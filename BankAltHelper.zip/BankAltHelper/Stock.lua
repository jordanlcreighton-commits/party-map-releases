-- Bank Alt Helper: what every character holds. Bags whenever they change, the bank each time it's
-- open, the mailbox, and mail sent to another of your characters (counted as on its way).
-- Saved account-wide, so your main sees the bank alt as of the last time you logged off it.
local _, ns = ...
local S = {}
ns.S = S

-- ---------------------------------------------------------------- containers

local function numSlots(bag)
	if C_Container and C_Container.GetContainerNumSlots then return C_Container.GetContainerNumSlots(bag) or 0 end
	return GetContainerNumSlots and GetContainerNumSlots(bag) or 0
end

local function slotInfo(bag, slot)
	if C_Container and C_Container.GetContainerItemInfo then
		local i = C_Container.GetContainerItemInfo(bag, slot)
		if not i then return nil end
		return { id = i.itemID, count = i.stackCount or 1, isBound = i.isBound, hasNoValue = i.hasNoValue,
			link = i.hyperlink, locked = i.isLocked }
	end
	if GetContainerItemInfo then
		local _, count, _, _, _, _, link, _, noValue, id = GetContainerItemInfo(bag, slot)
		if not id and not link then return nil end
		return { id = id or ns.ItemID(link), count = count or 1, hasNoValue = noValue, link = link }
	end
	return nil
end
S.SlotInfo = slotInfo

function S.BagIDs()
	local last = NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4
	local out = {}
	for b = 0, last do out[#out + 1] = b end
	return out
end

function S.BankIDs()
	local E = Enum and Enum.BagIndex
	local out = { (E and E.Bank) or BANK_CONTAINER or -1 }
	if E and E.BankBag_1 then
		for i = 1, 7 do if E["BankBag_" .. i] then out[#out + 1] = E["BankBag_" .. i] end end
	else
		local first = (NUM_BAG_SLOTS or 4) + 1
		for b = first, first + (NUM_BANKBAGSLOTS or 7) - 1 do out[#out + 1] = b end
	end
	if E and E.Reagentbank then out[#out + 1] = E.Reagentbank end
	return out
end

-- Reads a set of containers into { items = {id = count}, bound = {id = true}, free, total, t }.
function S.Read(bags)
	local r = { items = {}, bound = {}, free = 0, total = 0, t = ns.Now() }
	for _, bag in ipairs(bags) do
		local n = numSlots(bag)
		r.total = r.total + n
		for slot = 1, n do
			local i = slotInfo(bag, slot)
			if i and i.id then
				if ns.Sellable(i) then
					r.items[i.id] = (r.items[i.id] or 0) + i.count
				else
					r.bound[i.id] = true
				end
			else
				r.free = r.free + 1
			end
		end
	end
	return r
end

function S.ScanBags()
	local c = ns.Char()
	c.bags = S.Read(S.BagIDs())
	c.money = GetMoney and GetMoney() or c.money
	c.faction = ns.Faction()
end

function S.ScanBank()
	if not ns.atBank then return end
	local c = ns.Char()
	c.bank = S.Read(S.BankIDs())
end

-- ---------------------------------------------------------------- the mailbox

function S.ScanInbox()
	if not GetInboxNumItems then return end
	local c = ns.Char()
	local items, money = {}, 0
	local n = GetInboxNumItems() or 0
	local maxAtt = ATTACHMENTS_MAX_RECEIVE or 16
	for i = 1, n do
		local _, _, _, _, m, cod, _, hasItem = GetInboxHeaderInfo(i)
		money = money + (tonumber(m) or 0)
		if hasItem and (tonumber(cod) or 0) == 0 then
			for a = 1, maxAtt do
				local name, id, _, count = GetInboxItem(i, a)
				if name or id then
					id = id or (GetInboxItemLink and ns.ItemID(GetInboxItemLink(i, a)))
					if id then items[id] = (items[id] or 0) + (count or 1) end
				end
			end
		end
	end
	c.mail = { items = items, money = money, n = n, t = ns.Now() }
	-- Anything that was on its way to this character is in the mailbox (or already taken) now.
	ns.db.transit[ns.Me()] = nil
end

-- A name as typed or as the mail box has it -> the character's key ("bron herbs" -> "Bron Herbs").
function S.ShortName(r)
	return (ns.Resolve(r))
end

-- Called when a send is started; the items are counted only once the game says it went.
function S.OnSendMail(recipient)
	local to = S.ShortName(recipient)
	if not to or to == ns.Me() or not ns.db.chars[to] then S.pending = nil return end
	local items = {}
	local maxAtt = ATTACHMENTS_MAX_SEND or 12
	if GetSendMailItem then
		for a = 1, maxAtt do
			local name, id, _, count = GetSendMailItem(a)
			if name or id then
				id = id or (GetSendMailItemLink and ns.ItemID(GetSendMailItemLink(a)))
				if id then items[id] = (items[id] or 0) + (count or 1) end
			end
		end
	end
	local money = GetSendMailMoney and GetSendMailMoney() or 0
	if next(items) or money > 0 then
		S.pending = { to = to, items = items, money = money, from = ns.Me(), t = ns.Now() }
	else
		S.pending = nil
	end
end

function S.OnSendSuccess()
	local p = S.pending
	S.pending = nil
	if not p then return end
	local list = ns.db.transit[p.to]
	if type(list) ~= "table" then list = {}; ns.db.transit[p.to] = list end
	list[#list + 1] = p
	ns.After(0.5, S.ScanBags)
end

-- Everything on its way to a character, added up: { id = count }, money
function S.Transit(name)
	local items, money = {}, 0
	local list = ns.db.transit[name]
	if type(list) == "table" then
		for _, p in ipairs(list) do
			if type(p) == "table" then
				money = money + (tonumber(p.money) or 0)
				if type(p.items) == "table" then
					for id, n in pairs(p.items) do items[id] = (items[id] or 0) + n end
				end
			end
		end
	end
	return items, money
end

-- ---------------------------------------------------------------- totals

-- One character's stock, added up across bags, bank, mailbox and mail on its way.
-- Returns { [id] = count } and where it came from.
function S.AllItems(name)
	local c = ns.db.chars[name]
	local all = {}
	local function add(t)
		if type(t) == "table" and type(t.items) == "table" then
			for id, n in pairs(t.items) do all[id] = (all[id] or 0) + n end
		end
	end
	if type(c) == "table" then add(c.bags); add(c.bank); add(c.mail) end
	add({ items = (S.Transit(name)) })
	return all
end

-- What a set of items is worth: auction items at what you'd pocket, vendor items at the vendor price.
function S.Value(items)
	local auction, vendor, unknown = 0, 0, 0
	for id, n in pairs(items) do
		local v = ns.V.ForItem(id, n)
		if v.action == "auction" or (v.action == "keep" and v.net) then auction = auction + math.max(0, math.floor(v.net or 0))
		elseif v.action == "vendor" then vendor = vendor + v.vendorTotal
		else unknown = unknown + 1 end
	end
	return auction, vendor, unknown
end

-- ---------------------------------------------------------------- events

ns.On("PLAYER_ENTERING_WORLD", function() ns.After(2, S.ScanBags) end)
ns.On("BAG_UPDATE_DELAYED", function()
	S.ScanBags()
	if ns.atBank then S.ScanBank() end
end)
ns.On("PLAYER_MONEY", function() local c = ns.Char(); c.money = GetMoney and GetMoney() or c.money end)

ns.On("BANKFRAME_OPENED", function() ns.atBank = true; S.ScanBank() end)
ns.On("BANKFRAME_CLOSED", function() ns.atBank = false end)
ns.On("PLAYERBANKSLOTS_CHANGED", function() S.ScanBank() end)
ns.On("PLAYERBANKBAGSLOTS_CHANGED", function() S.ScanBank() end)

ns.On("MAIL_SHOW", function() ns.atMail = true end)
ns.On("MAIL_CLOSED", function() ns.atMail = false end)
ns.On("MAIL_INBOX_UPDATE", function() S.ScanInbox() end)
ns.On("MAIL_SEND_SUCCESS", function() S.OnSendSuccess() end)
ns.On("MAIL_FAILED", function() S.pending = nil end)

table.insert(ns.OnLoad, function()
	if hooksecurefunc then
		if SendMail then hooksecurefunc("SendMail", function(r) ns.Safe("send mail", S.OnSendMail, r) end) end
		if C_Mail and C_Mail.SendMail then
			hooksecurefunc(C_Mail, "SendMail", function(r) ns.Safe("send mail", S.OnSendMail, r) end)
		end
	end
end)
