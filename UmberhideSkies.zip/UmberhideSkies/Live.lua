-- Umberhide Skies: live weather. The weather rolls in and out on its own, by zone: clouds gather
-- from the windward side, the wind rises, a storm's thunder comes closer, the rain starts light and
-- builds, then eases off into mist and clears. Each zone has its climate (rain in Ashenvale and
-- Stranglethorn, snow in Dun Morogh and Winterspring, dust in the deserts, gloom in Duskwood and
-- the Plaguelands). It's worked out from the server's clock and the zone, so everyone in the same
-- zone (you and Mika) sees the same weather, without sending anything.
--
-- Everything else reads the weather from ns.W, which is either this (live) or your own look.
local ADDON, ns = ...
local Live = {}
ns.Live = Live
local Clamp = ns.Clamp

ns.W = { rain = 0, snow = 0, fog = 0, wind = 0, ff = 0, storm = 0, cloud = 0, dust = 0, frost = 0, dist = 0.6 }

local SLOT = 1200          -- each zone's weather can change every 20 minutes
local ARRIVE, LEAVE = 210, 180  -- a front takes about 3½ minutes to come in, 3 to clear

-- the climates: how often each kind of weather comes
local CLIMATES = {
	temperate = { clear = 42, cloudy = 20, mist = 10, drizzle = 12, rain = 10, storm = 6 },
	rainy = { clear = 22, cloudy = 16, mist = 10, drizzle = 18, rain = 20, storm = 14 },
	swamp = { clear = 15, cloudy = 15, mist = 30, drizzle = 15, rain = 15, storm = 10 },
	snowy = { clear = 30, cloudy = 20, mist = 8, snow = 27, blizzard = 15 },
	desert = { clear = 55, cloudy = 15, dust = 22, drizzle = 5, storm = 3 },
	gloomy = { clear = 15, cloudy = 20, mist = 30, drizzle = 22, rain = 10, storm = 3 },
}
Live.CLIMATES = CLIMATES
local ORDER = { "clear", "cloudy", "mist", "drizzle", "rain", "storm", "snow", "blizzard", "dust" }

-- what each kind of weather is made of at its height
local KINDS = {
	clear = { cloud = 0.08, wind = 0.12, fog = 0.03 },
	cloudy = { cloud = 0.55, wind = 0.30, fog = 0.08 },
	mist = { cloud = 0.30, wind = 0.05, fog = 0.75 },
	drizzle = { cloud = 0.60, wind = 0.15, fog = 0.30, rain = 0.30 },
	rain = { cloud = 0.80, wind = 0.30, fog = 0.18, rain = 0.65 },
	storm = { cloud = 1.00, wind = 0.60, fog = 0.15, rain = 0.90, storm = 1 },
	snow = { cloud = 0.70, wind = 0.20, fog = 0.25, snow = 0.55, frost = 1 },
	blizzard = { cloud = 0.95, wind = 0.85, fog = 0.50, snow = 1.00, frost = 1 },
	dust = { cloud = 0.25, wind = 0.80, fog = 0.00, dust = 0.75 },
}
Live.KINDS = KINDS
Live.NAMES = { clear = "clear", cloudy = "clouds", mist = "mist", drizzle = "drizzle", rain = "rain",
	storm = "a thunderstorm", snow = "snow", blizzard = "a blizzard", dust = "a dust storm" }

-- zones (the game's map IDs, as Party Map's quest pack has them) and their climates
local ZONES = {
	[1429] = "temperate", [1436] = "temperate", [1433] = "temperate", [1432] = "temperate", [1424] = "temperate",
	[1417] = "temperate", [1425] = "temperate", [1421] = "temperate", [1438] = "temperate", [1439] = "temperate",
	[1442] = "temperate", [1412] = "temperate", [1450] = "temperate", [1447] = "temperate", [1453] = "temperate",
	[1456] = "temperate", [1457] = "temperate",
	[1440] = "rainy", [1434] = "rainy", [1437] = "rainy", [1444] = "rainy", [1449] = "rainy",
	[1445] = "swamp", [1435] = "swamp",
	[1426] = "snowy", [1452] = "snowy", [1416] = "snowy", [1455] = "snowy",
	[1411] = "desert", [1413] = "desert", [1441] = "desert", [1443] = "desert", [1446] = "desert", [1451] = "desert",
	[1418] = "desert", [1427] = "desert", [1428] = "desert", [1419] = "desert", [1454] = "desert",
	[1431] = "gloomy", [1420] = "gloomy", [1422] = "gloomy", [1423] = "gloomy", [1448] = "gloomy", [1430] = "gloomy",
	[1458] = "gloomy",
}
Live.ZONES = ZONES

-- ---------------------------------------------------------------- where and when
local function ZoneMap()
	if not (C_Map and C_Map.GetBestMapForUnit) then return nil end
	local ok, id = pcall(C_Map.GetBestMapForUnit, "player")
	if not ok or type(id) ~= "number" or ns.Secret(id) then return nil end
	-- a cave, a building or a part of a city: walk up to the zone it's in
	for _ = 1, 6 do
		if ZONES[id] or not C_Map.GetMapInfo then break end
		local ok2, info = pcall(C_Map.GetMapInfo, id)
		if not ok2 or type(info) ~= "table" or not info.parentMapID or info.parentMapID == 0 then break end
		id = info.parentMapID
	end
	return id
end
Live.ZoneMap = ZoneMap

local function ServerTime()
	if GetServerTime then
		local ok, t = pcall(GetServerTime)
		if ok and type(t) == "number" and not ns.Secret(t) then return t end
	end
	return time and time() or 0
end
Live.ServerTime = ServerTime

-- a number from 0 to 1 that's the same for everyone for this zone and slot of time. (Lua 5.1 has
-- no bit operations and doubles are exact only to 2^53, so it mixes with small multiplies and a
-- square of the high half, which keeps it from falling into a pattern.)
local P = 2147483647
local function Mix(h)
	h = (h * 16807) % P
	local hi = math.floor(h / 65536)
	h = (h + hi * hi + 12345) % P
	return (h * 48271) % P
end
local function Hash(a, b, salt)
	local h = 1234567
	for _, v in ipairs({ a, b, salt or 0 }) do
		v = math.floor(math.abs(v))
		repeat
			h = Mix((h * 31 + v % 10000) % P)
			v = math.floor(v / 10000)
		until v == 0
		h = Mix(h)
	end
	return Mix(Mix(h)) / P
end
Live.Hash = Hash

local function KindOf(zone, climate, k)
	local w = CLIMATES[climate] or CLIMATES.temperate
	local total = 0
	for _, key in ipairs(ORDER) do total = total + (w[key] or 0) end
	local r = Hash(zone, k, 1) * total
	for _, key in ipairs(ORDER) do
		r = r - (w[key] or 0)
		if r < 0 then return key end
	end
	return "clear"
end

local function smooth(a, b, x)
	local t = Clamp((x - a) / (b - a), 0, 1)
	return t * t * (3 - 2 * t)
end

-- ---------------------------------------------------------------- the weather now
-- How much of the weather of slot k shows at time tau into it (0..1 each part), coming in at the
-- start (clouds first, then wind, then the rain) and going out at the end (rain first, clouds last).
local function Shape(kind, prevSame, nextSame, tau)
	local a = prevSame and 1 or Clamp(tau / ARRIVE, 0, 1)
	local b = nextSame and 0 or Clamp((tau - (SLOT - LEAVE)) / LEAVE, 0, 1)
	local p = {}
	p.cloud = smooth(0, 0.45, a) * (1 - smooth(0.4, 1.0, b))
	p.wind = smooth(0.1, 0.55, a) * (1 - smooth(0.2, 0.8, b))
	p.fall = smooth(0.35, 1.0, a) * (1 - smooth(0, 0.55, b))   -- rain, snow, dust
	p.storm = smooth(0.5, 1.0, a) * (1 - smooth(0, 0.4, b))
	p.fog = smooth(0.2, 0.9, a) * (1 - smooth(0.6, 1.0, b))
	p.after = math.sin(math.pi * b) -- mist rising as rain clears
	p.arrive, p.leave = a, b
	return p
end

function Live.Compute(zone, climate, t)
	local k = math.floor(t / SLOT)
	local tau = t - k * SLOT
	local cur, prev, nxt = KindOf(zone, climate, k), KindOf(zone, climate, k - 1), KindOf(zone, climate, k + 1)
	local I = 0.7 + 0.3 * Hash(zone, k, 2)
	local kd = KINDS[cur]
	local p = Shape(cur, prev == cur, nxt == cur, tau)
	local base = KINDS.clear
	local w = {}
	w.cloud = math.max(base.cloud, (kd.cloud or 0) * I * p.cloud)
	w.wind = math.max(base.wind, (kd.wind or 0) * I * p.wind)
	w.rain = (kd.rain or 0) * I * p.fall
	w.snow = (kd.snow or 0) * I * p.fall
	w.dust = (kd.dust or 0) * I * p.fall
	w.storm = (kd.storm or 0) * p.storm
	w.frost = (kd.frost or 0) * p.cloud
	w.fog = math.max(base.fog, (kd.fog or 0) * I * p.fog + ((kd.rain or 0) > 0 and 0.30 * (kd.rain or 0) * p.after or 0))
	-- a storm comes closer as it arrives and moves off as it clears
	if w.storm > 0 then
		local wobble = 0.15 * math.sin(t * 0.05 + k)
		w.dist = Clamp(math.max(1 - p.arrive, p.leave) * 0.85 + 0.25 + wobble, 0.05, 1)
	else
		w.dist = 1
	end
	-- what's happening, in words
	local phase
	if cur == "clear" then phase = "clear"
	elseif p.arrive < 1 then phase = "coming in"
	elseif p.leave > 0 then phase = "clearing"
	else phase = "here" end
	w.kind, w.phase, w.next, w.until_ = cur, phase, nxt, SLOT - tau
	return w
end

function Live.Climate(zone)
	return zone and ZONES[zone] or "temperate"
end

-- ---------------------------------------------------------------- each frame
local smoothW = {}
Live.status = { zone = nil, climate = "temperate", kind = "clear", phase = "clear" }

local FIELDS = { "rain", "snow", "fog", "wind", "ff", "storm", "cloud", "dust", "frost" }

local function Manual(s)
	local W = {}
	W.rain, W.snow, W.fog, W.wind, W.ff = s.rain, s.snow, s.fog, s.wind, s.ff
	W.storm = s.storm and 1 or 0
	W.frost = s.frost and 1 or 0
	W.dust = 0
	W.cloud = math.max(s.rain * 0.9, s.snow * 0.7, W.storm, s.fog * 0.35)
	return W
end

function Live.Update(elapsed, now)
	local s = ns.s
	local target
	if not s.on then
		target = { rain = 0, snow = 0, fog = 0, wind = 0, ff = 0, storm = 0, cloud = 0, dust = 0, frost = 0 }
	elseif s.live then
		local zone = ZoneMap()
		local climate = Live.Climate(zone)
		local w = Live.forced and Live.ComputeForced(Live.forced, now - (Live.forcedAt or now))
			or Live.Compute(zone or 0, climate, ServerTime())
		local k = s.wstr
		target = {}
		for _, f in ipairs(FIELDS) do target[f] = (w[f] or 0) * (f == "frost" and 1 or k) end
		-- fireflies on warm, dry, dark nights
		local d = ns.Darkness and ns.Darkness() or 0
		if (climate == "temperate" or climate == "rainy" or climate == "swamp") and w.rain < 0.05 and d > 0.4 then
			target.ff = 0.45 * k
		end
		ns.W.dist = w.dist
		local st = Live.status
		st.zone, st.climate, st.kind, st.phase, st.next, st.untilNext = zone, climate, w.kind, w.phase, w.next, w.until_
	else
		target = Manual(s)
		ns.W.dist = nil
	end
	-- ease towards it (the director already changes slowly; this takes the edge off a zone change
	-- or a switch between live and your own look)
	local k = Clamp((elapsed or 0) / 4, 0, 1)
	for _, f in ipairs(FIELDS) do
		local v = smoothW[f]
		if v == nil then v = target[f] end
		v = v + (target[f] - v) * k
		smoothW[f] = v
		ns.W[f] = v
	end
end

-- jump straight to the target (on load, so it doesn't fade in from nothing every /reload)
function Live.Settle()
	for _, f in ipairs(FIELDS) do smoothW[f] = nil end
	Live.Update(0, 0)
end
function Live.Init()
	Live.Settle()
	-- a preset or a setting changed by hand takes effect at once
	table.insert(ns.listeners, function() Live.Settle() end)
end

-- In words, for /skies status and the panel
function Live.Describe()
	local s = ns.s
	if not s.live then return "your own look" end
	local st = Live.status
	local zoneName = st.zone and ns.ZoneName and ns.ZoneName(st.zone) or "here"
	local now = Live.NAMES[st.kind] or st.kind
	local txt
	if st.kind == "clear" then txt = "clear skies"
	elseif st.phase == "coming in" then txt = now .. " coming in"
	elseif st.phase == "clearing" then txt = now .. ", clearing"
	else txt = now end
	if st.next and st.next ~= st.kind and st.untilNext and st.untilNext < 360 and st.next ~= "clear" then
		txt = txt .. "; " .. (Live.NAMES[st.next] or st.next) .. " on the way"
	end
	return ("%s (%s): %s"):format(zoneName, st.climate, txt)
end

-- Bring a kind of weather in now, whatever the zone's own weather is: /skies weather storm
-- (it comes in the way real weather does, and stays until /skies weather live)
function Live.ComputeForced(kind, tau)
	local kd = KINDS[kind]
	local p = Shape(kind, false, true, tau)
	local base = KINDS.clear
	local w = {}
	w.cloud = math.max(base.cloud, (kd.cloud or 0) * p.cloud)
	w.wind = math.max(base.wind, (kd.wind or 0) * p.wind)
	w.rain, w.snow, w.dust = (kd.rain or 0) * p.fall, (kd.snow or 0) * p.fall, (kd.dust or 0) * p.fall
	w.storm, w.frost = (kd.storm or 0) * p.storm, (kd.frost or 0) * p.cloud
	w.fog = math.max(base.fog, (kd.fog or 0) * p.fog)
	w.dist = (kd.storm or 0) > 0 and Clamp((1 - p.arrive) * 0.85 + 0.25 + 0.15 * math.sin(tau * 0.05), 0.05, 1) or 1
	w.kind, w.phase, w.next, w.until_ = kind, p.arrive < 1 and "coming in" or "here", kind, nil
	return w
end

function Live.Force(kind)
	if KINDS[kind] then
		Live.forced, Live.forcedAt = kind, ns.now or 0
		ns.s.live = true
		return true
	end
	Live.forced = nil
	return false
end

function ns.ZoneName(id)
	if C_Map and C_Map.GetMapInfo then
		local ok, info = pcall(C_Map.GetMapInfo, id)
		if ok and type(info) == "table" and type(info.name) == "string" then return info.name end
	end
	return "zone " .. tostring(id)
end

ns.Register("live", Live)
