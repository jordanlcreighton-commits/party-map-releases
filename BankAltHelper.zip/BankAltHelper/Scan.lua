-- Bank Alt Helper: auction house scans. Opening the auction house looks up the items you hold,
-- a few at a time and only as fast as the game allows, and saves the lowest price, how many are
-- listed and whether the lowest is yours. The post button asks for a fresh look right before posting.
local _, ns = ...
local C = ns.C
local A = {}
ns.A = A

A.queue = {}      -- { id = itemID, loc = ItemLocation or nil, cb = function or nil }
A.busy = nil      -- the look-up waiting for its answer
A.TIMEOUT = 5     -- seconds to wait for an answer before moving on
A.STALE = 600     -- don't look up an item seen less than 10 minutes ago (unless asked)
A.PER_VISIT = 250 -- at most this many look-ups each time the auction house opens

local function AH() return C_AuctionHouse end

local function now() return GetTime and GetTime() or 0 end

-- The search key for an item. One in your bags gives an exact key (its item level too).
function A.KeyFor(id, loc)
	local ah = AH()
	if loc and ah.GetItemKeyFromItem then
		local ok, key = pcall(ah.GetItemKeyFromItem, loc)
		if ok and type(key) == "table" then return key end
	end
	if ah.MakeItemKey then return ah.MakeItemKey(id) end
	return { itemID = id, itemLevel = 0, itemSuffix = 0, battlePetSpeciesID = 0 }
end

local function sorts()
	local order = Enum and Enum.AuctionHouseSortOrder and Enum.AuctionHouseSortOrder.Price or 0
	return { { sortOrder = order, reverseSort = false } }
end

-- Saves one look-up's answer into this faction's price book.
-- min: lowest unit price (nil = none listed), qty: how many listed, mine: lowest is yours
function A.Record(id, min, qty, mine, commodity)
	local book = ns.Prices()
	local e = book[id]
	if type(e) ~= "table" then e = {}; book[id] = e end
	local t = ns.Now()
	e.min, e.qty, e.mine, e.t = min, qty or 0, mine and true or false, t
	if commodity ~= nil then e.commodity = commodity end
	if min then e.last = min end
	if type(e.hist) ~= "table" then e.hist = {} end
	local h = e.hist
	local point = { t, min or 0, qty or 0 }
	local prev = h[#h]
	if type(prev) == "table" and t - (prev[1] or 0) < 1800 then
		h[#h] = point -- one point per half hour
	else
		h[#h + 1] = point
	end
	while #h > C.HISTORY_MAX do table.remove(h, 1) end
	if ns.G and ns.G.Refresh then ns.Safe("graph refresh", ns.G.Refresh, id) end
	return e
end

-- Reads the commodity results for an item: lowest unit price, total listed, lowest is yours.
function A.ReadCommodity(id)
	local ah = AH()
	local n = ah.GetNumCommoditySearchResults and ah.GetNumCommoditySearchResults(id) or 0
	local min, mine, qty = nil, false, 0
	for i = 1, n do
		local r = ah.GetCommoditySearchResultInfo(id, i)
		if r and r.unitPrice and r.unitPrice > 0 then
			qty = qty + (r.quantity or 0)
			if not min then
				min = r.unitPrice
				mine = (r.containsOwnerItem or r.containsAccountItem) and true or false
			end
		end
	end
	if ah.GetCommoditySearchResultsQuantity then
		local total = ah.GetCommoditySearchResultsQuantity(id)
		if type(total) == "number" and total > qty then qty = total end
	end
	return min, qty, mine
end

-- Reads item (non-stacking) results: lowest buyout per unit, how many listed, lowest is yours.
function A.ReadItems(key)
	local ah = AH()
	local n = ah.GetNumItemSearchResults and ah.GetNumItemSearchResults(key) or 0
	local min, mine, qty = nil, false, 0
	for i = 1, n do
		local r = ah.GetItemSearchResultInfo(key, i)
		if r then
			qty = qty + (r.quantity or 1)
			local buy = r.buyoutAmount
			if buy and buy > 0 then
				local per = math.floor(buy / math.max(1, r.quantity or 1))
				if not min or per < min then
					min = per
					mine = (r.containsOwnerItem or r.containsAccountItem) and true or false
				end
			end
		end
	end
	return min, qty, mine
end

-- ---------------------------------------------------------------- the queue

-- How the current round of look-ups went, for the summary in chat.
A.stats = { found = 0, none = 0, noAnswer = 0 }

local function finish(id, min, qty, mine, commodity, ok)
	local job = A.busy
	A.busy = nil
	if ok then A.Record(id, min, qty, mine, commodity) end
	if not ok then A.stats.noAnswer = A.stats.noAnswer + 1
	elseif min then A.stats.found = A.stats.found + 1
	else A.stats.none = A.stats.none + 1 end
	if job and job.cb then ns.Safe("scan answer", job.cb, ok and ns.Prices()[id] or nil) end
	A.Next()
end

-- "prices updated: 30 found, 4 not listed, 1 got no answer" (and a warning if nothing answered)
function A.Summary()
	local s = A.stats
	if s.found == 0 and s.none == 0 and s.noAnswer > 0 then
		return "|cffff6060the auction house didn't answer any of " .. s.noAnswer .. " searches.|r Close it, open it again, "
			.. "and if it still says this, tell Jordan."
	end
	local parts = { s.found .. " found" }
	if s.none > 0 then parts[#parts + 1] = s.none .. " not listed by anyone" end
	if s.noAnswer > 0 then parts[#parts + 1] = s.noAnswer .. " got no answer (tried again next visit)" end
	return "prices updated: " .. table.concat(parts, ", ") .. ". /bankalt to see what everything is worth."
end

function A.Next()
	if A.busy or not ns.atAH then return end
	local ah = AH()
	if not ah then return end
	if ah.IsThrottledMessageSystemReady and not ah.IsThrottledMessageSystemReady() then return end
	local job = table.remove(A.queue, 1)
	if not job then
		if A.onDone then local f = A.onDone; A.onDone = nil; ns.Safe("scan done", f) end
		return
	end
	job.key = A.KeyFor(job.id, job.loc)
	job.sent = now()
	A.busy = job
	ah.SendSearchQuery(job.key, sorts(), true)
	local mark = job.sent
	ns.After(A.TIMEOUT, function()
		if A.busy and A.busy.sent == mark then finish(job.id, nil, nil, nil, nil, false) end
	end)
end

-- Ask for one item. urgent puts it at the front (the post button uses this).
function A.Request(id, loc, cb, urgent)
	if not id then return end
	for i = #A.queue, 1, -1 do
		if A.queue[i].id == id then
			if not urgent and not cb then return end
			table.remove(A.queue, i)
		end
	end
	local job = { id = id, loc = loc, cb = cb }
	if urgent then table.insert(A.queue, 1, job) else A.queue[#A.queue + 1] = job end
	A.Next()
end

-- Look up everything this character holds, then everyone else's stock, stalest first.
function A.ScanHeld(force)
	A.stats = { found = 0, none = 0, noAnswer = 0 }
	local t = ns.Now()
	local mine = ns.S.AllItems(ns.Me())
	local seen, list = {}, {}
	local function want(id, own)
		if seen[id] or ns.db.keep[id] then return end
		seen[id] = true
		local e = ns.Prices()[id]
		local age = (type(e) == "table" and e.t) and (t - e.t) or math.huge
		if force or age > A.STALE then list[#list + 1] = { id = id, age = age, own = own } end
	end
	for id in pairs(mine) do want(id, true) end
	local first = #list
	for name in pairs(ns.db.chars) do
		if name ~= ns.Me() then for id in pairs(ns.S.AllItems(name)) do want(id, false) end end
	end
	table.sort(list, function(a, b)
		if a.own ~= b.own then return a.own end
		if a.age ~= b.age then return a.age > b.age end
		return a.id < b.id
	end)
	local n = 0
	for _, it in ipairs(list) do
		if n >= A.PER_VISIT then break end
		A.Request(it.id)
		n = n + 1
	end
	return n, first
end

-- ---------------------------------------------------------------- events

ns.On("AUCTION_HOUSE_SHOW", function()
	ns.atAH = true
	local cut, neutral = ns.V.Cut()
	A.neutral = neutral
	ns.After(1, function()
		local n = A.ScanHeld(false)
		if n > 0 then
			ns.Print("looking up " .. n .. " prices for your characters' items" .. (n > 20 and " (keep the auction house open a minute)" or "") .. ".")
			A.onDone = function() ns.Print(A.Summary()) end
		end
	end)
end)

ns.On("AUCTION_HOUSE_CLOSED", function()
	ns.atAH = false
	A.queue, A.busy = {}, nil
end)

ns.On("AUCTION_HOUSE_THROTTLED_SYSTEM_READY", function() A.Next() end)

-- Searches you make yourself in the auction house are saved too (only when they found listings:
-- a search still loading would otherwise look like "none listed"), so the graphs fill up faster.
ns.On("COMMODITY_SEARCH_RESULTS_UPDATED", function(id)
	local job = A.busy
	local min, qty, mine = A.ReadCommodity(id)
	if job and job.id == id then
		finish(id, min, qty, mine, true, true)
	elseif id and min then
		A.Record(id, min, qty, mine, true)
	end
end)

ns.On("ITEM_SEARCH_RESULTS_UPDATED", function(key)
	local job = A.busy
	local kid = type(key) == "table" and key.itemID or key
	if job and job.id == kid then
		local min, qty, mine = A.ReadItems(type(key) == "table" and key or job.key)
		finish(job.id, min, qty, mine, false, true)
	elseif type(key) == "table" and kid then
		local min, qty, mine = A.ReadItems(key)
		if min then A.Record(kid, min, qty, mine, false) end
	end
end)
