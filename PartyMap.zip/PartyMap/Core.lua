-- Party Map: shows your position and quest log as a thin grey strip on the edge of the
-- screen, for the Party Map app to read. Type /partymap for options.

local addonName, ns = ...
local E = ns.Encode

local WORLD = 947                 -- OpenMap's stitched world is Azeroth's world map
local UPDATE = 1 / 60             -- seconds between frames (60 a second, or the game's frame rate if lower)
local REBUILD = 1.0               -- seconds between quest log rebuilds at most

PartyMapDB = PartyMapDB or {}

-- the saved settings, checked when the game loads them: anything of the wrong type starts afresh
local DB_TYPES = { bags = "boolean", bind = "table", bright = "boolean", corner = "string", corpse = "table",
	learnedNames = "table", mailbox = "table", markerDebug = "boolean", names = "table", on = "boolean",
	roleHint = "table", roles = "table", run = "table", taxi = "table", uprank = "boolean", xp = "table",
	noticePos = "table", noticeLater = "string", noticeOff = "boolean", npcShot = "table", npcFaces = "boolean" }
function ns.CheckDB()
	if type(PartyMapDB) ~= "table" then PartyMapDB = {}; ns.dbReset = (ns.dbReset or 0) + 1; return end
	for k, want in pairs(DB_TYPES) do
		local v = PartyMapDB[k]
		if v ~= nil and type(v) ~= want then PartyMapDB[k] = nil; ns.dbReset = (ns.dbReset or 0) + 1 end
	end
	local c = PartyMapDB.corner
	if c and c ~= "bl" and c ~= "br" and c ~= "tl" and c ~= "tr" then PartyMapDB.corner = nil end
	for _, k in ipairs({ "names", "learnedNames" }) do
		for key, v in pairs(PartyMapDB[k] or {}) do if type(v) ~= "string" then PartyMapDB[k][key] = nil end end
	end
end

local frame = CreateFrame("Frame", "PartyMapStrip", UIParent)
frame:SetFrameStrata("TOOLTIP")
frame:SetFrameLevel(10000)
frame:SetIgnoreParentScale(true)
frame:SetSize(E.CELLS * 2, 1)
frame:EnableMouse(false)

local cells = {}
for i = 1, E.CELLS do
	local t = frame:CreateTexture(nil, "OVERLAY")
	t:SetSize(2, 1)
	t:SetPoint("TOPLEFT", frame, "TOPLEFT", (i - 1) * 2, 0)
	if t.SetSnapToPixelGrid then t:SetSnapToPixelGrid(false); t:SetTexelSnappingBias(0) end
	t:SetColorTexture(0, 0, 0, 1)
	cells[i] = t
end

-- 1 frame unit = 1 physical pixel, so each cell is exactly 2x1 pixels
local function Layout()
	local _, ph = GetPhysicalScreenSize()
	if not ph or ph <= 0 then return end
	frame:SetScale(768 / ph)
	frame:ClearAllPoints()
	local c = PartyMapDB.corner or "bl"
	local point = ({ bl = "BOTTOMLEFT", br = "BOTTOMRIGHT", tl = "TOPLEFT", tr = "TOPRIGHT" })[c] or "BOTTOMLEFT"
	frame:SetPoint(point, UIParent, point, 0, 0)
end

--------------------------------------------------------------------------------
-- Reading the game (every read guarded: some values can be hidden on this client)
--------------------------------------------------------------------------------

local function Secret(v) return issecretvalue and issecretvalue(v) or false end

local function Clean(s)
	if type(s) ~= "string" or Secret(s) then return "" end
	s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|T.-|t", ""):gsub("|A.-|a", "")
	s = s:gsub("|", "/"):gsub("[\r\n]", " ")
	return s
end

-- a map's rectangle on the world map (0..1), climbing to a parent that has one
local rectCache = {}
local function RectOnWorld(mapID)
	local r = rectCache[mapID]
	if r ~= nil then return r end
	r = false
	local ok, l, rr, t, b = pcall(C_Map.GetMapRectOnMap, mapID, WORLD)
	if ok and l and rr and rr > l and b > t then r = { l, rr, t, b } end
	rectCache[mapID] = r
	return r
end

local function WorldPos()
	local ok, mapID = pcall(C_Map.GetBestMapForUnit, "player")
	if not ok or not mapID or Secret(mapID) then return end
	local m = mapID
	for _ = 1, 6 do
		local okp, pos = pcall(C_Map.GetPlayerMapPosition, m, "player")
		if okp and pos then
			local okxy, x, y = pcall(pos.GetXY, pos)
			if okxy and x and y and not Secret(x) and not Secret(y) and (x ~= 0 or y ~= 0) then
				-- OpenMap's own placement when it's loaded (exact for cities), else Blizzard's rectangle
				if OpenMapAPI and OpenMapAPI.WorldFromMap then
					local oku, u, v = pcall(OpenMapAPI.WorldFromMap, m, x, y)
					u, v = oku and tonumber(u), oku and tonumber(v)
					if u and v then return u, v, mapID end
				end
				local r = RectOnWorld(m)
				if r then return r[1] + x * (r[2] - r[1]), r[3] + y * (r[4] - r[3]), mapID end
			end
		end
		local info = C_Map.GetMapInfo(m)
		if not info or not info.parentMapID or info.parentMapID == 0 then break end
		m = info.parentMapID
	end
	return nil, nil, mapID
end

-- Your bound inn: kept where you stood when you last set your hearthstone (HEARTHSTONE_BOUND);
-- until then, an innkeeper in the town your hearthstone names, if one is known.
function ns.BindLine()
	local okn, name = pcall(GetBindLocation)
	if not okn or type(name) ~= "string" or name == "" or Secret(name) then return end
	PartyMapDB = PartyMapDB or {}
	local b = PartyMapDB.bind
	if b and b.name == name and b.u then
		return ("HB|%d|%d|%s"):format(b.u * 1e5 + 0.5, b.v * 1e5 + 0.5, Clean(name))
	end
	local M = ns.Markers
	if M and M.places then
		local lname = name:lower()
		for _, p in ipairs(M.places) do
			if p[1] == "i" and p[6] then
				local ok, info = pcall(C_Map.GetMapInfo, p[6])
				if ok and info and info.name and info.name:lower() == lname then
					return ("HB|%d|%d|%s"):format(p[2] * 1e5 + 0.5, p[3] * 1e5 + 0.5, Clean(name))
				end
			end
		end
	end
end

local function HearthBound()
	local u, v = WorldPos()
	local okn, name = pcall(GetBindLocation)
	if u and okn and type(name) == "string" and not Secret(name) then
		PartyMapDB.bind = { u = u, v = v, name = name }
	end
end

local worldW, worldH
local function WorldSize()
	if worldW then return worldW, worldH end
	local ok, layers = pcall(C_Map.GetMapArtLayers, WORLD)
	local l = ok and layers and layers[1]
	if l then worldW, worldH = l.layerWidth, l.layerHeight end
	return worldW, worldH
end

local function Facing()
	local ok, f = pcall(GetPlayerFacing)
	if ok and f and not Secret(f) then return f end
end

local function Flags()
	local f = 0
	if UnitAffectingCombat("player") then f = f + 1 end
	if UnitIsDeadOrGhost("player") then f = f + 2 end
	local taxi = UnitOnTaxi and UnitOnTaxi("player")
	if taxi or IsMounted() then f = f + 4 end
	if taxi then f = f + 8 end
	return f
end

-- the quest log as compact text lines, in the quest log's own order:
--   N|name|level|class|zone|subzone|maxQuests
--   H|heading                          (a quest log heading: a zone or a category)
--   Q|questID|title|complete(0/1)|level|failed(0/1)
--   O|done(0/1)|have|need|objective text  (have/need empty when the objective has no count)
local function Objectives(questID, logIndex, out)
	local objs = C_QuestLog and C_QuestLog.GetQuestObjectives and C_QuestLog.GetQuestObjectives(questID)
	if objs then
		for _, o in ipairs(objs) do
			local have, need = o.numFulfilled, o.numRequired
			if type(need) ~= "number" or need <= 1 and o.type ~= "monster" and o.type ~= "item" then have, need = nil, nil end
			out[#out + 1] = ("O|%d|%s|%s|%s"):format(o.finished and 1 or 0, have and tostring(have) or "", need and tostring(need) or "", Clean(o.text))
		end
	elseif GetNumQuestLeaderBoards and GetQuestLogLeaderBoard then
		for k = 1, GetNumQuestLeaderBoards(logIndex) or 0 do
			local text, _, done = GetQuestLogLeaderBoard(k, logIndex)
			out[#out + 1] = ("O|%d|||%s"):format(done and 1 or 0, Clean(text))
		end
	end
end

local logQuests = {}               -- { id, title, complete } for the markers

-- The run: the dungeon you're in and the bosses killed in it (kept in PartyMapDB.run, so a /reload
-- keeps them; a different dungeon, or 30 minutes outside, starts a new run)
local function InstanceNow()
	if not (IsInInstance and GetInstanceInfo) then return end
	local ok, inside, kind = pcall(IsInInstance)
	if not ok or Secret(inside) or not inside or Secret(kind) or (kind ~= "party" and kind ~= "raid") then return end
	local ok2, name, _, _, _, _, _, _, id = pcall(GetInstanceInfo)
	if not ok2 or not id or Secret(id) or id == 0 then return end
	return id, (name and not Secret(name)) and name or ""
end
local function Run()
	PartyMapDB.run = PartyMapDB.run or { kills = {} }
	local run, now = PartyMapDB.run, time and time() or 0
	local id, name = InstanceNow()
	if id then
		if run.inst ~= id or (run.left and now - run.left > 1800) then run.kills = {} end
		run.inst, run.name, run.left = id, name, nil
		run.inside = true
	else
		if run.inside then run.left = now end
		run.inside = false
		if run.left and now - run.left > 1800 then run.inst, run.kills = nil, {} end
	end
	return run
end
-- Where people are inside a dungeon. The game hides positions there (from every addon), so the map
-- places people by what they're doing: at the boss they're fighting, else past the last boss the group
-- killed, else at the entrance. Boss and entrance spots come from ForeverDungeonJournal's dungeon maps
-- (FDJ.DUNGEON_MAPS: x/y on the same 1002x668 map pictures Party Map shows).
local function FDJMap(name)
	local fdj = _G.ForeverDungeonJournal_NS
	local maps = fdj and fdj.DUNGEON_MAPS
	if type(maps) ~= "table" or type(name) ~= "string" or name == "" then return end
	if maps[name] then return maps[name], name end
	-- (Scarlet Monastery: the journal has a map per wing, "Scarlet Monastery: Graveyard")
	local sub = GetSubZoneText and GetSubZoneText() or ""
	if Secret(sub) then sub = "" end
	local firstKey
	for key, m in pairs(maps) do
		if type(key) == "string" and (key:find(name, 1, true) == 1 or name:find(key, 1, true) == 1) then
			local wing = key:match(":%s*(.+)$")
			if wing and sub ~= "" and sub:find(wing, 1, true) then return m, key end
			firstKey = firstKey or key
		end
	end
	if firstKey then return maps[firstKey], firstKey end
end
local function FDJBossNamed(m, name)
	if not (m and m.bosses and type(name) == "string" and name ~= "") then return end
	for _, b in ipairs(m.bosses) do
		if b.name == name then return b.name end
		for _, a in ipairs(b.aliases or {}) do if a == name then return b.name end end
	end
end
-- "DS|instanceID|floor|combat|boss": your floor (by the journal's uiMapIDs), whether you're fighting,
-- and the boss you're on (your target, or a boss frame)
local function DungeonStateLine(inst, name)
	local m = FDJMap(name)
	local floor = 1
	if m and m.floors and C_Map and C_Map.GetBestMapForUnit then
		local ok, mapID = pcall(C_Map.GetBestMapForUnit, "player")
		if ok and mapID and not Secret(mapID) then
			for i, f in ipairs(m.floors) do if f.uiMapID == mapID then floor = i end end
		end
	end
	local boss = ""
	for _, unit in ipairs({ "target", "boss1", "boss2", "boss3" }) do
		local ok, n = pcall(UnitName, unit)
		if ok and n and not Secret(n) then
			local b = FDJBossNamed(m, n)
			if b then boss = b break end
		end
	end
	local okc, fighting = pcall(UnitAffectingCombat, "player")
	fighting = okc and not Secret(fighting) and fighting
	return ("DS|%d|%d|%d|%s"):format(inst, floor, fighting and 1 or 0, Clean(boss))
end
-- "DM|instanceID|floor|kind|x|y|name" (x, y ×1000; kind b boss, e entrance, t way to another floor):
-- for the dungeon you're in and the ones your party are in
function ns.DungeonMarkLines(run)
	local want = {}
	if run and run.inside and run.inst then want[run.inst] = run.name end
	for _, o in pairs(ns.Others or {}) do
		local id, nm = (o.quests or ""):match("I|(%d+)|([^\n]*)")
		if id then want[tonumber(id)] = nm end
	end
	local out = {}
	for inst, name in pairs(want) do
		local m = FDJMap(name)
		if m then
			local function add(floor, kind, x, y, label)
				if type(x) == "number" and type(y) == "number" then
					out[#out + 1] = ("DM|%d|%d|%s|%d|%d|%s"):format(inst, floor or 1, kind, math.floor(x * 1000 + 0.5), math.floor(y * 1000 + 0.5), Clean(label or ""))
				end
			end
			if m.entrance then add(m.entrance.floor, "e", m.entrance.x, m.entrance.y, "") end
			for _, b in ipairs(m.bosses or {}) do add(b.floor, "b", b.x, b.y, b.name) end
			for _, t in ipairs(m.transitions or {}) do add(t.floor, "t", t.x, t.y, tostring(t.to or "")) end
		end
	end
	return out
end

local function BossKilled(name)
	if type(name) ~= "string" or Secret(name) or name == "" then return end
	local run = Run()
	if run.inst then run.kills[name] = true end
end

-- XP: where you are in the level, how fast it's coming (the last 30 minutes, kept across a /reload in
-- PartyMapDB.xp), what a kill and a quest are worth lately, and how long levels have taken
local XP_WINDOW = 1800
local function XPState()
	PartyMapDB.xp = PartyMapDB.xp or {}
	local x = PartyMapDB.xp
	x.log = x.log or {}           -- { { time, xp }, ... } gains
	x.kills = x.kills or {}       -- the last few kills' XP
	x.quests = x.quests or {}     -- the last few quests' XP
	x.dings = x.dings or {}       -- [level] = time() it was reached
	return x
end
local function Num(v) return type(v) == "number" and not Secret(v) and v or nil end
local function XPNow()
	local ok, cur = pcall(UnitXP, "player")
	local ok2, max = pcall(UnitXPMax, "player")
	return ok and Num(cur), ok2 and Num(max), UnitLevel("player") or 0
end
local lastXP, questXP = nil, {}     -- (questXP: rewards just handed in, to tell quests from kills)
local function Push(list, v, n) list[#list + 1] = v; while #list > n do table.remove(list, 1) end end
local function XPSession(x, now)
	-- a new session after half an hour away (nothing gained, nothing seen)
	local lastGain = #x.log > 0 and x.log[#x.log][1] or 0
	if not x.start or (now - lastGain > XP_WINDOW and now - (x.seen or 0) > XP_WINDOW) then x.start = now end
	x.seen = now
end
local function XPChanged()
	local cur, max, level = XPNow()
	if not cur or not max then return end
	local x, now = XPState(), time and time() or 0
	XPSession(x, now)
	if lastXP and (level > lastXP.level or cur ~= lastXP.cur) then
		local gain = cur - lastXP.cur
		if level > lastXP.level then gain = (lastXP.max - lastXP.cur) + cur end
		if gain > 0 then
			Push(x.log, { now, gain }, 400)
			-- a quest's reward came with it: that much was the quest, the rest a kill (or exploring)
			local t = GetTime()
			for i = #questXP, 1, -1 do
				local q = questXP[i]
				if t - q.t < 3 then gain = gain - q.xp end
				table.remove(questXP, i)
			end
			if gain > 0 and gain < max * 0.25 then Push(x.kills, gain, 15) end
		end
	end
	lastXP = { cur = cur, max = max, level = level }
end
local function QuestXP(xp)
	xp = Num(xp)
	if not xp or xp <= 0 then return end
	questXP[#questXP + 1] = { xp = xp, t = GetTime() }
	Push(XPState().quests, xp, 10)
	-- (if the XP came first, take the reward back out of the kills)
	local k = XPState().kills
	if #k > 0 and math.abs(k[#k] - xp) <= math.max(2, xp * 0.02) then table.remove(k) end
end
local function Avg(list)
	if #list == 0 then return 0 end
	local s = 0
	for _, v in ipairs(list) do s = s + v end
	return math.floor(s / #list + 0.5)
end
local function XPLine()
	local cur, max, level = XPNow()
	if not cur then return end
	local x, now = XPState(), time and time() or 0
	XPSession(x, now)
	-- XP an hour over the last 30 minutes (or since you started, after 5 minutes)
	local sum = 0
	for _, g in ipairs(x.log) do if now - g[1] <= XP_WINDOW and g[1] >= x.start then sum = sum + g[2] end end
	local span = math.min(XP_WINDOW, now - x.start)
	local rate = span >= 300 and math.floor(sum / span * 3600 + 0.5) or -1
	local rested = 0
	if GetXPExhaustion then local ok, r = pcall(GetXPExhaustion); rested = ok and Num(r) or 0 end
	-- how long the last level took (from when Party Map saw you reach it)
	local took = (x.dings[level] and x.dings[level - 1]) and (x.dings[level] - x.dings[level - 1]) or -1
	local maxLevel = GetMaxPlayerLevel and GetMaxPlayerLevel() or 60
	if (max or 0) == 0 or level >= maxLevel then return ("XP|0|0|0|-1|0|0|%d|-1"):format(took) end
	return ("XP|%d|%d|%d|%d|%d|%d|%d|%d"):format(cur, max, rested, rate, Avg(x.kills), Avg(x.quests), took, x.dings[level] and (now - x.dings[level]) or -1)
end

-- The zone you're in: its map, level range and whose land it is ("ZI|uiMapID|minLevel|maxLevel|pvp";
-- pvp: friendly, hostile, contested, sanctuary, ... as GetZonePVPInfo says)
-- classic zone levels and home territories by uiMapID (used when the game gives none)
local ZONE_LEVELS = {
	[1411] = { 1, 10 }, [1412] = { 1, 10 }, [1413] = { 10, 25 }, [1438] = { 1, 10 }, [1439] = { 10, 20 }, [1440] = { 18, 30 },
	[1441] = { 25, 35 }, [1442] = { 15, 27 }, [1443] = { 30, 40 }, [1444] = { 40, 50 }, [1445] = { 35, 45 }, [1446] = { 40, 50 },
	[1447] = { 45, 55 }, [1448] = { 48, 55 }, [1449] = { 48, 55 }, [1451] = { 55, 60 }, [1452] = { 55, 60 },
	[1416] = { 30, 40 }, [1417] = { 30, 40 }, [1418] = { 35, 45 }, [1419] = { 45, 55 }, [1420] = { 1, 10 }, [1421] = { 10, 20 },
	[1422] = { 51, 58 }, [1423] = { 53, 60 }, [1424] = { 20, 30 }, [1425] = { 40, 50 }, [1426] = { 1, 10 }, [1427] = { 43, 50 },
	[1428] = { 50, 58 }, [1429] = { 1, 10 }, [1430] = { 55, 60 }, [1431] = { 18, 30 }, [1432] = { 10, 20 }, [1433] = { 15, 25 },
	[1434] = { 30, 45 }, [1435] = { 35, 45 }, [1436] = { 10, 20 }, [1437] = { 20, 30 },
}
local ZONE_HOME = {
	[1411] = "Horde", [1412] = "Horde", [1413] = "Horde", [1420] = "Horde", [1421] = "Horde", [1454] = "Horde", [1456] = "Horde", [1458] = "Horde",
	[1438] = "Alliance", [1439] = "Alliance", [1426] = "Alliance", [1429] = "Alliance", [1432] = "Alliance", [1436] = "Alliance", [1433] = "Alliance",
	[1453] = "Alliance", [1455] = "Alliance", [1457] = "Alliance",
}

local function ZoneLine()
	local ok, m = pcall(C_Map.GetBestMapForUnit, "player")
	if not ok or not m or Secret(m) then return end
	local zone = m
	local Z = Enum and Enum.UIMapType and Enum.UIMapType.Zone or 3
	for _ = 1, 6 do
		local info = C_Map.GetMapInfo(zone)
		if not info or info.mapType == Z or not info.parentMapID or info.parentMapID == 0 then break end
		local parent = C_Map.GetMapInfo(info.parentMapID)
		if not parent or parent.mapType < Z then break end    -- (don't climb to the continent)
		zone = info.parentMapID
	end
	local lo, hi = 0, 0
	if C_Map.GetMapLevels then
		local okl, a, b = pcall(C_Map.GetMapLevels, zone)
		if okl and Num(a) and Num(b) and a > 0 and b >= a then lo, hi = a, b end
	end
	-- (WoW Forever's client often has no levels for a zone: the classic ranges)
	if lo == 0 and ZONE_LEVELS[zone] then lo, hi = ZONE_LEVELS[zone][1], ZONE_LEVELS[zone][2] end
	local pvp = ""
	local getPvP = (C_PvP and C_PvP.GetZonePVPInfo) or GetZonePVPInfo
	if getPvP then
		local okp, t = pcall(getPvP)
		if okp and type(t) == "string" and not Secret(t) then pvp = t end
	end
	-- (and often no answer about whose land it is: the home territories)
	if pvp == "" then
		local home = ZONE_HOME[zone]
		local okf, mine = pcall(UnitFactionGroup, "player")
		if home == "sanctuary" then pvp = "sanctuary"
		elseif home and okf and mine then pvp = (home == mine) and "friendly" or "hostile"
		elseif ZONE_LEVELS[zone] then pvp = "contested" end
	end
	return ("ZI|%d|%d|%d|%s"):format(zone, lo, hi, pvp)
end

-- Durability: the most worn piece (percent), the average, and how many are broken ("DU|min|avg|broken")
local function DurabilityLine()
	if not GetInventoryItemDurability then return end
	local lo, sum, n, broken = 100, 0, 0, 0
	for slot = 1, 18 do
		local ok, cur, max = pcall(GetInventoryItemDurability, slot)
		cur, max = ok and Num(cur), ok and Num(max)
		if cur and max and max > 0 then
			local p = cur / max * 100
			lo, sum, n = math.min(lo, p), sum + p, n + 1
			if cur == 0 then broken = broken + 1 end
		end
	end
	if n == 0 then return end
	return ("DU|%d|%d|%d"):format(math.floor(lo + 0.5), math.floor(sum / n + 0.5), broken)
end

-- The flight paths you know, as the flight master's map last showed them (PartyMapDB.taxi), and your
-- faction: "TX|faction|name;name;..." (window only)
local function TaxiSeen()
	if not (NumTaxiNodes and TaxiNodeName and TaxiNodeGetType) then return end
	local n = NumTaxiNodes() or 0
	if n == 0 then return end
	local known = {}
	for i = 1, n do
		local okn, name = pcall(TaxiNodeName, i)
		local okt, kind = pcall(TaxiNodeGetType, i)
		if okn and okt and type(name) == "string" and kind and kind ~= "NONE" and kind ~= "DISTANT" then known[#known + 1] = name end
	end
	if #known > 0 then
		PartyMapDB.taxi = PartyMapDB.taxi or {}
		for _, name in ipairs(known) do PartyMapDB.taxi[name] = true end
	end
end
function ns.TaxiLine()
	local faction = UnitFactionGroup and UnitFactionGroup("player") or ""
	local names = {}
	for name in pairs(PartyMapDB.taxi or {}) do names[#names + 1] = Clean(name):gsub(";", ",") end
	table.sort(names)
	return "TX|" .. (faction or "") .. "|" .. table.concat(names, ";")
end

-- Where your body is while you're dead or a ghost: where you died (PartyMapDB.corpse), or the game's
-- own corpse position on the map you're on; inside a dungeon (no position there) the dungeon itself
local function DiedNow()
	local u, v = WorldPos()
	if u then PartyMapDB.corpse = { u = u, v = v }
	else
		local id = InstanceNow()
		PartyMapDB.corpse = id and { inst = id } or nil
	end
end
local function CorpseLine()
	if not (UnitIsDeadOrGhost and UnitIsDeadOrGhost("player")) then PartyMapDB.corpse = nil return end
	local c = PartyMapDB.corpse
	if C_DeathInfo and C_DeathInfo.GetCorpseMapPosition and C_Map and C_Map.GetBestMapForUnit then
		local okm, m = pcall(C_Map.GetBestMapForUnit, "player")
		local ok, pos = pcall(C_DeathInfo.GetCorpseMapPosition, okm and m or 0)
		if okm and m and ok and pos and pos.GetXY then
			local okxy, x, y = pcall(pos.GetXY, pos)
			if okxy and x and y and not Secret(x) and not Secret(y) and (x > 0 or y > 0) and ns.ToWorld then
				local u, v = ns.ToWorld(m, x, y)
				if u then c = { u = u, v = v } end
			end
		end
	end
	if not c then return end
	PartyMapDB.corpse = c
	if c.inst then return "D|i|" .. c.inst end
	return ("D|%d|%d"):format(math.floor(c.u * 100000 + 0.5), math.floor(c.v * 100000 + 0.5))
end

-- Your full name: WoW Forever's UnitName gives your own character only its first name, but your
-- player frame shows the full one ("Bron Umberhide"), so read it from there
local ownName, ownNameAt = nil, -99
local function OwnFullName()
	local now = GetTime()
	if now - ownNameAt < 10 then return ownName end
	ownNameAt = now
	local first = UnitName("player")
	if not first or first == "" then return ownName end
	local function Try(fs)
		if not (fs and fs.GetText) then return end
		local ok, t = pcall(fs.GetText, fs)
		if ok and type(t) == "string" and not Secret(t) then
			t = t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("^%s+", ""):gsub("%s+$", "")
			if t:sub(1, #first + 1) == first .. " " and #t <= 40 then return t end
		end
	end
	local found = Try(_G.PlayerName) or Try(PlayerFrame and PlayerFrame.name)
	-- (else look through the player frame for a text that starts with your name and goes on)
	local function Walk(f, depth)
		if found or not f or depth > 5 then return end
		local okr, regions = pcall(function() return { f:GetRegions() } end)
		if okr then for _, r in ipairs(regions) do if not found and r.GetObjectType and r:GetObjectType() == "FontString" then found = Try(r) end end end
		local okc, kids = pcall(function() return { f:GetChildren() } end)
		if okc then for _, k in ipairs(kids) do Walk(k, depth + 1) end end
	end
	if not found and PlayerFrame then Walk(PlayerFrame, 0) end
	if found then ownName = found end
	return ownName
end

local function QuestBlob()
	local out = {}
	local quests = {}
	-- your name as you've set it (/partymap name: WoW Forever gives your own character only its first name)
	local key = ns.Markers and ns.Markers.CharKey and ns.Markers.CharKey()
	local name = (key and PartyMapDB.names and PartyMapDB.names[key]) or OwnFullName()
		or (key and PartyMapDB.learnedNames and PartyMapDB.learnedNames[key]) or UnitName("player") or "?"
	local _, class = UnitClass("player")
	local maxQ = (C_QuestLog and C_QuestLog.GetMaxNumQuestsCanAccept and C_QuestLog.GetMaxNumQuestsCanAccept()) or 0
	out[#out + 1] = ("N|%s|%d|%s|%s|%s|%d"):format(Clean(name), UnitLevel("player") or 0, class or "", Clean(GetZoneText()), Clean(GetSubZoneText()), maxQ or 0)
	local n = (C_QuestLog and C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetNumQuestLogEntries()) or (GetNumQuestLogEntries and GetNumQuestLogEntries()) or 0
	for i = 1, n do
		local title, level, isHeader, isComplete, isFailed, questID
		if C_QuestLog and C_QuestLog.GetInfo then
			local info = C_QuestLog.GetInfo(i)
			if info then
				title, level, isHeader, questID = info.title, info.level, info.isHeader, info.questID
				if questID and not isHeader then
					isComplete = C_QuestLog.IsComplete and C_QuestLog.IsComplete(questID)
					isFailed = C_QuestLog.IsFailed and C_QuestLog.IsFailed(questID)
				end
			end
		elseif GetQuestLogTitle then
			local t, lvl, _, hdr, _, comp, _, qid = GetQuestLogTitle(i)
			title, level, isHeader, isComplete, isFailed, questID = t, lvl, hdr, comp == 1, comp == -1, qid
		end
		if title and isHeader then
			out[#out + 1] = "H|" .. Clean(title)
		elseif title and questID then
			out[#out + 1] = ("Q|%d|%s|%d|%d|%d"):format(questID, Clean(title), isComplete and 1 or 0, level or 0, isFailed and 1 or 0)
			quests[#quests + 1] = { id = questID, title = Clean(title), complete = isComplete and true or false, index = i }
			Objectives(questID, i, out)
		end
	end
	logQuests = quests
	-- bags and money: B|free slots|all slots|copper
	local free, total = 0, 0
	local getFree = (C_Container and C_Container.GetContainerNumFreeSlots) or GetContainerNumFreeSlots
	local getSlots = (C_Container and C_Container.GetContainerNumSlots) or GetContainerNumSlots
	if getFree and getSlots then
		for bag = 0, (NUM_TOTAL_EQUIPPED_BAG_SLOTS or NUM_BAG_SLOTS or 4) do
			local ok, f = pcall(getFree, bag)
			local ok2, n = pcall(getSlots, bag)
			if ok and ok2 and n and n > 0 then free, total = free + (f or 0), total + n end
		end
	end
	out[#out + 1] = ("B|%d|%d|%d"):format(free, total, GetMoney and GetMoney() or 0)
	-- the dungeon you're in ("I|instanceID|name"), the bosses down this run ("X|instanceID|name"), your body
	local run = Run()
	if run.inside and run.inst then
		out[#out + 1] = ("I|%d|%s"):format(run.inst, Clean(run.name or ""))
		local okd, ds = pcall(DungeonStateLine, run.inst, run.name)
		if okd and ds then out[#out + 1] = ds end
	end
	if run.inst then for boss in pairs(run.kills or {}) do out[#out + 1] = ("X|%d|%s"):format(run.inst, Clean(boss)) end end
	local okc, dead = pcall(CorpseLine)
	if okc and dead then out[#out + 1] = dead end
	local okx, xp = pcall(XPLine)
	if okx and xp then out[#out + 1] = xp end
	local okd, du = pcall(DurabilityLine)
	if okd and du then out[#out + 1] = du end
	local okz, zi = pcall(ZoneLine)
	if okz and zi then out[#out + 1] = zi end
	-- your bound inn (where your hearthstone takes you): "HB|u|v|name" (×1e5)
	local okb, hb = pcall(ns.BindLine)
	if okb and hb then out[#out + 1] = hb end
	-- the game's (server's) clock, so the map's day and night match the game: "GT|hours|minutes"
	if GetGameTime then
		local okt, h, m = pcall(GetGameTime)
		if okt and type(h) == "number" and type(m) == "number" and not Secret(h) then out[#out + 1] = ("GT|%d|%d"):format(h, m) end
	end
	-- your role in the group: T tank, H healer, D damage (set with /partymap role, else the leader's)
	if ns.Markers and ns.Markers.Role then
		local okr, r, from = pcall(ns.Markers.Role)
		local letter = okr and ({ TANK = "T", HEALER = "H", DAMAGER = "D" })[r]
		if letter then out[#out + 1] = "RL|" .. letter .. "|" .. from end
	end
	-- which continent you're on (for distances: across the sea is another continent, not yards)
	if ns.Markers and ns.Markers.ContinentOf and C_Map and C_Map.GetBestMapForUnit then
		local m = C_Map.GetBestMapForUnit("player")
		local pos = m and C_Map.GetPlayerMapPosition and C_Map.GetPlayerMapPosition(m, "player")
		local x, y = 0.5, 0.5
		if pos and pos.GetXY then x, y = pos:GetXY() end
		local cont = m and ns.Markers.ContinentOf(m, x or 0.5, y or 0.5)
		if cont then out[#out + 1] = "C|" .. cont end
	end
	-- what you can train, and the nearest trainer (WhatsTraining)
	if ns.Markers and ns.Markers.TrainingLines then
		local ok, lines = pcall(ns.Markers.TrainingLines, WorldPos())
		if ok then for _, l in ipairs(lines) do out[#out + 1] = l end end
	end
	-- where to level next: the quests you could take, by zone, and the zones you've explored (0.16.2)
	if ns.Markers and ns.Markers.LevelNextLines then
		local ok, lines = pcall(ns.Markers.LevelNextLines)
		if ok then for _, l in ipairs(lines) do out[#out + 1] = l end end
	end
	return table.concat(out, "\n")
end

ns.QuestBlob = QuestBlob          -- (for tests)

--------------------------------------------------------------------------------
-- Sending
--------------------------------------------------------------------------------

-- channels share the strip (flags bits 5-7 say which): 0 = my quest log, 1 = my markers,
-- 2 = party members' quest logs, 3 = their markers, 4 = where they are (one person per frame,
-- each frame complete in itself, so positions that change all the time still get through)
local chans = {}
ns.ChannelsForTest = function() return chans end   -- (the tests read the strip's lines)
for i = 0, 7 do chans[i] = { blob = "", rev = 0, pages = 1, page = 0 } end
local ORDER = { 0, 1, 5, 0, 2, 5, 7, 0, 3, 5, 6, 5, 7, 0, 5 }   -- (4 goes every third frame; empty channels are skipped)
-- (7: everyone's bags, one line a frame, for the Party bags window)
-- (6: my extras for the window only: recommended quests)
-- (4 and 5 carry one complete line a frame, round and round: 4 others' positions, portraits, pins and
-- the continents' corners; 5 the places near you)
local orderPos = 0
local ShareBags, RebuildBags
local lastOthers = 0
local dirty, lastBuild = true, 0

-- your full name as a party member's game shows it (sent by their Party Map; /partymap name still wins)
ns.NameLearned = function(full)
	local key = ns.Markers and ns.Markers.CharKey and ns.Markers.CharKey()
	if not key then return end
	PartyMapDB.learnedNames = PartyMapDB.learnedNames or {}
	if PartyMapDB.learnedNames[key] ~= full then
		PartyMapDB.learnedNames[key] = full
		dirty = true
	end
end

local markersDirty, lastMarkers = true, 0
local MARKERS_EVERY, MARKERS_REFRESH = 1, 10   -- seconds: soonest after a change, and a regular refresh
local seq, elapsed = 0, 0
local lastU, lastV

local function SetBlob(c, b)
	if b == c.blob then return end
	c.blob = b
	c.rev = (c.rev + 1) % 65536
	c.pages = math.max(1, math.ceil(#b / E.CHUNK_MAX))
	c.page = 0
	-- (just changed: it gets two frames in three until it has gone round twice; friends' quest logs
	-- and markers, which are long in a big party, once)
	c.boost = (c == chans[2] or c == chans[3]) and 1 or 2
end

local function Rebuild()
	local ok, b = pcall(QuestBlob)
	if ok then
		SetBlob(chans[0], b)
		if ns.Comms then pcall(ns.Comms.SetMine, "q", b) end
	end
	dirty, lastBuild = false, GetTime()
	markersDirty = true
end

local function RebuildMarkers()
	if not ns.Markers then return end
	local ok, b = pcall(ns.Markers.Build, logQuests, lastU, lastV)
	if ok then
		SetBlob(chans[1], b or "")
		if ns.Comms then pcall(ns.Comms.SetMine, "m", b or "") end
	end
	markersDirty, lastMarkers = false, GetTime()
end

-- where a unit's portrait is on screen, so the app can cut it out for the map: "A|name|x|y|w|h", in
-- pixels from the strip's top-left corner. Blizzard's own unit frames only (old and new layouts).
-- Portraits for the app: our own pictures of you, each party member and the NPC you target
-- (SetPortraitTexture: just the face, no unit frame, overlay, "Dead" text or other addon in the
-- way), shown for a moment just beside the strip where the app knows exactly where to look.
-- A person's picture is taken once, then again only when they change form (a druid shifting, say;
-- a friend's form comes from their Party Map): it never changes by itself. (The app keeps the
-- pictures on disk between runs.) Nothing is shown while the world map is open.
local SLOT, GAP, SHOW, SETTLE = 44, 4, 1.8, 1.2
local slots = {}          -- [key] = { f, tex, shownAt, look, pending, lookSince, line }
local function Slot(key)
	local sl = slots[key]
	if not sl then
		local f = CreateFrame("Frame", nil, frame)
		f:SetSize(SLOT, SLOT)
		f:SetFrameStrata("TOOLTIP")
		f:SetFrameLevel(frame:GetFrameLevel() + 2)
		local bg = f:CreateTexture(nil, "BACKGROUND")
		bg:SetAllPoints()
		bg:SetColorTexture(0, 0, 0, 1)
		local tex = f:CreateTexture(nil, "ARTWORK")
		tex:SetAllPoints()
		f:Hide()
		sl = { f = f, tex = tex, shownAt = -99 }
		slots[key] = sl
	end
	return sl
end
-- /partymap faces: take everyone's picture again (if the app wasn't running the first time)
ns.RetakePortraits = function()
	for k, sl in pairs(slots) do if k ~= "target" then sl.look = nil end end
	PartyMapDB.npcShot = {}
end
-- (0.15.7) creatures already shown for a picture: each kind once, not every new one you target
local NPC_SHOT_MAX = 5000
local function NPCShot(id)
	local t = PartyMapDB.npcShot
	if type(t) ~= "table" then t = {}; PartyMapDB.npcShot = t end
	return t[id] == true
end
local function MarkNPCShot(id)
	local t = PartyMapDB.npcShot
	if type(t) ~= "table" then t = {}; PartyMapDB.npcShot = t end
	if not t[id] then
		t.n = (tonumber(t.n) or 0) + 1
		if t.n > NPC_SHOT_MAX then t = { n = 1 }; PartyMapDB.npcShot = t end
		t[id] = true
	end
end

local function ShowSlot(sl, idx, unit, name, now, form)
	if not (UnitExists and UnitExists(unit)) or not SetPortraitTexture then return end
	if not pcall(SetPortraitTexture, sl.tex, unit) then return end
	local x = (idx - 1) * (SLOT + GAP)
	local below = PartyMapDB.corner == "tl" or PartyMapDB.corner == "tr"
	sl.f:ClearAllPoints()
	local y
	if below then sl.f:SetPoint("TOPLEFT", frame, "BOTTOMLEFT", x, -GAP); y = 1 + GAP
	else sl.f:SetPoint("BOTTOMLEFT", frame, "TOPLEFT", x, GAP); y = -(GAP + SLOT) end
	sl.f:Show()
	sl.shownAt = now
	-- (the form it shows: the app keeps one picture per form, so shifting swaps straight to it)
	sl.line = ("A|%s|%d|%d|%d|%d|%s"):format(name, x, y, SLOT, SLOT, form or "")
end

local targetSince, targetShown = 0, nil
ns.TargetChanged = function() targetSince = GetTime() end

-- the portrait lines for this moment (and showings started or ended)
local function PortraitLines(now, names)
	local out = {}
	local covered = WorldMapFrame and WorldMapFrame.IsShown and WorldMapFrame:IsShown()
	-- look: what decides the picture (the form they're in); a picture is taken when it's new and has
	-- settled for a moment (so flicking through forms doesn't take one for each)
	local function Want(key, idx, unit, name, look, form)
		local sl = Slot(key)
		if sl.f:IsShown() then
			if now - sl.shownAt > SHOW then sl.f:Hide() else out[#out + 1] = sl.line end
			return
		end
		if look ~= sl.pending then sl.pending, sl.lookSince = look, now end
		if covered or sl.look == look or now - sl.lookSince < SETTLE then return end
		sl.look = look
		ShowSlot(sl, idx, unit, name, now, form)
	end
	local myForm = tostring(GetShapeshiftFormID and GetShapeshiftFormID() or 0)
	Want("me", 1, "player", "", myForm, myForm)
	for _, name in ipairs(names) do
		local o = ns.Others[name]
		local unit = o.unit
		if name:find(" %(echo%)$") then unit = "player" end   -- test mode: borrow your own face
		local n = unit and (tonumber(unit:match("^party(%d)$")) or (unit == "player" and 1))
		-- (their name is part of it too: a picture taken before their full name arrived is filed
		-- under the short one, so it's taken again once the full name is known)
		local shown = (o.display or name):sub(1, 40)
		local form = unit == "player" and myForm or (o.form and tostring(o.form) or "")
		local look = (form ~= "" and form or "?") .. "|" .. shown
		if n then Want("p:" .. name, n + 1, unit, shown, look, form) end
	end
	-- the NPC you're targeting (after a moment on it, so a quick tab-through isn't photographed)
	local tsl = Slot("target")
	if tsl.f:IsShown() then
		if now - tsl.shownAt > SHOW or not UnitExists("target") then tsl.f:Hide() else out[#out + 1] = tsl.line end
	elseif not covered and PartyMapDB.npcFaces ~= false and now - targetSince >= 0.6 and UnitExists("target") and not UnitIsPlayer("target")
		and not ((InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player"))) then
		local ok, guid = pcall(UnitGUID, "target")
		if ok and type(guid) == "string" and not Secret(guid) and guid ~= targetShown then
			local kind, _, _, _, _, id = strsplit("-", guid)
			if kind == "Creature" and tonumber(id) and NPCShot(tonumber(id)) then
				targetShown = guid
			elseif kind == "Creature" and tonumber(id) and not (UnitIsDead and UnitIsDead("target")) then
				targetShown = guid
				MarkNPCShot(tonumber(id))
				ShowSlot(tsl, 6, "target", "npc:" .. id, now)
			end
		end
	end
	return out
end
local lastCorners, cornerLines = 0, {}
local lastPlaces, placesU, placesV = 0, nil, nil

-- channel 5: the places near you, rebuilt when you've moved on (or every 20 s)
local function RebuildPlaces(now, u, v)
	if not (ns.Markers and ns.Markers.PlacesNear) or not u then return end
	if now - lastPlaces < 2 then return end
	local moved = not placesU or (u - placesU) ^ 2 + (v - placesV) ^ 2 > 0.01 * 0.01
	if not moved and now - lastPlaces < 20 then return end
	lastPlaces, placesU, placesV = now, u, v
	local c5 = chans[5]
	c5.lines = ns.Markers.PlacesNear(u, v)
	-- gathering spots and rares near you
	for _, fn in ipairs({ "NodesNear", "RaresNear", "LightsNear" }) do
		if ns.Markers[fn] then
			local ok, list = pcall(ns.Markers[fn], u, v)
			if ok then for _, l in ipairs(list) do c5.lines[#c5.lines + 1] = l end end
		end
	end
	-- and the zones' rectangles (for dungeon entrances given on a zone's map)
	if ns.Markers.Zones then
		local ok, zl = pcall(ns.Markers.Zones)
		if ok then for _, l in ipairs(zl) do c5.lines[#c5.lines + 1] = l end end
	end
	c5.blob = table.concat(c5.lines, "\n")
	c5.pages = math.max(1, #c5.lines)
	if c5.page >= c5.pages then c5.page = 0 end
end

-- channel 6: quests worth picking up near you (and the ones friends are on), every few seconds
local lastRec, lastGear, gearDirty, gearLines = 0, 0, true, {}
local function RebuildRecommend(now, u, v)
	if not (ns.Markers and ns.Markers.Recommend) or now - lastRec < (gearDirty and 1 or 5) then return end
	lastRec = now
	local friends = {}
	for _, o in pairs(ns.Others or {}) do
		for id in (o.quests or ""):gmatch("Q|(%d+)|") do friends[tonumber(id)] = true end
	end
	local ok, lines = pcall(ns.Markers.Recommend, u or lastU, v or lastV, UnitLevel("player") or 0, friends)
	lines = ok and lines or {}
	-- gear upgrades: rebuilt when the log, your gear or item info changes (or every 30 s)
	if ns.Markers.Gear and (gearDirty or now - lastGear > 30) then
		local _, class = UnitClass("player")
		local okg, g = pcall(ns.Markers.Gear, logQuests, UnitLevel("player") or 1, class)
		if okg then gearLines = g end
		gearDirty, lastGear = false, now
	end
	local all = {}
	for _, l in ipairs(lines) do all[#all + 1] = l end
	for _, l in ipairs(gearLines) do all[#all + 1] = l end
	if ns.Markers.UprankLines then local oku, ul = pcall(ns.Markers.UprankLines); if oku then for _, l in ipairs(ul) do all[#all + 1] = l end end end
	local okm, dm = pcall(ns.DungeonMarkLines, PartyMapDB and PartyMapDB.run)
	if okm then for _, l in ipairs(dm) do all[#all + 1] = l end end
	local okt, tx = pcall(ns.TaxiLine)
	if okt and tx then all[#all + 1] = tx end
	SetBlob(chans[6], table.concat(all, "\n"))
end

-- what's known of party members (and friends sharing through OpenMap), for channels 2-4
local function RebuildOthers(now)
	local q, m, p = {}, {}, {}
	local names = {}
	for name in pairs(ns.Others or {}) do names[#names + 1] = name end
	table.sort(names)
	for _, name in ipairs(names) do
		local o = ns.Others[name]
		local shown = o.display or name
		if o.quests and o.quests ~= "" then q[#q + 1] = "W|" .. shown; q[#q + 1] = o.quests end
		if o.markers and o.markers ~= "" then m[#m + 1] = "W|" .. shown; m[#m + 1] = o.markers end
		local u, v, facing, src, age = ns.Comms.Best(o, now)
		if u then
			-- the role the game gives them in the group (works without their addon)
			local role = ""
			local unit = o.unit or (name:find(" %(echo%)$") and "player")
			if unit and UnitGroupRolesAssigned then
				local okr, r = pcall(UnitGroupRolesAssigned, unit)
				role = okr and ({ TANK = "T", HEALER = "H", DAMAGER = "D" })[r] or ""
			end
			local line = ("P|%s|%d|%d|%d|%d|%d|%s|%d|%s|%d|%s"):format(shown, math.floor(u * 100000 + 0.5), math.floor(v * 100000 + 0.5),
				facing and math.floor(facing * 1000 + 0.5) or -1, o.mapID or 0, o.flags or 0, o.class or "", o.level or 0, src, math.min(999, math.floor(age + 0.5)), role)
			-- their Party Map version, so the map can say when a friend's is older (only when it fits whole)
			local ver = o.pm and o.version
			if type(ver) == "string" and ver:match("^%d+%.%d+%.%d+$") and #line + #ver + 1 <= E.CHUNK_MAX then line = line .. "|" .. ver end
			p[#p + 1] = line:sub(1, E.CHUNK_MAX)
		end
	end
	for _, line in ipairs(PortraitLines(now, names)) do p[#p + 1] = line:sub(1, E.CHUNK_MAX) end
	-- this addon's version, its strip format and the errors it has caught ("V|0.15.0|1|0"), for the app's health check
	p[#p + 1] = ("V|%s|%d|%d"):format(ns.VERSION or "?", ns.STRIP_FORMAT or 1, ns.errors and ns.errors.n or 0)
	-- someone in the group runs a newer Party Map: the app fetches it ("NV|0.15.4")
	local newest = ns.Comms.NewestPeer and ns.Comms.NewestPeer()
	if newest then p[#p + 1] = "NV|" .. newest end
	-- everyone's form right now ("FM|name|form", name "" = you): the map swaps to that form's picture at once
	p[#p + 1] = "FM||" .. tostring(GetShapeshiftFormID and GetShapeshiftFormID() or 0)
	for _, name in ipairs(names) do
		local o = ns.Others[name]
		if o.form and not name:find(" %(echo%)$") then
			p[#p + 1] = ("FM|%s|%d"):format((o.display or name):sub(1, 40), tonumber(o.form) or 0)
		end
	end
	-- your role, in a line of its own so a change shows within a moment ("RL|T|party")
	if ns.Markers and ns.Markers.Role then
		local okr, r, from = pcall(ns.Markers.Role)
		local letter = okr and ({ TANK = "T", HEALER = "H", DAMAGER = "D" })[r]
		p[#p + 1] = letter and ("RL|" .. letter .. "|" .. from) or "RL|-|"
	end
	-- the last mailbox you opened ("MB|time|place": the app posts your postcards)
	local mb = PartyMapDB and PartyMapDB.mailbox
	if mb and mb.t then p[#p + 1] = ("MB|%d|%s"):format(mb.t, mb.at or ""):sub(1, E.CHUNK_MAX) end
	-- pins: mine and the party's ("K|by|id|u|v|label")
	local me = (UnitName("player") or ""):gsub("%-.*$", "")
	for _, pin in ipairs(ns.Comms.myPins or {}) do
		p[#p + 1] = ("K|%s|%d|%d|%d|%s"):format(me, pin.id, math.floor(pin.u * 100000 + 0.5), math.floor(pin.v * 100000 + 0.5), pin.label):sub(1, E.CHUNK_MAX)
	end
	for _, name in ipairs(names) do
		local o = ns.Others[name]
		for _, pin in ipairs(o.pins or {}) do
			p[#p + 1] = ("K|%s|%d|%d|%d|%s"):format(o.display or name, pin.id, math.floor(pin.u * 100000 + 0.5), math.floor(pin.v * 100000 + 0.5), pin.label):sub(1, E.CHUNK_MAX)
		end
	end
	if now - lastCorners > 10 or #cornerLines == 0 and now - lastCorners > 2 then
		lastCorners = now
		cornerLines = ns.Markers and ns.Markers.Corners and ns.Markers.Corners() or {}
	end
	for _, line in ipairs(cornerLines) do p[#p + 1] = line end
	-- rares SilverDragon has just seen
	if ns.Markers and ns.Markers.SeenRareLines then
		local ok, list = pcall(ns.Markers.SeenRareLines)
		if ok then for _, l in ipairs(list) do p[#p + 1] = l:sub(1, E.CHUNK_MAX) end end
	end
	SetBlob(chans[2], table.concat(q, "\n"))
	SetBlob(chans[3], table.concat(m, "\n"))
	local c4 = chans[4]
	c4.lines = p
	c4.blob = table.concat(p, "\n")
	c4.pages = math.max(1, #p)
	if c4.page >= c4.pages then c4.page = 0 end
end

--------------------------------------------------------------------------------
-- Bags: yours go to the party (unless /partymap bags off), and everyone's go to the Party bags
-- window on channel 7:
--   BG|who|bag|size|first|slot,slot,...   who "" = you; a slot "itemID", "itemID*count" or "" (empty)
--   BO|who                                 they've switched sharing off
--   BI|itemID|quality|iconFileID|sellPrice|classID|name   what an item is (always in the round)
-- (lines that are new or changed go to the front, so a sale or a potion drunk shows within a moment)
--------------------------------------------------------------------------------
local function Split(s, sep)
	local out, i = {}, 1
	while true do
		local j = s:find(sep, i, true)
		if not j then out[#out + 1] = s:sub(i); return out end
		out[#out + 1] = s:sub(i, j - 1)
		i = j + 1
	end
end

local function BagSize(bag)
	if C_Container and C_Container.GetContainerNumSlots then return C_Container.GetContainerNumSlots(bag) or 0 end
	return GetContainerNumSlots and GetContainerNumSlots(bag) or 0
end

local function BagItem(bag, slot)
	if C_Container and C_Container.GetContainerItemInfo then
		local info = C_Container.GetContainerItemInfo(bag, slot)
		if type(info) == "table" and info.itemID then return info.itemID, info.stackCount end
		return
	end
	if GetContainerItemInfo then
		local _, count, _, _, _, _, link, _, _, id = GetContainerItemInfo(bag, slot)
		id = id or (type(link) == "string" and tonumber(link:match("item:(%d+)")))
		if id then return id, count end
	end
end

local function MyBags()
	local out = {}
	for bag = 0, 4 do
		local n = BagSize(bag)
		if n and n > 0 then
			local s = {}
			for slot = 1, n do
				local id, count = BagItem(bag, slot)
				count = tonumber(count) or 1
				s[slot] = id and (count > 1 and (id .. "*" .. count) or tostring(id)) or ""
			end
			out[#out + 1] = bag .. "|" .. n .. "|" .. table.concat(s, ",")
		end
	end
	return table.concat(out, "\n")
end
ns.MyBags = MyBags                  -- (for tests)

local bagsDirty, lastScan, lastBagsSent, myBags, sentBags = true, -10, -10, "", nil
local lastBagLines = -10
ns.BagsChanged = function() bagsDirty = true end
ShareBags = function(now)
	-- yours: looked at again just after a change (and every 4 s anyway, in case an event was missed);
	-- a change goes onto the strip straight away
	if (bagsDirty and now - lastScan >= 0.3) or now - lastScan >= 4 then
		bagsDirty, lastScan = false, now
		local ok, b = pcall(MyBags)
		if ok and b ~= myBags then myBags = b; lastBagLines = -10 end
	end
	-- to the party: at most every 3 s
	local share = PartyMapDB.bags == false and "off" or myBags
	if share ~= sentBags and now - lastBagsSent >= 3 then
		sentBags, lastBagsSent = share, now
		if ns.Comms then pcall(ns.Comms.SetMine, "b", share) end
	end
end

local function BagLines(out, who, text, items)
	if text == "off" then out[#out + 1] = ("BO|%s"):format(who); return end
	for line in text:gmatch("[^\n]+") do
		local bag, size, slots = line:match("^(%d+)|(%d+)|(.*)$")
		if bag then
			local list = Split(slots, ",")
			local first = 1
			while first <= #list do
				local head = ("BG|%s|%s|%s|%d|"):format(who, bag, size, first)
				local parts, len, i = {}, #head, first
				while i <= #list do
					local add = #list[i] + (i > first and 1 or 0)
					if len + add > E.CHUNK_MAX then break end
					parts[#parts + 1] = list[i]
					len, i = len + add, i + 1
				end
				if i == first then break end
				out[#out + 1] = head .. table.concat(parts, ",")
				first = i
			end
			for _, sl in ipairs(list) do
				local id = tonumber(sl:match("^(%d+)"))
				if id then items[id] = true end
			end
		end
	end
end

local itemSent, lastItemReset, prevLines, othersBagsT = {}, 0, {}, 0
function ns.ItemPainted(line)
	local id = tonumber(line:match("^BI|(%d+)|"))
	if id then itemSent[id] = (itemSent[id] or 0) + 1 end
end

-- (WoW Forever's client is a modern one: GetItemInfo and friends live in C_Item there)
local function ItemLine(id)
	local info = (C_Item and C_Item.GetItemInfo) or GetItemInfo
	local instant = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
	if not info then return end
	local name, _, q, _, _, _, _, _, _, icon, price = info(id)
	if not name then
		if C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
		return
	end
	local classID
	if instant then
		local r = { pcall(instant, id) }
		if r[1] then
			if not tonumber(icon) then icon = r[6] end
			classID = tonumber(r[7])
		end
	end
	if not tonumber(icon) and C_Item and C_Item.GetItemIconByID then icon = C_Item.GetItemIconByID(id) end
	return ("BI|%d|%d|%d|%d|%d|%s"):format(id, tonumber(q) or 1, tonumber(icon) or 0, tonumber(price) or 0, classID or -1,
		(name:gsub("|", ""))):sub(1, E.CHUNK_MAX)
end

RebuildBags = function(now)
	local newest = 0
	for _, o in pairs(ns.Others or {}) do if (o.bagsT or 0) > newest then newest = o.bagsT end end
	if newest ~= othersBagsT then othersBagsT, lastBagLines = newest, -10 end   -- (a friend's bags changed)
	if now - lastBagLines < 2 then return end
	lastBagLines = now
	local out, items = {}, {}
	BagLines(out, "", myBags, items)
	local names = {}
	for name, o in pairs(ns.Others or {}) do if o.bags then names[#names + 1] = name end end
	table.sort(names)
	for _, name in ipairs(names) do
		local o = ns.Others[name]
		BagLines(out, ((o.display or name):gsub("|", "")):sub(1, 30), o.bags, items)
	end
	-- what each item is: always in the round (the app may not have been running when it last went by;
	-- it keeps them, and lines it already knows cost a moment each)
	local ids = {}
	for id in pairs(items) do ids[#ids + 1] = id end
	table.sort(ids)
	local named = 0
	for _, id in ipairs(ids) do
		local ok, l = pcall(ItemLine, id)
		if ok and l then out[#out + 1] = l; named = named + 1 end
	end
	ns.bagNames = { #ids, named }
	-- new or changed lines first, and start the round again with them
	local seen, fresh, rest = {}, {}, {}
	for _, l in ipairs(out) do
		seen[l] = true
		if prevLines[l] then rest[#rest + 1] = l else fresh[#fresh + 1] = l end
	end
	prevLines = seen
	local c7 = chans[7]
	if #fresh > 0 then
		out = fresh
		for _, l in ipairs(rest) do out[#out + 1] = l end
		c7.page = 0
	end
	c7.lines = out
	c7.blob = table.concat(out, "\n")
	c7.pages = math.max(1, #out)
	if c7.page >= c7.pages then c7.page = 0 end
end

local boostTurn = 0
local function NextChannel()
	if seq % 3 == 0 and #chans[4].blob > 0 then return 4 end
	-- a channel that's just changed (new quests, objectives done, markers moved) goes first, so the
	-- window has it within seconds: quest logs before markers (the counts are what people watch),
	-- yours before your friends', on two frames of every three
	boostTurn = (boostTurn + 1) % 3
	if boostTurn ~= 0 then
		for _, ch in ipairs({ 0, 2, 1, 3, 6 }) do
			local c = chans[ch]
			if (c.boost or 0) > 0 and #c.blob > 0 then return ch end
		end
	end
	for _ = 1, #ORDER do
		orderPos = orderPos % #ORDER + 1
		local ch = ORDER[orderPos]
		if ch == 0 or #chans[ch].blob > 0 then return ch end
	end
	return 0
end

local maxGrey = E.MAX
local painted = {}   -- the level each cell shows now (cleared when the brightness changes)

local function Paint()
	local now = GetTime()
	if dirty and now - lastBuild >= REBUILD then Rebuild() end
	if (markersDirty and now - lastMarkers >= MARKERS_EVERY) or now - lastMarkers >= MARKERS_REFRESH then RebuildMarkers() end
	local u, v, mapID = WorldPos()
	if u then lastU, lastV = u, v end
	local W, H = WorldSize()
	local facing, flags = Facing(), Flags()
	if ns.Comms then
		pcall(ns.Comms.Tick, now, u, v, facing, mapID, flags)
		pcall(ns.Comms.ScanParty, now)
		if now - lastOthers >= 0.05 then lastOthers = now; pcall(RebuildOthers, now) end
		pcall(RebuildPlaces, now, u, v)
	end
	pcall(RebuildRecommend, now, u, v)
	if ns.Markers and ns.Markers.LevelNextStep then
		local okl, changed = pcall(ns.Markers.LevelNextStep, now, UnitLevel("player") or 0)
		if okl and changed then dirty = true end
	end
	pcall(ShareBags, now)
	pcall(RebuildBags, now)
	local ch = NextChannel()
	local c = chans[ch]
	local chunk
	if ch == 4 or ch == 5 or ch == 7 then
		chunk = (c.lines and c.lines[c.page + 1]) or ""
		if ch == 7 and chunk:sub(1, 3) == "BI|" then ns.ItemPainted(chunk) end
	else
		chunk = c.blob:sub(c.page * E.CHUNK_MAX + 1, (c.page + 1) * E.CHUNK_MAX)
	end
	local bytes = E.BuildFrame({
		seq = seq, rev = c.rev, page = c.page, pages = c.pages,
		u = u, v = v, facing = facing, mapID = mapID, W = W, H = H, flags = flags + ch * 32, chunk = chunk,
	})
	local levels = E.Cells(bytes)
	for i = 1, E.CELLS do
		local lv = levels[i]
		if painted[i] ~= lv then
			painted[i] = lv
			local g = lv / 7 * maxGrey
			cells[i]:SetColorTexture(g, g, g, 1)
		end
	end
	seq = (seq + 1) % 256
	c.page = (c.page + 1) % c.pages
	if c.page == 0 and (c.boost or 0) > 0 then c.boost = c.boost - 1 end
end

frame:SetScript("OnUpdate", function(_, dt)
	elapsed = elapsed + dt
	if elapsed < UPDATE then return end
	elapsed = 0
	-- (never an error pop-up every frame: counted instead, for /partymap check)
	local ok, e = pcall(Paint)
	if not ok and ns.Err then ns.Err("paint", e) end
end)

-- with the strip switched off (/partymap off: someone with no Party Map window, say), the party still
-- gets your position, quests, markers, pins and bags
local partyOnly, partyElapsed = CreateFrame("Frame"), 0
partyOnly:SetScript("OnUpdate", function(_, dt)
	if frame:IsShown() then return end
	partyElapsed = partyElapsed + dt
	if partyElapsed < 0.1 then return end
	partyElapsed = 0
	local now = GetTime()
	if dirty and now - lastBuild >= REBUILD then pcall(Rebuild) end
	if (markersDirty and now - lastMarkers >= MARKERS_EVERY) or now - lastMarkers >= MARKERS_REFRESH then pcall(RebuildMarkers) end
	local u, v, mapID = WorldPos()
	if u then lastU, lastV = u, v end
	if ns.Comms then
		pcall(ns.Comms.Tick, now, u, v, Facing(), mapID, Flags())
		pcall(ns.Comms.ScanParty, now)
	end
	pcall(ShareBags, now)
end)

-- Alt+click on the world map drops a pin there for the party
local hooked = false
local function HookMapClicks()
	if hooked or not WorldMapFrame or not WorldMapFrame.ScrollContainer then return end
	hooked = true
	WorldMapFrame.ScrollContainer:HookScript("OnMouseUp", function(_, button)
		if button ~= "LeftButton" or not IsAltKeyDown() or not ns.Comms then return end
		local u, v
		if OpenMapAPI and OpenMapAPI.CursorPosition then
			local ok, a, b = pcall(OpenMapAPI.CursorPosition)
			if ok then u, v = a, b end
		end
		if not u and WorldMapFrame.GetNormalizedCursorPosition and WorldMapFrame.GetMapID then
			local x, y = WorldMapFrame:GetNormalizedCursorPosition()
			if x and y then u, v = ns.ToWorld(WorldMapFrame:GetMapID(), x, y) end
		end
		if u and ns.Comms.AddPin(u, v, "") then print("|cffF0B04AParty Map|r pin dropped for your party (/partymap pins clear to remove them).") end
	end)
end

-- a mailbox: your postcards (drafts in the app) go in the post, postmarked from here
local function MailboxOpened()
	if not time then return end
	local zone = GetRealZoneText and GetRealZoneText() or (GetZoneText and GetZoneText()) or ""
	local sub = GetSubZoneText and GetSubZoneText() or ""
	if Secret(zone) then zone = "" end
	if Secret(sub) then sub = "" end
	local place = zone
	if sub ~= "" and sub ~= zone then place = (zone ~= "" and (sub .. ", " .. zone) or sub) end
	PartyMapDB.mailbox = { t = time(), at = (place:gsub("|", "")) }
	dirty = true
end

local events = CreateFrame("Frame")
for _, ev in ipairs({ "PLAYER_LOGIN", "QUEST_LOG_UPDATE", "QUEST_ACCEPTED", "QUEST_REMOVED", "QUEST_TURNED_IN",
	"UNIT_QUEST_LOG_CHANGED", "ZONE_CHANGED", "ZONE_CHANGED_NEW_AREA", "ZONE_CHANGED_INDOORS", "PLAYER_LEVEL_UP",
	"DISPLAY_SIZE_CHANGED", "UI_SCALE_CHANGED", "BAG_UPDATE_DELAYED", "PLAYER_MONEY",
	"PLAYER_ENTERING_WORLD", "PLAYER_DEAD", "PLAYER_ALIVE", "PLAYER_UNGHOST", "ENCOUNTER_END", "BOSS_KILL",
	"PLAYER_XP_UPDATE", "UPDATE_EXHAUSTION", "PLAYER_EQUIPMENT_CHANGED", "GET_ITEM_INFO_RECEIVED", "CHARACTER_POINTS_CHANGED",
	"UPDATE_INVENTORY_DURABILITY", "TAXIMAP_OPENED", "SPELLS_CHANGED", "LEARNED_SPELL_IN_TAB", "PLAYER_REGEN_ENABLED",
	"PLAYER_TARGET_CHANGED", "BAG_UPDATE", "PLAYER_ROLES_ASSIGNED", "GROUP_ROSTER_UPDATE", "MAIL_SHOW", "PLAYER_REGEN_DISABLED", "INSTANCE_ENCOUNTER_ENGAGE_UNIT", "HEARTHSTONE_BOUND" }) do
	pcall(events.RegisterEvent, events, ev)
end
local function OnEvent(_, ev, ...)
	if ev == "ADDON_LOADED" then
		if ... == addonName then ns.CheckDB() end
		return
	end
	if ev == "MAIL_SHOW" then pcall(MailboxOpened) return end
	if ev == "HEARTHSTONE_BOUND" then pcall(HearthBound); dirty = true; return end
	if ev == "BAG_UPDATE_DELAYED" or ev == "BAG_UPDATE" or ev == "PLAYER_ENTERING_WORLD" then ns.BagsChanged() end
	if ev == "BAG_UPDATE" then return end
	if ev == "PLAYER_ROLES_ASSIGNED" or ev == "GROUP_ROSTER_UPDATE" then
		if ev == "PLAYER_ROLES_ASSIGNED" or ns.lastRole ~= (ns.Markers.Role()) then gearDirty = true; dirty = true end
		ns.lastRole = ns.Markers.Role()
		if ev == "PLAYER_ROLES_ASSIGNED" then return end
	end
	if ev == "PLAYER_EQUIPMENT_CHANGED" or ev == "GET_ITEM_INFO_RECEIVED" or ev == "CHARACTER_POINTS_CHANGED" or ev == "QUEST_LOG_UPDATE" or ev == "PLAYER_LEVEL_UP" then
		gearDirty = true
		if ev == "GET_ITEM_INFO_RECEIVED" then return end   -- (lots of these: the gear list picks them up)
	end
	if ev == "TAXIMAP_OPENED" then pcall(TaxiSeen) end
	if (ev == "PLAYER_TARGET_CHANGED" or ev == "PLAYER_REGEN_ENABLED" or ev == "PLAYER_REGEN_DISABLED" or ev == "INSTANCE_ENCOUNTER_ENGAGE_UNIT")
		and PartyMapDB and PartyMapDB.run and PartyMapDB.run.inside then dirty = true end
	if ev == "PLAYER_REGEN_DISABLED" or ev == "INSTANCE_ENCOUNTER_ENGAGE_UNIT" then return end
	if ev == "PLAYER_TARGET_CHANGED" then ns.TargetChanged() return end
	-- new spell ranks onto your bars (a moment after the spellbook settles), and anything held back by combat
	if ev == "SPELLS_CHANGED" or ev == "LEARNED_SPELL_IN_TAB" then
		if C_Timer and not ns.rankTimer then
			ns.rankTimer = true
			C_Timer.After(0.5, function() ns.rankTimer = nil; pcall(ns.Markers.CheckRanks) end)
		end
		if ev == "SPELLS_CHANGED" then return end
	elseif ev == "PLAYER_REGEN_ENABLED" then
		pcall(ns.Markers.RetryRanks)
		return
	end
	if ev == "PLAYER_DEAD" then pcall(DiedNow)
	elseif ev == "ENCOUNTER_END" then
		local _, name, _, _, success = ...
		pcall(function() if not Secret(success) and (success == 1 or success == true) then BossKilled(name) end end)
	elseif ev == "BOSS_KILL" then
		local _, name = ...
		pcall(BossKilled, name)
	elseif ev == "PLAYER_XP_UPDATE" or ev == "PLAYER_LEVEL_UP" then
		pcall(XPChanged)
		if ev == "PLAYER_LEVEL_UP" then
			local level = ...
			level = Num(level)
			if level and time then XPState().dings[level] = time() end
		end
	elseif ev == "QUEST_TURNED_IN" then
		local _, xp = ...
		pcall(QuestXP, xp)
	end
	if (ev == "QUEST_TURNED_IN" or ev == "QUEST_ACCEPTED" or ev == "QUEST_REMOVED" or ev == "PLAYER_LEVEL_UP") and ns.Markers and ns.Markers.LevelNextDirty then
		pcall(ns.Markers.LevelNextDirty)
	end
	if ev == "PLAYER_LOGIN" or ev == "PLAYER_ENTERING_WORLD" then pcall(XPChanged) end
	if ev == "PLAYER_LOGIN" then
		if PartyMapDB.on == nil then PartyMapDB.on = true end
		-- (the game clock moves on: send it again every few minutes)
		if C_Timer and C_Timer.NewTicker then C_Timer.NewTicker(240, function() dirty = true end) end
		maxGrey = PartyMapDB.bright and E.MAX_BRIGHT or E.MAX
		for k in pairs(painted) do painted[k] = nil end
		Layout()
		frame:SetShown(PartyMapDB.on)
		rectCache = {}
		if ns.Markers and ns.Markers.BuildPlaces and C_Timer then
			ns.Markers.onPlaces = function() lastPlaces, placesU = 0, nil end
			C_Timer.After(8, ns.Markers.BuildPlaces)   -- (after Questie's database has loaded)
		end
		HookMapClicks()
		if C_Timer then
			C_Timer.After(15, function()
				local ok, _, wrong = pcall(ns.CheckReport)
				if ok and wrong and #wrong > 0 then
					print("|cffF0B04AParty Map|r " .. table.concat(wrong, "; ") .. ". /partymap check for more.")
				end
			end)
		end
		-- hybrids: say once per character how to choose a role for gear upgrades
		local _, cls = UnitClass("player")
		if C_Timer and ({ DRUID = true, SHAMAN = true, PALADIN = true, WARRIOR = true, PRIEST = true })[cls] then
			C_Timer.After(12, function()
				PartyMapDB.roleHint = PartyMapDB.roleHint or {}
				local key = ns.Markers.CharKey()
				if not ns.Markers.Role() and not PartyMapDB.roleHint[key] then
					PartyMapDB.roleHint[key] = true
					print("|cffF0B04AParty Map|r gear upgrades follow your talents until you choose a role: /partymap role tank, healer or dps.")
				end
			end)
		end
		if ns.Markers.HookSilverDragon then pcall(ns.Markers.HookSilverDragon) end
		-- WhatsTraining: rebuild when what you can learn changes; a note in chat on levelling up
		local api = rawget(_G, "WT_API")
		if api and api.RegisterCallback and not ns.wtHooked then
			ns.wtHooked = true
			local function Changed() dirty = true end
			pcall(api.RegisterCallback, ns, "Ready", Changed)
			pcall(api.RegisterCallback, ns, "SpellsChanged", Changed)
			pcall(api.RegisterCallback, ns, "LevelChanged", function(_, level)
				dirty = true
				if C_Timer then C_Timer.After(1, function() pcall(ns.Markers.TrainingNote, level, WorldPos()) end) end
			end)
		end
	elseif ev == "DISPLAY_SIZE_CHANGED" or ev == "UI_SCALE_CHANGED" then
		Layout()
	end
	dirty = true
end
pcall(events.RegisterEvent, events, "ADDON_LOADED")
events:SetScript("OnEvent", function(...)
	local ok, e = pcall(OnEvent, ...)
	if not ok and ns.Err then ns.Err("event", e) end
end)

SLASH_PARTYMAP1 = "/partymap"
local Slash
SlashCmdList.PARTYMAP = function(msg)
	local ok, e = pcall(Slash, msg)
	if not ok then
		if ns.Err then ns.Err("slash", e) end
		print("|cffF0B04AParty Map|r that didn't work (" .. tostring(e):gsub("^.-:%d+: ", ""):sub(1, 80) .. "). /partymap check shows more.")
	end
end

-- /partymap check (and once at login if something is wrong): versions, the other addons, the
-- party's Party Map versions, the send queue and errors caught since login
local OPTIONAL = { "OpenMap", "WhatsTraining", "GatherMate2", "SilverDragon", "ForeverDungeonJournal" }
local function Loaded(name)
	local f = (C_AddOns and C_AddOns.IsAddOnLoaded) or IsAddOnLoaded
	if f then local ok, r = pcall(f, name); if ok then return r and true or false end end
	return rawget(_G, name) ~= nil
end
function ns.CheckReport()
	local lines, wrong = {}, {}
	local C = ns.Comms
	local errs = ns.errors or { n = 0, where = {} }
	lines[#lines + 1] = ("addon %s, strip format %d, party messages %d"):format(ns.VERSION or "?", ns.STRIP_FORMAT or 1, C and C.PROTO or 0)
	local questie = rawget(_G, "QuestieLoader") ~= nil or Loaded("Questie")
	lines[#lines + 1] = "Questie (needed): " .. (questie and "yes" or "MISSING")
	if not questie then wrong[#wrong + 1] = "Questie isn't loaded" end
	local opt = {}
	for _, n in ipairs(OPTIONAL) do opt[#opt + 1] = n .. " " .. (Loaded(n) and "yes" or "no") end
	opt[#opt + 1] = "ChatThrottleLib " .. (rawget(_G, "ChatThrottleLib") and "yes" or "no")
	lines[#lines + 1] = "others: " .. table.concat(opt, ", ")
	local peers = {}
	for name, o in pairs(ns.Others or {}) do
		if o.pm then
			peers[#peers + 1] = ("%s %s"):format(o.display or name, o.version or "older than 0.15.0")
			if C and not C.AtLeast(o.version, ns.VERSION or "0") then wrong[#wrong + 1] = (o.display or name) .. "'s Party Map is older (" .. (o.version or "before 0.15.0") .. ")" end
		end
	end
	table.sort(peers)
	lines[#lines + 1] = "party: " .. (#peers > 0 and table.concat(peers, ", ") or "nobody else with Party Map")
	lines[#lines + 1] = ("send queue: %d waiting; unknown messages ignored: %d"):format(C and C.QueueForTest and #C.QueueForTest() or 0, C and C.unknown or 0)
	local where = {}
	for k, n in pairs(errs.where or {}) do where[#where + 1] = k .. " " .. n end
	table.sort(where)
	lines[#lines + 1] = ("Lua errors caught since login: %d%s"):format(errs.n or 0, #where > 0 and (" (" .. table.concat(where, ", ") .. ")") or "")
	if errs.last then lines[#lines + 1] = "last: " .. errs.last end
	if (errs.n or 0) > 0 then wrong[#wrong + 1] = errs.n .. " Lua error" .. (errs.n == 1 and "" or "s") .. " caught" end
	if ns.dbReset then lines[#lines + 1] = ("saved settings: %d of the wrong kind were reset"):format(ns.dbReset) end
	return lines, wrong
end
local function CheckPrint()
	local lines = ns.CheckReport()
	print("|cffF0B04AParty Map|r check:")
	for _, l in ipairs(lines) do print("  " .. l) end
end

Slash = function(msg)
	local raw = (msg or ""):match("^%s*(.-)%s*$")
	msg = raw:lower()
	if msg == "check" then CheckPrint() return end
	if msg:match("^updates") then
		local arg = msg:match("^updates%s+(%a+)")
		if arg == "off" then PartyMapDB.noticeOff = true elseif arg == "on" then PartyMapDB.noticeOff = nil; PartyMapDB.noticeLater = nil end
		print("|cffF0B04AParty Map|r update notices " .. (PartyMapDB.noticeOff and "off (/partymap updates on to see them again)." or "on: when someone in your group has a newer Party Map, its app downloads it and a notice offers \"Reload now\"."))
		return
	end
	if msg == "train" or msg == "training" then
		if not rawget(_G, "WT_API") then print("|cffF0B04AParty Map|r needs the WhatsTraining addon for this.") return end
		local now = ns.Markers.TrainList()
		if now and #now > 0 then ns.Markers.TrainingNote(UnitLevel("player"), WorldPos())
		else print("|cffF0B04AParty Map|r nothing new to train right now.") end
		return
	end
	if msg:match("^name") then
		local key = ns.Markers.CharKey()
		local arg = raw:match("^[Nn][Aa][Mm][Ee]%s+(.+)$")
		PartyMapDB.names = PartyMapDB.names or {}
		if arg and arg:lower() == "reset" then PartyMapDB.names[key] = nil
		elseif arg then
			arg = arg:gsub("[|\r\n]", ""):gsub("^%s+", ""):gsub("%s+$", ""):sub(1, 40)
			local first = (UnitName("player") or ""):lower()
			if arg:lower():sub(1, #first) == first then PartyMapDB.names[key] = arg
			else print("|cffF0B04AParty Map|r the name has to start with your character's name (" .. (UnitName("player") or "") .. ")."); return end
		end
		dirty = true
		print("|cffF0B04AParty Map|r your party sees you as: " .. (PartyMapDB.names[key] or UnitName("player") or "?") .. ". /partymap name <full name>, or /partymap name reset")
		return
	end
	if msg:match("^role") then
		local arg = msg:match("^role%s+(%a+)")
		if arg == "tank" or arg == "healer" or arg == "dps" then ns.Markers.SetRole(arg)
		elseif arg == "heal" or arg == "healing" then ns.Markers.SetRole("healer")
		elseif arg == "damage" then ns.Markers.SetRole("dps")
		elseif arg == "auto" or arg == "off" then ns.Markers.Role(); ns.Markers.SetRole(nil) end
		gearDirty, dirty = true, true
		local r, from = ns.Markers.Role()
		local names = { TANK = "tank", HEALER = "healer", DAMAGER = "damage dealer" }
		if r then
			print(("|cffF0B04AParty Map|r gear upgrades are picked for a %s (%s). /partymap role tank|healer|dps|auto"):format(names[r], from == "set" and "you set it, for this character" or "your party role"))
		else
			print("|cffF0B04AParty Map|r gear upgrades follow your talents (no party role yet). /partymap role tank|healer|dps to choose one.")
		end
		return
	end
	if msg:match("^faces") or msg == "portraits" then
		local arg = msg:match("^faces%s+(%a+)")
		if arg == "off" then
			PartyMapDB.npcFaces = false
			print("|cffF0B04AParty Map|r no more pictures of creatures you target (/partymap faces on to switch back). The map keeps the ones it has.")
		elseif arg == "on" then
			PartyMapDB.npcFaces = nil
			print("|cffF0B04AParty Map|r creatures you target get their picture taken for the map again, once per kind, never in combat.")
		else
			ns.RetakePortraits()
			print("|cffF0B04AParty Map|r taking fresh portraits of you, your party and the creatures you target for the map.")
		end
		return
	end
	if msg:match("^bags") then
		local arg = msg:match("^bags%s+(%a+)")
		if arg == "off" then PartyMapDB.bags = false
		elseif arg == "on" then PartyMapDB.bags = true end
		ns.BagsChanged()
		local bn = ns.bagNames
		if bn then print(("|cffF0B04AParty Map|r %d different items in the bags shown, %d named so far."):format(bn[1], bn[2])) end
		if PartyMapDB.bags == false then
			print("|cffF0B04AParty Map|r your bags aren't shared with the party (/partymap bags on to share them again).")
		else
			print("|cffF0B04AParty Map|r your bags are shared with your party, for their Party bags window (/partymap bags off to stop).")
		end
		return
	end
	if msg:match("^uprank") then
		local arg = msg:match("^uprank%s+(%a+)")
		if arg == "off" then PartyMapDB.uprank = false; print("|cffF0B04AParty Map|r new spell ranks won't go on your bars by themselves now (/partymap uprank on to switch back).")
		elseif arg == "on" then PartyMapDB.uprank = true; print("|cffF0B04AParty Map|r new spell ranks will replace the old ones on your bars.")
		else ns.Markers.UprankAll() end
		return
	end
	if msg:match("^pins? clear") or msg == "clearpins" then
		if ns.Comms then ns.Comms.ClearPins() end
		print("|cffF0B04AParty Map|r your pins are cleared.")
		return
	end
	if msg:match("^pin") then
		local rest = raw:gsub("^%S+%s*", "")
		local pu, pv, label = rest:match("^(%d+)%s+(%d+)%s*(.*)$")
		local u, v
		if pu then
			u, v = tonumber(pu) / 100000, tonumber(pv) / 100000
		else
			u, v = WorldPos()
			label = rest
		end
		if u and ns.Comms and ns.Comms.AddPin(u, v, label) then
			print("|cffF0B04AParty Map|r pin dropped" .. (label ~= "" and (": " .. label) or "") .. ".")
		else
			print("|cffF0B04AParty Map|r can't tell where that is.")
		end
		return
	end
	if msg == "on" or msg == "off" or msg == "" then
		if msg == "" then PartyMapDB.on = not PartyMapDB.on else PartyMapDB.on = (msg == "on") end
		frame:SetShown(PartyMapDB.on)
		print("|cffF0B04AParty Map|r strip " .. (PartyMapDB.on and "on" or "off") .. ".")
	elseif msg == "test" then
		if ns.Comms then
			ns.Comms.SetTest(not ns.Comms.test)
			print("|cffF0B04AParty Map|r test mode " .. (ns.Comms.test and "on: a pretend friend, \"" .. (UnitName("player") or "you") .. " (echo)\", copies you, just beside you. /partymap test again to stop." or "off."))
		end
	elseif msg == "bright" or msg == "dim" then
		PartyMapDB.bright = (msg == "bright")
		maxGrey = PartyMapDB.bright and E.MAX_BRIGHT or E.MAX
		for k in pairs(painted) do painted[k] = nil end
		print("|cffF0B04AParty Map|r strip " .. (PartyMapDB.bright and "brighter (easier to read)." or "near invisible."))
	elseif msg == "bl" or msg == "br" or msg == "tl" or msg == "tr" then
		PartyMapDB.corner = msg
		Layout()
		print("|cffF0B04AParty Map|r strip moved to the " .. ({ bl = "bottom left", br = "bottom right", tl = "top left", tr = "top right" })[msg] .. ".")
	else
		print("|cffF0B04AParty Map|r: /partymap (on/off), /partymap on, /partymap off, /partymap bl|br|tl|tr (which corner), /partymap dim|bright, /partymap test (pretend friend), /partymap pin [label] (pin where you are), /partymap pins clear, /partymap train (what you can learn), /partymap uprank (highest ranks on your bars now; uprank off/on: automatically when you learn a rank), /partymap bags off|on (share your bags with the party), /partymap faces (retake portraits for the map), /partymap role tank|healer|dps|auto (which gear upgrades you see), /partymap check (versions, other addons, errors), /partymap updates off|on (the Reload now notice). Alt+click the world map to pin a spot.")
	end
end

--------------------------------------------------------------------------------
-- Update notice: when someone in the group runs a newer Party Map, the app downloads it in the
-- background (it hears about it from the strip's NV line); a moment later a small notice offers
-- "Reload now". Hidden in combat, never reloads by itself; "Later" hides it until the next update.
-- When the update needs a full restart (a new addon file, the TOC's file list or the strip format),
-- the notice says so with just an OK, since an addon can't restart the game.
--------------------------------------------------------------------------------

local NOTICE_WAIT = 20          -- seconds after first hearing a version (the download has time to finish)
local heardAt = {}
local notice

-- what the notice should show now: nil (nothing), or version and whether a restart is needed
function ns.NoticeWanted(now)
	local C = ns.Comms
	if not (C and C.NewestPeer) then return end
	if PartyMapDB and PartyMapDB.noticeOff then return end
	local v, since = C.NewestPeer()
	if not v then return end
	heardAt[v] = heardAt[v] or now
	if now - heardAt[v] < NOTICE_WAIT then return end
	if PartyMapDB and PartyMapDB.noticeLater == v then return end
	if (InCombatLockdown and InCombatLockdown()) or (UnitAffectingCombat and UnitAffectingCombat("player")) then return end
	local restart = since and not C.AtLeast(C.VERSION, since) or false
	return v, restart
end

local function NoticeFrame()
	if notice then return notice end
	local f = CreateFrame("Frame", "PartyMapUpdateNotice", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(320, 96)
	f:SetFrameStrata("DIALOG")
	f:SetClampedToScreen(true)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
			tile = true, tileSize = 32, edgeSize = 32, insets = { left = 11, right = 12, top = 12, bottom = 11 } })
	end
	f:SetMovable(true)
	f:EnableMouse(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", function(self) self:StartMoving() end)
	f:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		local point, _, rel, x, y = self:GetPoint()
		PartyMapDB.noticePos = { point = point, rel = rel, x = x, y = y }
	end)
	local title = f:CreateFontString(nil, "ARTWORK", "GameFontNormal")
	title:SetPoint("TOP", f, "TOP", 0, -20)
	f.title = title
	local reload = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	reload:SetSize(120, 24)
	reload:SetText("Reload now")
	reload:SetScript("OnClick", function() if ReloadUI then ReloadUI() end end)
	f.reload = reload
	local later = CreateFrame("Button", nil, f, "UIPanelButtonTemplate")
	later:SetSize(120, 24)
	later:SetText("Later")
	later:SetScript("OnClick", function() PartyMapDB.noticeLater = f.version; f:Hide() end)
	f.later = later
	f:Hide()
	notice = f
	return f
end

local function PlaceNotice(f)
	f:ClearAllPoints()
	local p = PartyMapDB and PartyMapDB.noticePos
	if type(p) == "table" and p.point then
		f:SetPoint(p.point, UIParent, p.rel or p.point, tonumber(p.x) or 0, tonumber(p.y) or 0)
	else
		f:SetPoint("TOP", UIParent, "TOP", 0, -135)   -- (where the game's own pop-ups go)
	end
end

function ns.UpdateNotice(now)
	local v, restart = ns.NoticeWanted(now)
	if not v then
		if notice and notice:IsShown() then notice:Hide() end
		return
	end
	local f = NoticeFrame()
	if f.version ~= v or f.restart ~= restart or not f:IsShown() then
		f.version, f.restart = v, restart
		f.reload:ClearAllPoints()
		f.later:ClearAllPoints()
		if restart then
			f.title:SetText(("|cffffd100Party Map updated|r (%s)\nRestart WoW to update"):format(v))
			f.reload:Hide()
			f.later:SetText(OKAY or "OK")
			f.later:SetPoint("BOTTOM", f, "BOTTOM", 0, 16)
		else
			f.title:SetText(("|cffffd100Party Map updated|r (%s)"):format(v))
			f.reload:Show()
			f.later:SetText("Later")
			f.reload:SetPoint("BOTTOMRIGHT", f, "BOTTOM", -4, 16)
			f.later:SetPoint("BOTTOMLEFT", f, "BOTTOM", 4, 16)
		end
		PlaceNotice(f)
		f:Show()
	end
end

local noticeTick, noticeElapsed = CreateFrame("Frame"), 0
noticeTick:SetScript("OnUpdate", function(_, dt)
	noticeElapsed = noticeElapsed + dt
	if noticeElapsed < 0.5 then return end
	noticeElapsed = 0
	local ok, e = pcall(ns.UpdateNotice, GetTime())
	if not ok and ns.Err then ns.Err("notice", e) end
end)
