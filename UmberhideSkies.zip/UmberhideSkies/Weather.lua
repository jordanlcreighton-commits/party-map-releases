-- Umberhide Skies: rain, snow, fireflies, fog, splashes and lightning, with depth.
-- Every drop, flake and firefly has a place in front of the camera (x across, y up, z away). They
-- are drawn in perspective from the horizon line: far ones small, faint and slow, near ones big and
-- fast. Drops land on the ground at their own distance and splash there. Turning swings them past
-- and running rushes them at you. An addon can't see the ground's shape, trees or rocks, so the
-- ground is treated as flat; name plates and your own spot tell it where characters are.
local ADDON, ns = ...
local Wx = {}
ns.Weather = Wx

local Clamp = ns.Clamp
local CAMH, ZFAR = 1, 40
local MAXR, MAXS, MAXF, MAXSPLASH, MAXBITS = 520, 300, 60, 110, 140
local rnd = function(a, b) return a + math.random() * (b - a) end

local drops, flakes, flies, splashes, bits = {}, {}, {}, {}, {}
Wx.drops = drops -- for the tests
local fogA, fogB, sheetA, sheetB
local skyA, skyB, skyEdgeA, skyEdgeB, boltTex, skyGlow -- rolling cloud and lightning (Sky.tga)
-- fog (since 1.0.5): it can't be pinned to a horizon line (the camera tilts, and an addon can't see
-- by how much), so it thickens towards the top of the screen, which in a third-person view is
-- always further away (distant land or sky), and thins towards your feet. Slow sheets of layered
-- mist roll across it and wisps form and fade in the upper part of the view. Fog.tga is a sheet of
-- stripes (see tools/skies/make_assets.py); these are the stripes' rows out of 512.
local FOGV = { bankA = { 2 / 512, 158 / 512 }, bankB = { 170 / 512, 326 / 512 }, haze = { 338 / 512, 414 / 512 }, wisp = { 426 / 512, 510 / 512 } }
local SHEETS = { -- one repeat across (in screen widths), thickness, drift speed, slow heave period (s)
	{ rep = 2.6, a = 0.42, v = 0.6, per = 47, stripe = FOGV.haze },
	{ rep = 1.5, a = 0.34, v = 1.0, per = 33, stripe = FOGV.haze },
	{ rep = 0.9, a = 0.26, v = 1.6, per = 23, stripe = FOGV.haze },
	{ rep = 1.9, a = 0.22, v = -0.4, per = 39, stripe = FOGV.haze }, -- an eddy drifting the other way
}
local MAXWISP = 14
local wisps, halos = {}, {}
Wx.sheets, Wx.wisps, Wx.halos = SHEETS, wisps, halos -- for the tests
local view = { W = 1600, H = 900, CX = 800, F = 1234, hz = 207 }

local function View()
	local W, H = ns.Layers.Size()
	view.W, view.H, view.CX, view.F = W, H, W / 2, H * 1.372
	view.hz = ns.s.horizon * H
	view.u = H / 656
end

local function HalfX(z) return (view.W / 2 + 120 * view.u) * z / view.F end
local function TopY(z) return CAMH + (view.hz + 60 * view.u) * z / view.F end
local function GroundY(z) return view.hz + CAMH * view.F / z end
local function Project(x, y, z) return view.CX + x * view.F / z, view.hz + (CAMH - y) * view.F / z end
Wx.Project = function(x, y, z) View(); return Project(x, y, z) end
Wx.GroundY = function(z) View(); return GroundY(z) end

local function NewDrop(p, fill)
	-- Most drops are spread through the whole depth (far ones are many and small, which gives the
	-- rain its texture). The rest are made near more often, in proportion to how quickly near drops
	-- cross the screen, so there is always rain close by too, catching your light.
	if math.random() < 0.58 then
		p.z = 1.25 + 34 * math.random() ^ 0.9
	else
		local A, B = 1 + 0.234 * 1.25, 1 + 0.234 * 35
		p.z = (A * (B / A) ^ math.random() - 1) / 0.234
	end
	local hx = HalfX(p.z)
	p.x = rnd(-hx, hx)
	p.y = fill and rnd(0, TopY(p.z)) or TopY(p.z) + rnd(0, 0.4)
	p.v = rnd(8.5, 10.5)
	return p
end
local function NewFlake(p, fill)
	p.z = 1.2 + 30 * math.random() ^ 0.85
	local hx = HalfX(p.z)
	p.x = rnd(-hx, hx)
	p.y = fill and rnd(0, TopY(p.z)) or TopY(p.z) + rnd(0, 0.3)
	p.v, p.ph, p.amp = rnd(0.55, 1.05), rnd(0, 6.28), rnd(0.15, 0.45)
	return p
end
local function NewFly(p)
	p.z = rnd(1.6, 22)
	p.x = rnd(-HalfX(p.z), HalfX(p.z))
	p.h, p.vx, p.vh, p.vz = rnd(0.05, 0.9), 0, 0, 0
	p.ph, p.per = rnd(0, 100), rnd(2.5, 6)
	return p
end

function Wx.Init()
	local Tex = ns.Layers.Tex
	View()
	-- fog lies under the night (drawn above it, it greyed the dark out in game) and under the rain
	fogA = Tex("BACKGROUND", 1, nil)
	fogB = Tex("BACKGROUND", 1, nil)
	sheetA = Tex("ARTWORK", -4, nil)
	sheetB = Tex("ARTWORK", -4, nil)
	-- cloud rolling in across the top of the sky, under the night and the fog
	skyA = Tex("BACKGROUND", 0, nil); skyEdgeA = Tex("BACKGROUND", 0, nil)
	skyB = Tex("BACKGROUND", 0, nil); skyEdgeB = Tex("BACKGROUND", 0, nil)
	for _, t in ipairs({ skyA, skyB, skyEdgeA, skyEdgeB }) do t:SetTexture(ns.PATH .. "Textures\\Sky", "REPEAT", "CLAMP") end
	-- lightning: a bolt for a near strike, a glow across the clouds for a far one (above the night)
	boltTex = Tex("ARTWORK", 4, ns.PATH .. "Textures\\Sky", "ADD")
	skyGlow = Tex("ARTWORK", 3, ns.PATH .. "Textures\\Soft", "ADD")
	for i, sh in ipairs(SHEETS) do
		sh.tex = Tex("BACKGROUND", 2 + math.floor((i - 1) / 2), nil)
		sh.tex:SetTexture(ns.PATH .. "Textures\\Fog", "REPEAT", "CLAMP")
		sh.off, sh.ph = math.random(), math.random() * 6.28
	end
	for i = 1, MAXWISP do
		wisps[i] = { tex = Tex("BACKGROUND", 5, ns.PATH .. "Textures\\Fog"), life = 0, t = 1 }
	end
	for i = 1, 5 do halos[i] = Tex("ARTWORK", -5, ns.PATH .. "Textures\\Soft", "ADD") end
	for _, t in ipairs({ sheetA, sheetB }) do t:SetTexture(ns.PATH .. "Textures\\Sheet", "REPEAT", "REPEAT") end
	for i = 1, MAXR do
		local t = Tex("ARTWORK", 0, ns.PATH .. "Textures\\Streak")
		drops[i] = NewDrop({ tex = t }, true)
	end
	for i = 1, MAXS do
		local t = Tex("ARTWORK", 1, ns.PATH .. "Textures\\Soft")
		flakes[i] = NewFlake({ tex = t }, true)
	end
	for i = 1, MAXF do
		local t = Tex("ARTWORK", 2, ns.PATH .. "Textures\\Soft", "ADD")
		flies[i] = NewFly({ tex = t })
	end
	for i = 1, MAXSPLASH do splashes[i] = { tex = Tex("ARTWORK", 3, ns.PATH .. "Textures\\Ring"), t = 99 } end
	for i = 1, MAXBITS do bits[i] = { tex = Tex("ARTWORK", 3, "Interface\\Buttons\\WHITE8X8"), t = 99 } end
end

-- ---------------------------------------------------------------- moving with the camera
local lastFacing
local function CameraMove(elapsed)
	local turn, rush = 0, 0
	if GetPlayerFacing then
		local ok, f = pcall(GetPlayerFacing)
		if ok and type(f) == "number" and not ns.Secret(f) then
			if lastFacing then
				turn = f - lastFacing
				if turn > math.pi then turn = turn - 2 * math.pi elseif turn < -math.pi then turn = turn + 2 * math.pi end
				if math.abs(turn) > 0.6 then turn = 0 end -- a teleport or loading screen, not a turn
			end
			lastFacing = f
		end
	end
	if GetUnitSpeed then
		local ok, sp = pcall(GetUnitSpeed, "player")
		if ok and type(sp) == "number" and not ns.Secret(sp) then rush = sp / 2.5 * elapsed * 0.6 end
	end
	return turn, rush
end

-- ---------------------------------------------------------------- characters
-- Your character stands at your light spot; party members under their name plates. A drop at the
-- same distance that falls into a body breaks on it.
local bodies = {}
local function Bodies()
	wipe(bodies)
	for _, l in ipairs(ns.Layers.lights) do
		local k = ns.Layers.ScaleAt(l.y)
		bodies[#bodies + 1] = { x = l.x, top = l.y - 150 * view.u * k, feet = l.y, half = 28 * view.u * k, z = CAMH * view.F / math.max(l.y - view.hz, 1) }
	end
end
local function HitsBody(sx, sy, z)
	for _, b in ipairs(bodies) do
		if math.abs(sx - b.x) < b.half and sy > b.top and sy < b.feet and math.abs(z - b.z) < b.z * 0.18 then return b end
	end
end

-- ---------------------------------------------------------------- splashes
local function Splash(x, y, z, onBody)
	for _, s in ipairs(splashes) do
		if s.t >= 0.26 then
			s.x, s.y, s.z, s.t, s.body = x, y, z, 0, onBody
			break
		end
	end
	if z < 7 then
		local k = 3 / z * view.u
		local n = 0
		for _, b in ipairs(bits) do
			if b.t >= 0.32 then
				b.x, b.y, b.t = x, y, 0
				b.vx, b.vy, b.g = rnd(-70, 70) * k, -rnd(90, 170) * k, 900 * k
				n = n + 1
				if n >= 2 then break end
			end
		end
	end
end

-- ---------------------------------------------------------------- lightning
local strokes, nextStrike, flash = {}, 4, 0
Wx.thunder = {}
local function Flash(now)
	local f = 0
	for _, s in ipairs(strokes) do
		if now >= s.t then f = f + s.a * math.exp(-(now - s.t) / s.d) end
	end
	return math.min(1.3, f)
end

-- ---------------------------------------------------------------- one frame
local function HideList(list) for _, p in ipairs(list) do p.tex:Hide() end end

local function Wind(now) return ns.W.wind * 5 * (1 + 0.55 * math.sin(now * 0.37) + 0.3 * math.sin(now * 1.21 + 1.3)) end
Wx.Wind = Wind


-- ---------------------------------------------------------------- fog
-- Wisps live on the screen, not on a horizon line: anywhere across the upper three quarters of the
-- view, smaller and fainter higher up (further away), drifting with the wind, slowly forming and
-- fading. One that drifts out of view thins out and a new one forms.
local function NewWisp(w)
	w.fy = rnd(0.04, 0.72)                -- how far down the screen (0 top .. 1 bottom)
	w.k = 0.45 + w.fy * 1.1               -- nearer (lower) wisps are bigger
	w.x = rnd(-0.2, 1.2)                  -- across, in screen widths
	w.sw, w.sh = rnd(0.28, 0.5), rnd(0.06, 0.11)
	w.life, w.t = rnd(14, 26), 0
	w.flip, w.half = math.random() < 0.5, math.random() < 0.5
	w.v = rnd(0.6, 1.4)
	return w
end

local function FogColour(d, flash)
	local c = ns.Colour(ns.s.colour)
	local m = math.max(c.r, c.g, c.b)
	local g0 = 0.82 - 0.30 * d -- (the night's darkness lies over the fog, so it needn't darken it much itself)
	local r, g, b = g0 * (0.74 + 0.26 * c.r / m), g0 * (0.74 + 0.26 * c.g / m), g0 * (0.76 + 0.24 * c.b / m)
	local du = ns.W.dust or 0
	r, g, b = r + (0.80 * g0 / 0.82 - r) * du, g + (0.66 * g0 / 0.82 - g) * du, b + (0.46 * g0 / 0.82 - b) * du
	local f = math.min(1, flash) * 0.35
	return Clamp(r + f, 0, 1), Clamp(g + f, 0, 1), Clamp(b + f * 1.1, 0, 1)
end

-- Fog sits still: it follows a turn only partly, and smoothly over about a second, so it drifts a
-- little the way you turn and settles. (The camera often lags your character's facing, and the
-- game's field of view isn't known, so following exactly would make it slide and jitter.)
local FOG_FOLLOW, FOG_SETTLE, FOG_MAXRATE = 0.35, 1.1, 0.25
local fogYaw, fogShown = 0, 0
function Wx.Fog(elapsed, now, on, d, wind, turn, rush)
	local s = ns.s
	local W = ns.W
	-- rain and snow bring their own haze to the distance
	local amt = on and Clamp(W.fog + W.rain * 0.22 + W.snow * 0.18 + W.dust * 0.55, 0, 1) or 0
	if amt < 0.01 then
		fogA:Hide(); fogB:Hide()
		for _, sh in ipairs(SHEETS) do sh.tex:Hide() end
		for _, w in ipairs(wisps) do w.tex:Hide() end
		for _, h in ipairs(halos) do h:Hide() end
		return
	end
	fogYaw = fogYaw + turn * FOG_FOLLOW
	local step = (fogYaw - fogShown) * Clamp(elapsed / FOG_SETTLE, 0, 1)
	step = Clamp(step, -FOG_MAXRATE * elapsed, FOG_MAXRATE * elapsed)
	fogShown = fogShown + step
	local shift = step * view.F -- how far the fog moves across this frame, in screen units
	local W, H = view.W, view.H
	local fr, fg, fb = FogColour(d, flash)
	local lift = 1 + math.min(1, flash) * 0.9
	-- the whole fog breathes: thicker and thinner over a minute or so, and surges with the wind
	local surge = 0.5 + 0.5 * math.sin(now * 0.11) * math.sin(now * 0.043 + 1.7)
	local breathe = 0.88 + 0.12 * math.sin(now * 0.07 + 0.9)
	local roll = (0.010 + wind * 0.004 + surge * 0.008) -- screen widths a second
	-- the base haze: thickest at the top of the screen (far off), thinning smoothly to your feet
	local top = amt * 0.42 * lift * breathe
	fogA:ClearAllPoints()
	fogA:SetPoint("TOPLEFT", ns.Layers.Root(), "TOPLEFT", 0, 0)
	fogA:SetPoint("BOTTOMRIGHT", ns.Layers.Root(), "TOPRIGHT", 0, -H * 0.55)
	ns.Gradient(fogA, "VERTICAL", fr, fg, fb, top * 0.45, top)
	fogA:SetAlpha(1)
	fogA:Show()
	fogB:ClearAllPoints()
	fogB:SetPoint("TOPLEFT", ns.Layers.Root(), "TOPLEFT", 0, -H * 0.55)
	fogB:SetPoint("BOTTOMRIGHT", ns.Layers.Root(), "BOTTOMRIGHT", 0, 0)
	ns.Gradient(fogB, "VERTICAL", fr, fg, fb, top * 0.06, top * 0.45)
	fogB:SetAlpha(1)
	fogB:Show()
	-- sheets of layered mist rolling across, each at its own speed and size, heaving slowly; each
	-- is the soft haze stretched into long streaks, also thickest towards the top
	for i, sh in ipairs(SHEETS) do
		local t = sh.tex
		local heave = math.sin(now * 6.283 / sh.per + sh.ph)
		local repW = sh.rep * W
		sh.off = (sh.off - (roll * sh.v * elapsed) / sh.rep - shift / repW) % 1
		local reach = 0.62 + 0.12 * heave -- how far down the screen this sheet reaches
		t:ClearAllPoints()
		t:SetPoint("TOPLEFT", ns.Layers.Root(), "TOPLEFT", 0, H * 0.12)
		t:SetPoint("BOTTOMRIGHT", ns.Layers.Root(), "TOPRIGHT", 0, -H * reach)
		t:SetTexCoord(sh.off, sh.off + 1 / sh.rep, sh.stripe[1], sh.stripe[2])
		local a = amt * sh.a * lift * breathe * (1 + 0.2 * heave)
		ns.Gradient(t, "VERTICAL", fr, fg, fb, 0, Clamp(a, 0, 0.8))
		t:SetAlpha(1)
		t:Show()
	end
	-- wisps forming and fading in the upper part of the view
	local nW = math.floor(MAXWISP * Clamp(amt * 1.4, 0, 1) + 0.5)
	for i, w in ipairs(wisps) do
		local t = w.tex
		if i > nW then
			t:Hide()
		else
			if w.t >= w.life then NewWisp(w) end
			w.t = w.t + elapsed
			w.x = w.x + roll * w.v * w.k * elapsed * 2 + shift / W
			if w.x > 1.35 or w.x < -0.35 then NewWisp(w) end
			local ww, wh = w.sw * W * w.k, w.sh * H * w.k * (1 + 0.15 * math.sin(now * 0.3 + w.life))
			local life = math.sin(math.pi * Clamp(w.t / w.life, 0, 1))
			local edge = Clamp(math.min(w.x + 0.3, 1.3 - w.x) / 0.3, 0, 1)
			local a = amt * 0.36 * life * lift * edge * (1.15 - w.fy * 0.6)
			if a < 0.01 then
				t:Hide()
			else
				local l, r = w.half and 0.5 or 0, w.half and 1 or 0.5
				if w.flip then l, r = r, l end
				t:SetTexCoord(l, r, FOGV.wisp[1], FOGV.wisp[2])
				t:SetVertexColor(fr, fg, fb, 1)
				t:SetAlpha(Clamp(a, 0, 0.6))
				ns.Layers.Place(t, w.x * W, w.fy * H, ww, wh)
				t:Show()
			end
		end
	end
	-- light caught in the fog round your lantern and your party
	local warm = s.colour == "ember" and { 1, 0.72, 0.48 } or { 1, 0.88, 0.70 }
	local n = 0
	for _, l in ipairs(ns.Layers.lights) do
		if n < #halos then
			n = n + 1
			local h = halos[n]
			h:SetVertexColor(warm[1], warm[2], warm[3], 1)
			h:SetAlpha(Clamp(amt * s.lstr * l.k * (0.06 + 0.22 * d), 0, 0.3))
			ns.Layers.Place(h, l.cx, l.cy - l.ry * 0.15, l.rx * 2.4, l.ry * 2.0)
			h:Show()
		end
	end
	for i = n + 1, #halos do halos[i]:Hide() end
end

-- ---------------------------------------------------------------- clouds
-- Cloud rolls in across the top of the sky from the side the wind comes from, thickening as the
-- weather comes in, and drifts with the wind; lightning lights it from below.
local cloudShift = { 0, 0.37 }
function Wx.Clouds(elapsed, now, on, wind, flash)
	local W = ns.W
	local c = on and W.cloud or 0
	local layers = { { skyA, skyEdgeA, 1.0, 0.70, 0.55 }, { skyB, skyEdgeB, 0.6, 0.45, 0.42 } }
	if c < 0.03 then
		for _, L in ipairs(layers) do L[1]:Hide(); L[2]:Hide() end
		return
	end
	local Wd, H = view.W, view.H
	local fromLeft = wind >= 0
	local f = Clamp(c * 1.6, 0, 1) -- how far across the sky it has come
	local lit = math.min(1, flash) * 0.55
	local r, g, b = 0.17 + lit, 0.19 + lit, 0.23 + lit * 1.1
	for i, L in ipairs(layers) do
		local body, edge, scale, alpha, reach = L[1], L[2], L[3], L[4], L[5]
		cloudShift[i] = (cloudShift[i] + (0.004 + math.abs(wind) * 0.004) * elapsed / scale * (fromLeft and -1 or 1)) % 1
		local heave = 1 + 0.06 * math.sin(now * 0.05 + i)
		local bottom = H * reach * heave * (0.75 + 0.25 * c)
		local edgeW = Wd * 0.35
		local front = -edgeW + f * (Wd + 2 * edgeW) -- where the leading edge has reached
		local x0, x1, e0, e1
		if fromLeft then x0, x1, e0, e1 = -10, front, front, front + edgeW
		else x0, x1, e0, e1 = Wd - front, Wd + 10, Wd - front - edgeW, Wd - front end
		local a = Clamp(c * alpha, 0, 0.85)
		local function Put(t, xa, xb, ga, gb)
			if xb - xa < 2 then t:Hide() return end
			t:ClearAllPoints()
			t:SetPoint("TOPLEFT", ns.Layers.Root(), "TOPLEFT", xa, H * 0.04)
			t:SetPoint("BOTTOMRIGHT", ns.Layers.Root(), "TOPLEFT", xb, -bottom)
			local u0 = cloudShift[i] + xa / (Wd * 1.6 * scale)
			t:SetTexCoord(u0, u0 + (xb - xa) / (Wd * 1.6 * scale), 2 / 512, 254 / 512)
			if ga then ns.Gradient(t, "HORIZONTAL", r, g, b, ga, gb) else t:SetVertexColor(r, g, b, 1); t:SetAlpha(a) end
			if ga then t:SetAlpha(1) end
			t:Show()
		end
		Put(body, x0, x1)
		if fromLeft then Put(edge, e0, e1, a, 0) else Put(edge, e0, e1, 0, a) end
	end
end

local weatherOn = false
function Wx.Update(elapsed, now)
	local s = ns.s
	local W = ns.W
	View()
	local outside = ns.Place() == "out"
	local on = s.on and outside
	local d = ns.Layers.darkness or 0
	local vis = Clamp(1 - d * 0.68, 0.32, 1)
	local turn, rush = CameraMove(elapsed)
	Bodies()
	-- lightning: how often is yours to set ("Lightning: how often", from about one in 26 seconds to
	-- one in 3), and a storm's lightning is far off and dim as it comes in, close and bright at its
	-- height. A near strike draws a bolt down the sky; a far one lights the clouds from behind.
	if on and W.storm > 0.05 then
		nextStrike = nextStrike - elapsed * Clamp(W.storm, 0.2, 1)
		if nextStrike <= 0 then
			wipe(strokes)
			local dist = W.dist and Clamp(W.dist + rnd(-0.2, 0.2), 0.02, 1) or math.random()
			local bright = (0.25 + 0.75 * (1 - dist)) * (0.35 + 0.9 * s.boltBright)
			local n, t = (math.random() < 0.6) and 3 or 2, now
			for i = 1, n do
				strokes[i] = { t = t, a = (i == 1 and 1 or rnd(0.35, 0.95)) * bright, d = rnd(0.05, 0.11) }
				t = t + rnd(0.06, 0.16)
			end
			Wx.strike = { x = rnd(0.08, 0.92), dist = dist, t0 = now, bolt = dist < 0.65 and math.random(4) or nil, flip = math.random() < 0.5 }
			Wx.thunder[#Wx.thunder + 1] = { at = now + 0.4 + dist * 4.5, dist = dist }
			nextStrike = (26 - 23 * s.boltRate) * rnd(0.6, 1.4)
		end
	else
		wipe(strokes)
	end
	flash = Flash(now)
	Wx.flash = flash
	local fl = ns.Layers.flash
	if flash > 0.01 and on then
		ns.Gradient(fl, "VERTICAL", 0.80, 0.85, 1, flash * 0.14, flash * 0.5)
		fl:Show()
	else
		fl:Hide()
	end
	local st = Wx.strike
	if on and st and flash > 0.02 then
		local W_, H_ = view.W, view.H
		local x = st.x * W_
		if st.bolt then
			-- a near bolt reaches far down the sky; a further one is shorter, higher and thinner
			local h = H_ * (0.30 + 0.45 * (1 - st.dist))
			local i = st.bolt
			local l, r = (i - 1) / 4, i / 4
			if st.flip then l, r = r, l end
			boltTex:SetTexCoord(l, r, 264 / 512, 510 / 512)
			boltTex:SetVertexColor(0.85, 0.9, 1, 1)
			boltTex:SetAlpha(Clamp(flash * 1.1, 0, 1))
			ns.Layers.Place(boltTex, x, h / 2 - H_ * 0.04, h * 0.5, h)
			boltTex:Show()
		else
			boltTex:Hide()
		end
		skyGlow:SetVertexColor(0.75, 0.82, 1, 1)
		skyGlow:SetAlpha(Clamp(flash * (0.25 + 0.35 * st.dist), 0, 0.6))
		ns.Layers.Place(skyGlow, x, H_ * 0.08, W_ * 0.7, H_ * 0.7)
		skyGlow:Show()
	else
		boltTex:Hide(); skyGlow:Hide()
	end
	vis = vis + flash * 1.2
	local wind = Wind(now)
	Wx.Fog(elapsed, now, on, d, wind, turn, rush)
	Wx.Clouds(elapsed, now, on, wind, flash)
	-- far rain hanging near the horizon
	if on and W.rain > 0.01 then
		local hz = view.hz
		for i, t in ipairs({ sheetA, sheetB }) do
			local sc = i == 1 and 1 or 0.6
			local v = now * (i == 1 and 0.66 or 0.37)
			local uo = -now * wind * 0.05 * sc
			t:ClearAllPoints()
			t:SetPoint("TOPLEFT", ns.Layers.Root(), "TOPLEFT", 0, -math.max(0, hz - 140 * view.u))
			t:SetPoint("TOPRIGHT", ns.Layers.Root(), "TOPRIGHT", 0, -math.max(0, hz - 140 * view.u))
			t:SetHeight(400 * view.u)
			t:SetTexCoord(uo, uo + view.W / (256 * view.u * sc), -v, -v + 400 / (512 * sc))
			ns.Gradient(t, "VERTICAL", 0.78, 0.84, 0.94, 0, Clamp(W.rain * 0.45 * vis * (Wx.rainNow or 1) * (i == 1 and 0.55 or 0.35), 0, 0.7))
			t:SetAlpha(1)
			t:Show()
		end
	else
		sheetA:Hide(); sheetB:Hide()
	end
	-- rain: it comes in spells, heavier and lighter over half a minute or so, harder in the gusts,
	-- and gust fronts sweep across as bands of heavier rain
	local spell = 0.80 + 0.20 * math.sin(now * 0.047 + 1.1) * math.sin(now * 0.019 + 0.3)
	local gust = W.wind > 0.01 and Clamp(0.88 + 0.12 * (wind / (W.wind * 5) - 1), 0.75, 1) or 1
	Wx.rainNow = spell * gust
	local nR = on and math.floor(W.rain * MAXR * spell * gust + 0.5) or 0
	local fdir = wind >= 0 and 1 or -1
	local EXPO = 0.016
	for i = 1, MAXR do
		local p = drops[i]
		local t = p.tex
		if i > nR then
			t:Hide()
		else
			p.y = p.y - p.v * elapsed
			p.x = p.x + wind * elapsed + turn * p.z
			p.z = p.z - rush
			local hx = HalfX(p.z)
			if p.z < 1.1 then NewDrop(p, false) p.y = rnd(0, TopY(p.z)) end
			if p.x > hx * 1.15 then p.x = p.x - 2.3 * hx elseif p.x < -hx * 1.15 then p.x = p.x + 2.3 * hx end
			local sx, sy = Project(p.x, p.y, p.z)
			local body = HitsBody(sx, sy, p.z)
			if p.y <= 0 or body then
				if s.splash and p.z < 16 and sy < view.H + 10 then Splash(sx, body and sy or GroundY(p.z), p.z, body) end
				NewDrop(p, false)
				t:Hide()
			elseif sy < -40 or sy > view.H + 40 then
				t:Hide()
			else
				local len = p.v * view.F / p.z * EXPO
				local dx = wind * view.F / p.z * EXPO - (sx - view.CX) / view.W * len * 0.5
				local li = ns.Layers.LightAt(sx, sy)
				local base, w
				if p.z < 2.6 then base, w = 0.16, 2.4 elseif p.z < 6 then base, w = 0.28, 1.4 elseif p.z < 15 then base, w = 0.32, 1.0 else base, w = 0.20, 0.8 end
				local fogK = p.z >= 15 and (1 - W.fog * 0.6) or (p.z >= 6 and (1 - W.fog * 0.3) or 1)
				local front = 1 + 0.25 * math.sin(sx / view.W * 5.0 - now * 1.3 * fdir)
				-- in the dark, rain shows faintly; where it passes through a light it glitters
				local a = Clamp((base * 1.5 * front + li * 1.0) * math.max(vis, li > 0.06 and 0.6 or 0.38) * fogK, 0, 0.95)
				if li > 0.06 then t:SetVertexColor(0.92, 0.9, 0.82, 1) else t:SetVertexColor(0.75, 0.80, 0.91, 1) end
				t:SetAlpha(a)
				ns.Layers.Place(t, sx - dx / 2, sy - len / 2, math.max(1, w * view.u * 1.6), math.sqrt(len * len + dx * dx))
				if t.SetRotation then t:SetRotation(math.atan2(dx, len)) end
				t:Show()
			end
		end
	end
	-- splashes: rings lying flat on the ground, and thrown droplets
	for _, sp in ipairs(splashes) do
		local t = sp.tex
		if sp.t < 0.26 and on then
			sp.t = sp.t + elapsed
			local k = Clamp(sp.t / 0.26, 0, 1)
			local sc = 3 / sp.z * view.u
			local rx = (3 + k * 13) * sc * (sp.body and 0.6 or 1)
			local li = ns.Layers.LightAt(sp.x, sp.y)
			local a = (1 - k) * (0.18 + li * 0.7) * math.max(vis, 0.35) * (sp.z > 9 and 0.6 or 1)
			if a > 0.01 and rx * 2 >= 3 then -- (a far splash smaller than that would only be a dot)
				t:SetVertexColor(0.82, 0.86, 0.94, 1)
				t:SetAlpha(Clamp(a * 1.6, 0, 1))
				ns.Layers.Place(t, sp.x, sp.y, rx * 2, rx * 2 * 0.28)
				t:Show()
			else
				t:Hide()
			end
		else
			t:Hide()
		end
	end
	for _, b in ipairs(bits) do
		local t = b.tex
		if b.t < 0.32 and on then
			b.t = b.t + elapsed
			b.vy = b.vy + b.g * elapsed
			b.x, b.y = b.x + b.vx * elapsed, b.y + b.vy * elapsed
			local li = ns.Layers.LightAt(b.x, b.y)
			t:SetColorTexture(0.84, 0.88, 0.96, Clamp((1 - b.t / 0.32) * (0.25 + li) * math.max(vis, 0.35), 0, 1))
			ns.Layers.Place(t, b.x, b.y, 1.4 * view.u, 1.4 * view.u)
			t:Show()
		else
			t:Hide()
		end
	end
	-- snow: flakes sway and drift; near ones are soft and out of focus. A blizzard drives them
	-- sideways; a dust storm uses the same flakes as small, fast, sandy grains.
	local dusty = W.dust > W.snow
	local nS = on and math.floor(math.max(W.snow, W.dust) * MAXS + 0.5) or 0
	local sway = wind * (dusty and 1.6 or (0.35 + 0.9 * W.snow * W.wind))
	for i = 1, MAXS do
		local f = flakes[i]
		local t = f.tex
		if i > nS then
			t:Hide()
		else
			f.y = f.y - f.v * elapsed * (dusty and 0.35 or 1)
			f.x = f.x + (sway + math.sin(now * 1.3 + f.ph) * f.amp) * elapsed + turn * f.z
			f.z = f.z - rush * 0.5
			local hx = HalfX(f.z)
			if f.z < 1.1 then NewFlake(f, false) f.y = rnd(0, TopY(f.z)) end
			if f.x > hx * 1.15 then f.x = f.x - 2.3 * hx elseif f.x < -hx * 1.15 then f.x = f.x + 2.3 * hx end
			local sx, sy = Project(f.x, f.y, f.z)
			if f.y <= 0 or HitsBody(sx, sy, f.z) then
				NewFlake(f, false)
				t:Hide()
			elseif sy < -20 or sy > view.H + 20 then
				t:Hide()
			else
				local r = Clamp(2.4 * 3 / f.z, 1.3, 9) * view.u * (dusty and 0.55 or 1)
				local li = ns.Layers.LightAt(sx, sy)
				local fogK = 1 - W.fog * 0.6 * math.min(1, f.z / 25)
				if dusty then t:SetVertexColor(0.80, 0.68, 0.50, 1) else t:SetVertexColor(0.93, 0.95, 1, 1) end
				t:SetAlpha(Clamp((0.9 + li * 0.6) * math.max(vis, 0.45) * fogK * (f.z < 2 and 0.55 or 1) * (r < 2.2 * view.u and 1.4 or 1) * (dusty and 0.55 or 1), 0, 1))
				ns.Layers.Place(t, sx, sy, r * 3.2, r * 3.2)
				t:Show()
			end
		end
	end
	-- fireflies: wander slowly, blink with long gaps, glow more the darker it is
	local nF = on and math.floor(W.ff * MAXF + 0.5) or 0
	local glow = 0.35 + 0.65 * math.min(1, d * 1.4)
	for i = 1, MAXF do
		local f = flies[i]
		local t = f.tex
		if i > nF then
			t:Hide()
		else
			f.vx = (f.vx + rnd(-0.3, 0.3) * elapsed) * 0.985
			f.vh = (f.vh + rnd(-0.15, 0.15) * elapsed) * 0.985
			f.vz = (f.vz + rnd(-0.4, 0.4) * elapsed) * 0.985
			f.x = f.x + f.vx * elapsed + wind * 0.02 * elapsed + turn * f.z
			f.h = Clamp(f.h + f.vh * elapsed, 0.03, 1.1)
			f.z = Clamp(f.z + f.vz * elapsed - rush * 0.3, 1.5, 26)
			local hx = HalfX(f.z)
			if f.x > hx then f.x = -hx elseif f.x < -hx then f.x = hx end
			local sx, sy = Project(f.x, f.h, f.z)
			local ph = ((now + f.ph) % f.per) / f.per
			local lit = ph < 0.22 and math.sin(ph / 0.22 * math.pi) or 0
			if lit < 0.02 then
				t:Hide()
			else
				local r = Clamp(18 * 3 / f.z, 4, 70) * view.u
				t:SetVertexColor(0.92, 0.97, 0.55, 1)
				t:SetAlpha(Clamp(lit * glow * (f.z < 2.6 and 0.35 or 1) * (1 - W.fog * 0.5 * math.min(1, f.z / 20)), 0, 1))
				ns.Layers.Place(t, sx, sy, r * 2, r * 2)
				t:Show()
			end
		end
	end
	weatherOn = on
end

ns.Register("weather", Wx)
