-- Party Map: quest markers from Questie, for the map on the second monitor.
-- Reads what Questie already worked out in game (its active quests' objective spawn lists, quest
-- finishers and the quests you can pick up), turns each spot into a point on OpenMap's world map
-- and groups nearby spots into areas. Everything is optional: without Questie there are no markers.
--
-- Lines (one per marker), positions on the world map as integers (x 100000):
--   M|questID|kind|objective|u|v|r|label
--   kind: a = objective area, f = hand-in (quest complete), g = quest giver (a quest you can pick up)

local addonName, ns = ...

local M = {}
ns.Markers = M

local floor, sqrt, max, min = math.floor, math.sqrt, math.max, math.min
local WORLD = 947
local SCALE = 100000

local CLUSTER = 0.008           -- spots this close (world units, 0..1) join one area
local MAX_AREAS = 6             -- per objective
local MAX_GIVERS = 30           -- nearest quest givers sent
local GIVER_RANGE = 0.06        -- how far from you a giver can be (world units)

local function Questie(name)
	if not QuestieLoader or not QuestieLoader.ImportModule then return end
	local ok, mod = pcall(QuestieLoader.ImportModule, QuestieLoader, name)
	if ok then return mod end
end

local rects = {}
local function ToWorld(uiMapID, x, y)
	if not uiMapID or uiMapID == 0 then return end
	if OpenMapAPI and OpenMapAPI.WorldFromMap then
		local ok, u, v = pcall(OpenMapAPI.WorldFromMap, uiMapID, x, y)
		u, v = ok and tonumber(u), ok and tonumber(v)
		if u and v then return u, v end
	end
	local r = rects[uiMapID]
	if r == nil then
		r = false
		local ok, l, rr, t, b = pcall(C_Map.GetMapRectOnMap, uiMapID, WORLD)
		if ok and l and rr and rr > l and b > t then r = { l, rr, t, b } end
		rects[uiMapID] = r
	end
	if r then return r[1] + x * (r[2] - r[1]), r[3] + y * (r[4] - r[3]) end
end

ns.ToWorld = ToWorld

-- every spot of a spawn table ({ [areaID] = { {x, y}, ... } }, x/y 0..100) as world points
-- a quest you've already taken, or already done (Questie's "!" list can lag behind for a moment)
local function OnQuest(qid)
	if C_QuestLog and C_QuestLog.IsOnQuest then
		local ok, on = pcall(C_QuestLog.IsOnQuest, qid)
		if ok and on == true then return true end
	end
	if GetQuestLogIndexByID then
		local ok, i = pcall(GetQuestLogIndexByID, qid)
		if ok and type(i) == "number" and i > 0 then return true end
	end
	return false
end
local function QuestDone(qid)
	local f = (C_QuestLog and C_QuestLog.IsQuestFlaggedCompleted) or IsQuestFlaggedCompleted
	if not f then return false end
	local ok, done = pcall(f, qid)
	return ok and done == true
end
M.OnQuest, M.QuestDone = OnQuest, QuestDone

local function AddSpawns(points, spawns, ZoneDB)
	if type(spawns) ~= "table" then return end
	for areaID, list in pairs(spawns) do
		local uiMapID = ZoneDB and ZoneDB.GetUiMapIdByAreaId and ZoneDB:GetUiMapIdByAreaId(areaID)
		if uiMapID and uiMapID ~= 0 and type(list) == "table" then
			for _, c in ipairs(list) do
				local x, y = c[1], c[2]
				if type(x) == "number" and type(y) == "number" and x >= 0 and y >= 0 then
					local u, v = ToWorld(uiMapID, x / 100, y / 100)
					if u then points[#points + 1] = { u, v } end
				end
			end
		end
	end
end

-- nearby points grouped into areas: { u, v, r, n }, biggest first
local function Cluster(points)
	local cl = {}
	for _, p in ipairs(points) do
		local best, bd
		for _, c in ipairs(cl) do
			local cu, cv = c.su / c.n, c.sv / c.n
			local d = (p[1] - cu) ^ 2 + (p[2] - cv) ^ 2
			if d < CLUSTER * CLUSTER and (not bd or d < bd) then best, bd = c, d end
		end
		if best then
			best.su, best.sv, best.n = best.su + p[1], best.sv + p[2], best.n + 1
			best.pts[#best.pts + 1] = p
		else
			cl[#cl + 1] = { su = p[1], sv = p[2], n = 1, pts = { p } }
		end
	end
	local out = {}
	for _, c in ipairs(cl) do
		local cu, cv = c.su / c.n, c.sv / c.n
		local r = 0
		for _, p in ipairs(c.pts) do r = max(r, sqrt((p[1] - cu) ^ 2 + (p[2] - cv) ^ 2)) end
		out[#out + 1] = { cu, cv, min(0.02, max(0.0015, r)), c.n }
	end
	table.sort(out, function(a, b) return a[4] > b[4] end)
	return out
end

local function Clean(s)
	if type(s) ~= "string" then return "" end
	return (s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("|", "/"):gsub("[\r\n]", " "))
end

local function Line(out, qid, kind, idx, u, v, r, label)
	out[#out + 1] = ("M|%d|%s|%d|%d|%d|%d|%s"):format(qid, kind, idx, floor(u * SCALE + 0.5), floor(v * SCALE + 0.5),
		floor(r * SCALE + 0.5), (label:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("[\r\n]", " ")))
end

-- quests: { { id, complete } , ... } from the quest log; px, py: your world position (or nil)
function M.Build(quests, px, py)
	local ActiveQuests, QuestieDB, ZoneDB = Questie("ActiveQuests"), Questie("QuestieDB"), Questie("ZoneDB")
	-- (a report of what Questie gave us for each quest, kept in the saved variables for checking)
	local dbg = { t = time and time() or 0, aq = ActiveQuests and true or false, db = QuestieDB and true or false, zdb = ZoneDB and true or false, quests = {} }
	if PartyMapDB then PartyMapDB.markerDebug = dbg end
	if not ActiveQuests or not QuestieDB or not ZoneDB then return "" end
	local out = {}
	for _, q in ipairs(quests) do
		local acc = ActiveQuests.Get and ActiveQuests.Get(q.id)
		local quest = acc and acc.quest
		local d = { id = q.id, complete = q.complete and true or false, acc = acc and true or false, quest = quest and true or false }
		dbg.quests[#dbg.quests + 1] = d
		if acc and not quest then
			local keys = {}
			for k in pairs(acc) do keys[#keys + 1] = tostring(k) end
			d.accKeys = table.concat(keys, ",")
		end
		if quest and not q.complete then
			d.objs = #(quest.Objectives or {})
			d.spawnLists, d.points = 0, 0
			for _, obj in ipairs(quest.Objectives or {}) do
				if type(obj.spawnList) == "table" then
					d.spawnLists = d.spawnLists + 1
					for _, sd in pairs(obj.spawnList) do
						if type(sd) == "table" and type(sd.Spawns) == "table" then
							for _, l in pairs(sd.Spawns) do if type(l) == "table" then d.points = d.points + #l end end
						end
					end
				end
				d.done = (d.done or 0) + (obj.Completed and 1 or 0)
			end
			local okeys = {}
			local o1 = (quest.Objectives or {})[1]
			if type(o1) == "table" then for k in pairs(o1) do okeys[#okeys + 1] = tostring(k) end end
			d.objKeys = table.concat(okeys, ",")
		end
		if quest then
			-- where to hand it in: a gold "?" once it's done (f), a grey one while you're on it (p)
			do
				local fin = quest.Finisher or {}
				local pts = {}
				local finNPC = fin.NPC and fin.NPC[1]
				for _, id in ipairs(fin.NPC or {}) do
					local ok, npc = pcall(QuestieDB.GetNPC, QuestieDB, id)
					if ok and npc then AddSpawns(pts, npc.spawns, ZoneDB) end
				end
				for _, id in ipairs(fin.GameObject or {}) do
					local ok, obj = pcall(QuestieDB.GetObject, QuestieDB, id)
					if ok and obj then AddSpawns(pts, obj.spawns, ZoneDB) end
				end
				local kind = q.complete and "f" or "p"
				for i, c in ipairs(Cluster(pts)) do
					if i > (q.complete and 2 or 1) then break end
					Line(out, q.id, finNPC and (kind .. ":" .. finNPC) or kind, 0, c[1], c[2], 0,
						Clean((q.complete and "Hand in: " or "On it: ") .. (q.title or "")))
				end
			end
			if not q.complete then
				-- where each unfinished objective is (the spots Questie draws)
				for idx, obj in ipairs(quest.Objectives or {}) do
					-- (finished objectives stay on the map, ticked, until the quest is handed in)
					if type(obj.spawnList) == "table" then
						local pts = {}
						for _, spawnData in pairs(obj.spawnList) do
							if type(spawnData) == "table" then AddSpawns(pts, spawnData.Spawns, ZoneDB) end
						end
						local label = obj.Description
						-- who or what it comes from (the names Questie lists), for the map's hover card
						local from, seen = {}, {}
						for _, spawnData in pairs(obj.spawnList) do
							local n = type(spawnData) == "table" and spawnData.Name
							if n and not seen[n] and #from < 3 then seen[n] = true; from[#from + 1] = Clean(n) end
						end
						if not label or label == "" then label = from[1] end
						-- what kind of objective: kill, loot, use an object, explore
						local t = obj.Type
						local kind = "a" .. ((t == "monster" or t == "killcredit") and "k" or t == "item" and "l" or t == "object" and "o" or t == "event" and "e" or "")
						-- the thing's own icon (an item to loot: its bag icon) and, for a kill, the creature
						local icon, npcID = "", ""
						if t == "item" and type(obj.Id) == "number" then
							local f = (C_Item and C_Item.GetItemIconByID) or GetItemIcon
							local ok, fid = pcall(f, obj.Id)
							if ok and type(fid) == "number" then icon = tostring(fid) end
						end
						if t == "monster" or t == "killcredit" then
							for id in pairs(obj.spawnList) do if type(id) == "number" then npcID = tostring(id); break end end
						end
						for i, c in ipairs(Cluster(pts)) do
							if i > MAX_AREAS then break end
							Line(out, q.id, kind, idx, c[1], c[2], c[3], Clean(label or "") .. "|" .. table.concat(from, ", ") .. "|" .. icon .. "|" .. npcID)
						end
					end
				end
			end
		end
	end
	-- quests you can pick up nearby (Questie's "!")
	local Available = Questie("AvailableQuests")
	local byNpc = Available and Available.__availableQuestsByNpc
	if px and py and type(byNpc) == "table" then
		local inLog = {}
		for _, q in ipairs(quests) do inLog[q.id] = true end
		local givers = {}
		for npcID, qs in pairs(byNpc) do
			local ok, npc = pcall(QuestieDB.GetNPC, QuestieDB, npcID)
			if ok and npc and type(qs) == "table" then
				local pts = {}
				AddSpawns(pts, npc.spawns, ZoneDB)
				local qid, n = nil, 0
				for id in pairs(qs) do
					if not inLog[id] and not OnQuest(id) and not QuestDone(id) then
						if not qid or id < qid then qid = id end
						n = n + 1
					end
				end
				for _, p in ipairs(pts) do
					local d = (p[1] - px) ^ 2 + (p[2] - py) ^ 2
					if d < GIVER_RANGE * GIVER_RANGE and qid then
						givers[#givers + 1] = { d = d, u = p[1], v = p[2], qid = qid, npc = npcID,
							label = (npc.name or "Quest giver") .. (n > 1 and (" (" .. n .. " quests)") or "") }
						break
					end
				end
			end
		end
		-- the nearest, but listed in a steady order: walking about shouldn't change the list (each
		-- change starts its trip down the strip again)
		table.sort(givers, function(a, b) return a.d < b.d end)
		local near = {}
		for i, g in ipairs(givers) do if i <= MAX_GIVERS then near[#near + 1] = g end end
		table.sort(near, function(a, b) return (a.npc or 0) < (b.npc or 0) end)
		for _, g in ipairs(near) do
			Line(out, g.qid, g.npc and ("g:" .. g.npc) or "g", 0, g.u, g.v, 0, Clean(g.label))
		end
	end
	return table.concat(out, "\n")
end

--------------------------------------------------------------------------------
-- Places: townsfolk from Questie's NPC database (as OpenMap's own townsfolk pins read it), for the
-- map's Places layers. Built once, a few hundred NPCs a frame, then the nearest are sent:
--   T|kind|u|v|name|subname
--   kind: v vendor, r repair, i innkeeper, b banker, a auctioneer, s stable master,
--         c your class trainer, p profession trainer, f flight master, m mailbox
--------------------------------------------------------------------------------
local PLACE_KINDS = {
	{ "v", "VENDOR" }, { "r", "REPAIR" }, { "i", "INNKEEPER" }, { "b", "BANKER" }, { "a", "AUCTIONEER" },
	{ "s", "STABLEMASTER" }, { "t", "TRAINER" }, { "f", "FLIGHT_MASTER", 8192 },
}
local CLASS_NAMES = {
	WARRIOR = "warrior", PALADIN = "paladin", HUNTER = "hunter", ROGUE = "rogue", PRIEST = "priest", SHAMAN = "shaman",
	MAGE = "mage", WARLOCK = "warlock", DRUID = "druid", DEATHKNIGHT = "death knight", MONK = "monk",
	DEMONHUNTER = "demon hunter", EVOKER = "evoker",
}
local places, placesState, placesTries = {}, "none", 0   -- placesState: none / building / done
M.places = places
-- lights for the map's night: where friendly townsfolk stand (guards, dockhands, shopkeepers' doors),
-- the nearest sent as "L|" lines of base-36 spots
local lights = {}
M.lights = lights

local function Middle(coords)
	local sx, sy, n = 0, 0, 0
	for _, c in ipairs(coords) do
		if c[1] and c[1] >= 0 then sx, sy, n = sx + c[1], sy + c[2], n + 1 end
	end
	if n == 0 then return coords end
	sx, sy = sx / n, sy / n
	local best, bd
	for _, c in ipairs(coords) do
		if c[1] and c[1] >= 0 then
			local d = (c[1] - sx) ^ 2 + (c[2] - sy) ^ 2
			if not bd or d < bd then best, bd = c, d end
		end
	end
	return { best }
end

local function AddPlace(kind, spawns, name, sub, ZoneDB, npcID)
	if type(spawns) ~= "table" then return end
	for areaID, coords in pairs(spawns) do
		if type(coords) == "table" then
			if #coords > 6 then coords = Middle(coords) end
			local uiMapID = ZoneDB:GetUiMapIdByAreaId(areaID)
			for _, c in ipairs(coords) do
				if uiMapID and c[1] and c[1] >= 0 and c[2] then
					local u, v = ToWorld(uiMapID, c[1] / 100, c[2] / 100)
					if u then places[#places + 1] = { kind, u, v, Clean(name):sub(1, 28), Clean(sub or ""):sub(1, 26), uiMapID, npcID } end
				end
			end
		end
	end
end

function M.BuildPlaces()
	if placesState ~= "none" then return end
	local QDB, ZoneDB = Questie("QuestieDB"), Questie("ZoneDB")
	if not (QDB and ZoneDB and QDB.NPCPointers and QDB.QueryNPCSingle and ZoneDB.GetUiMapIdByAreaId) then
		placesTries = placesTries + 1
		if placesTries < 12 and C_Timer then C_Timer.After(5, M.BuildPlaces) end
		return
	end
	placesState = "building"
	local flags = QDB.npcFlags or {}
	local faction = UnitFactionGroup and UnitFactionGroup("player") == "Horde" and "H" or "A"
	local myClass = select(2, UnitClass("player"))
	local ids = {}
	for id in pairs(QDB.NPCPointers) do ids[#ids + 1] = id end
	local i = 0
	local function Chunk()
		for _ = 1, 300 do
			i = i + 1
			local id = ids[i]
			if not id then return true end
			local f = QDB.QueryNPCSingle(id, "npcFlags") or 0
			local friendly = QDB.QueryNPCSingle(id, "friendlyToFaction") or ""
			-- (a light where a friendly NPC stands still: not wanderers or critters with lots of spawns)
			if type(friendly) == "string" and friendly:find(faction, 1, true) then
				local sp = QDB.QueryNPCSingle(id, "spawns")
				if type(sp) == "table" then
					for areaID, coords in pairs(sp) do
						if type(coords) == "table" and #coords <= 3 then
							local uiMapID = ZoneDB:GetUiMapIdByAreaId(areaID)
							for _, c in ipairs(coords) do
								if uiMapID and c[1] and c[1] >= 0 and c[2] then
									local u, v = ToWorld(uiMapID, c[1] / 100, c[2] / 100)
									if u then lights[#lights + 1] = { u, v } end
								end
							end
						end
					end
				end
			end
			if f ~= 0 then
				if type(friendly) == "string" and friendly:find(faction, 1, true) then
					local spawns, name, sub
					for _, k in ipairs(PLACE_KINDS) do
						local bitv = flags[k[2]] or k[3]
						if bitv and bit.band(f, bitv) ~= 0 then
							local kind = k[1]
							sub = sub or QDB.QueryNPCSingle(id, "subName") or ""
							if kind == "t" then
								local low, cls = sub:lower(), nil
								for token, n in pairs(CLASS_NAMES) do
									if low:find(n, 1, true) and (not cls or #n > #CLASS_NAMES[cls]) then cls = token end
								end
								if cls == nil then kind = "p" elseif cls == myClass then kind = "c" else kind = nil end
							end
							if kind then
								spawns = spawns or QDB.QueryNPCSingle(id, "spawns")
								name = name or QDB.QueryNPCSingle(id, "name") or "?"
								AddPlace(kind, spawns, name, sub, ZoneDB, id)
							end
						end
					end
				end
			end
		end
	end
	-- mailboxes: objects, from Questie's own list of them
	pcall(function()
		local folk = Questie("Townsfolk")
		if not (folk and QDB.QueryObjectSingle) then return end
		local list
		if folk.GetFactionSpecificMailboxes then
			local ok, a, h = pcall(folk.GetFactionSpecificMailboxes)
			if ok then list = faction == "H" and h or a end
		end
		if (type(list) ~= "table" or #list == 0) and folk.GetMailboxes then list = folk.GetMailboxes() end
		for _, id in ipairs(list or {}) do AddPlace("m", QDB.QueryObjectSingle(id, "spawns"), MINIMAP_TRACKING_MAILBOX or "Mailbox", "", ZoneDB) end
	end)
	local function Step()
		local ok, finished = pcall(Chunk)
		if not ok then placesState = "done" return end
		if finished then placesState = "done" if M.onPlaces then M.onPlaces() end return end
		C_Timer.After(0, Step)
	end
	Step()
end

-- the lights near you: "L|" + up to 7 spots of 8 base-36 letters (u, v × 100000, 4 letters each)
local function B36(n)
	n = math.max(0, math.min(1679615, floor(n + 0.5)))
	local d, out = "0123456789abcdefghijklmnopqrstuvwxyz", ""
	for _ = 1, 4 do local r = n % 36; out = d:sub(r + 1, r + 1) .. out; n = (n - r) / 36 end
	return out
end
function M.LightsNear(px, py)
	if not px then return {} end
	local near = {}
	for _, l in ipairs(lights) do
		local d = (l[1] - px) ^ 2 + (l[2] - py) ^ 2
		if d < 0.035 * 0.035 then near[#near + 1] = { d, l } end
	end
	table.sort(near, function(a, b) return a[1] < b[1] end)
	local out, line, n = {}, {}, 0
	for i = 1, min(210, #near) do
		local l = near[i][2]
		line[#line + 1] = B36(l[1] * SCALE) .. B36(l[2] * SCALE)
		if #line == 7 then out[#out + 1] = "L|" .. table.concat(line); line = {} end
	end
	if #line > 0 then out[#out + 1] = "L|" .. table.concat(line) end
	return out
end

-- the places near you, nearest first: about 110 lines, plus flight masters further out
function M.PlacesNear(px, py)
	local near, far = {}, {}
	if not px then return {} end
	for _, p in ipairs(places) do
		local d = (p[2] - px) ^ 2 + (p[3] - py) ^ 2
		if d < 0.05 * 0.05 then near[#near + 1] = { d, p }
		elseif p[1] == "f" and d < 0.2 * 0.2 then far[#far + 1] = { d, p } end
	end
	table.sort(near, function(a, b) return a[1] < b[1] end)
	table.sort(far, function(a, b) return a[1] < b[1] end)
	local out = {}
	local function Add(p)
		-- "T|kind|u|v|name|sub|npcID" (the NPC's ID last, so a long sub-name loses letters, not the ID)
		local tail = p[7] and ("|" .. p[7]) or ""
		local head = ("T|%s|%d|%d|%s|%s"):format(p[1], floor(p[2] * SCALE + 0.5), floor(p[3] * SCALE + 0.5), p[4], p[5])
		out[#out + 1] = head:sub(1, 67 - #tail) .. tail
	end
	for i = 1, min(110, #near) do Add(near[i][2]) end
	for i = 1, min(24, #far) do Add(far[i][2]) end
	return out
end

-- each continent's corners in the game's yards and on the world map, for the app's close-up
-- detail (the game's minimap tiles are laid out in yards):
--   Y|continent|x0|y0|x1|y1|l|t|r|b|swap   (yards x10, world x1000000)
local CONT_MAP = { [0] = 1415, [1] = 1414 }
local yardsPerUnit   -- (yards in one world unit, from the corners: for distances in chat)
function M.Corners()
	local out = {}
	if not (C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return out end
	for cont, mapID in pairs(CONT_MAP) do
		local ok0, _, p0 = pcall(C_Map.GetWorldPosFromMapPos, mapID, CreateVector2D(0, 0))
		local ok1, _, p1 = pcall(C_Map.GetWorldPosFromMapPos, mapID, CreateVector2D(1, 1))
		local l, t = ToWorld(mapID, 0, 0)
		local r, b = ToWorld(mapID, 1, 1)
		if ok0 and ok1 and p0 and p1 and l and r then
			local okA, x0, y0 = pcall(p0.GetXY, p0)
			local okB, x1, y1 = pcall(p1.GetXY, p1)
			local okS, secret = pcall(function() return issecretvalue and (issecretvalue(x0) or issecretvalue(x1)) end)
			if okA and okB and x0 and x1 and x1 ~= x0 and y1 ~= y0 and not (okS and secret) then
				-- which way the map's x runs (OpenMap checks the same: Stormwind's flight master)
				local swap = 0
				local sl, st = ToWorld(1453, 0, 0)
				local sr, sb = ToWorld(1453, 1, 1)
				if cont == 0 and sl then
					local function Proj(wx, wy, sw)
						local mx, my
						if sw then mx, my = (wx - x0) / (x1 - x0), (wy - y0) / (y1 - y0)
						else mx, my = (wy - y0) / (y1 - y0), (wx - x0) / (x1 - x0) end
						return l + mx * (r - l), t + my * (b - t)
					end
					local u, v = Proj(-8840.6, 489.7, false)
					if not (u >= sl and u <= sr and v >= st and v <= sb) then
						u, v = Proj(-8840.6, 489.7, true)
						if u >= sl and u <= sr and v >= st and v <= sb then swap = 1 end
					end
				end
				if r ~= l then yardsPerUnit = math.abs((swap == 1 and (x1 - x0) or (y1 - y0)) / (r - l)) end
				out[#out + 1] = ("Y|%d|%d|%d|%d|%d|%d|%d|%d|%d|%d"):format(cont, floor(x0 * 10 + 0.5), floor(y0 * 10 + 0.5),
					floor(x1 * 10 + 0.5), floor(y1 * 10 + 0.5), floor(l * 1e6 + 0.5), floor(t * 1e6 + 0.5), floor(r * 1e6 + 0.5), floor(b * 1e6 + 0.5), swap)
			end
		end
	end
	return out
end

--------------------------------------------------------------------------------
-- Training: what you can learn now (and next level), from the WhatsTraining addon's WT_API, and
-- the nearest trainer of your class (from the places above). Lines for the quest blob:
--   R|a|cost|level|name|rank     (a = can learn now, n = next level; cost in copper)
--   RT|name|zone|u|v|yards       (the nearest class trainer)
--------------------------------------------------------------------------------
local function ZoneName(uiMapID)
	local info = uiMapID and C_Map and C_Map.GetMapInfo and C_Map.GetMapInfo(uiMapID)
	return info and info.name or ""
end

function M.NearestPlace(kind, px, py)
	local best, bd
	if not px then return end
	for _, p in ipairs(places) do
		if p[1] == kind then
			local d = (p[2] - px) ^ 2 + (p[3] - py) ^ 2
			if not bd or d < bd then best, bd = p, d end
		end
	end
	if not best then return end
	return best, math.sqrt(bd), ZoneName(best[6])
end

function M.Yards(units)
	if not yardsPerUnit then pcall(M.Corners) end
	return yardsPerUnit and math.floor(units * yardsPerUnit + 0.5) or nil
end

-- the spells WhatsTraining says you can learn now / next level
function M.TrainList()
	local api = rawget(_G, "WT_API")
	if not (api and api.IsReady and api.IsReady() and api.GetSpells and api.Status) then return end
	local now, nextL = {}, {}
	local ok, spells = pcall(api.GetSpells)
	if not ok or type(spells) ~= "table" then return end
	for _, sp in ipairs(spells) do
		if sp.status == api.Status.AVAILABLE then now[#now + 1] = sp
		elseif sp.status == api.Status.NEXTLEVEL then nextL[#nextL + 1] = sp end
	end
	local function order(a, b)
		if (a.level or 0) ~= (b.level or 0) then return (a.level or 0) < (b.level or 0) end
		return (a.name or "") < (b.name or "")
	end
	table.sort(now, order)
	table.sort(nextL, order)
	return now, nextL
end

function M.TrainingLines(px, py)
	local now, nextL = M.TrainList()
	if not now then return {} end
	local out = {}
	local function Add(flag, sp)
		out[#out + 1] = ("R|%s|%d|%d|%s|%s"):format(flag, sp.cost or 0, sp.level or 0, Clean(sp.name or "?"):sub(1, 40), Clean(sp.subText or ""):sub(1, 20))
	end
	for i = 1, min(30, #now) do Add("a", now[i]) end
	for i = 1, min(15, #nextL) do Add("n", nextL[i]) end
	local t, d, zone = M.NearestPlace("c", px, py)
	if t then
		out[#out + 1] = ("RT|%s|%s|%d|%d|%d"):format(t[4], Clean(zone), floor(t[2] * SCALE + 0.5), floor(t[3] * SCALE + 0.5), M.Yards(d) or -1)
	end
	return out
end

function M.Money(c)
	c = c or 0
	local g, s, k = floor(c / 10000), floor(c / 100) % 100, c % 100
	local out = {}
	if g > 0 then out[#out + 1] = g .. "g" end
	if s > 0 then out[#out + 1] = s .. "s" end
	if k > 0 or #out == 0 then out[#out + 1] = k .. "c" end
	return table.concat(out, " ")
end

-- the chat note on reaching a level with something to learn
function M.TrainingNote(level, px, py)
	local now = M.TrainList()
	if not now or #now == 0 then return end
	local total, names = 0, {}
	for i, sp in ipairs(now) do
		total = total + (sp.cost or 0)
		if i <= 6 then names[#names + 1] = (sp.name or "?") .. ((sp.subText and sp.subText ~= "") and (" (" .. sp.subText .. ")") or "") end
	end
	if #now > 6 then names[#names + 1] = ("and %d more"):format(#now - 6) end
	local msg = ("|cffF0B04AParty Map|r Level %d: %d to train for %s: %s."):format(level or UnitLevel("player"), #now, M.Money(total), table.concat(names, ", "))
	local t, d, zone = M.NearestPlace("c", px, py)
	if t then
		local y = M.Yards(d)
		msg = msg .. (" Nearest trainer: %s%s%s."):format(t[4], zone ~= "" and (", " .. zone) or "", y and (" (about " .. y .. " yards)") or "")
	end
	print(msg)
end

--------------------------------------------------------------------------------
-- Zones: each zone's rectangle on the world map ("Z|uiMapID|u0|v0|u1|v1", x 1e6), so the app can place
-- OpenMap's dungeon entrances that are given as a spot on a zone's map
--------------------------------------------------------------------------------

-- which continent a spot on a map is on (the game's instance: 0 Eastern Kingdoms, 1 Kalimdor)
function M.ContinentOf(mapID, x, y)
	if not (mapID and C_Map and C_Map.GetWorldPosFromMapPos and CreateVector2D) then return end
	local ok, cont = pcall(C_Map.GetWorldPosFromMapPos, mapID, CreateVector2D(x, y))
	if ok and type(cont) == "number" then return cont end
end

local zoneLines
function M.Zones()
	if zoneLines and #zoneLines > 0 then return zoneLines end
	local out, seen = {}, {}
	local function Add(id)
		if seen[id] then return end
		seen[id] = true
		local u0, v0 = ToWorld(id, 0, 0)
		local u1, v1 = ToWorld(id, 1, 1)
		if u0 and u1 and u1 > u0 and v1 > v0 then
			out[#out + 1] = ("Z|%d|%d|%d|%d|%d|%d"):format(id, floor(u0 * 1e6 + 0.5), floor(v0 * 1e6 + 0.5), floor(u1 * 1e6 + 0.5), floor(v1 * 1e6 + 0.5), M.ContinentOf(id, 0.5, 0.5) or -1)
		end
	end
	if C_Map and C_Map.GetMapChildrenInfo then
		local ok, kids = pcall(C_Map.GetMapChildrenInfo, WORLD, nil, true)
		if ok and type(kids) == "table" then
			local Z, O = Enum and Enum.UIMapType and Enum.UIMapType.Zone or 3, Enum and Enum.UIMapType and Enum.UIMapType.Orphan or 6
			for _, k in ipairs(kids) do
				if k.mapID and (k.mapType == Z or k.mapType == O) then Add(k.mapID) end
			end
		end
	end
	zoneLines = out
	return out
end

--------------------------------------------------------------------------------
-- Recommended quests: of the quests Questie says you can pick up, the ones worth it now: at your level
-- (not grey, not far above), givers close by, and first of all the ones a friend in the party is on
-- (so you can do them together). "RQ|questID|questLevel|requiredLevel|u|v|tag|giver|title"
-- (tag: f a friend has it, d dungeon, r raid, e elite/group, "" normal)
--------------------------------------------------------------------------------

local MAX_REC = 8
local ln = { lines = {}, at = -1e9, wantAt = 0 }   -- where to level next's scan (below)
local REC_RANGE = 3500          -- yards (or REC_RANGE_U world units without the continents' corners)
local REC_RANGE_U = 0.12
local npcPoints, questInfo = {}, {}

local function GreenRange(level)
	if GetQuestGreenRange then
		local ok, g = pcall(GetQuestGreenRange)
		if ok and type(g) == "number" and g > 0 then return g end
	end
	if level <= 9 then return 5 elseif level <= 19 then return 6 elseif level <= 29 then return 7 elseif level <= 39 then return 8 end
	return 9
end

local function QuestInfo(QDB, qid)
	local q = questInfo[qid]
	if q == nil then
		q = false
		local function Get(field)
			local ok, v = pcall(QDB.QueryQuestSingle, qid, field)
			if ok then return v end
		end
		local name = Get("name")
		if type(name) == "string" then q = { name = name, level = tonumber(Get("questLevel")) or 0, req = tonumber(Get("requiredLevel")) or 0, races = Get("requiredRaces") } end
		questInfo[qid] = q
	end
	return q or nil
end

local function QuestTag(QDB, qid)
	local q = questInfo[qid]
	if q and q.tag ~= nil then return q.tag end
	local tag = ""
	local function Is(fn) local f = QDB[fn]; if not f then return false end; local ok, r = pcall(f, qid); return ok and r end
	if Is("IsRaidQuest") then tag = "r" elseif Is("IsDungeonQuest") then tag = "d" elseif Is("IsGroupQuest") then tag = "e" end
	if q then q.tag = tag end
	return tag
end

-- the side a quest is for, from its race mask (Forever's masks go past 32 bits, so by arithmetic):
-- Questie's own race test goes wrong for some of Forever's races (a Horde character shown the
-- Alliance's quests and none of the Horde's), so the scan tests the side instead
local ALLIANCE_BITS = { 1, 4, 8, 64, 1024, 2097152, 16777216, 4294967296 }
local HORDE_BITS = { 2, 16, 32, 128, 256, 512, 33554432, 8589934592 }
local function HasBit(mask, b) return mask % (2 * b) >= b end
local function ForMySide(mask, side)
	mask = tonumber(mask)
	if not mask or mask <= 0 then return true end
	for _, b in ipairs(side == "Alliance" and ALLIANCE_BITS or HORDE_BITS) do
		if HasBit(mask, b) then return true end
	end
	-- (a mask of neither side's races: Questie's data for something unusual; let Questie decide)
	for _, b in ipairs(side == "Alliance" and HORDE_BITS or ALLIANCE_BITS) do
		if HasBit(mask, b) then return false end
	end
	return true
end
M.ForMySide = ForMySide

-- friends: { [questID] = true } of the quests party members have
function M.Recommend(px, py, level, friends)
	local Available, QDB, ZoneDB = Questie("AvailableQuests"), Questie("QuestieDB"), Questie("ZoneDB")
	local byNpc = Available and Available.__availableQuestsByNpc
	-- (and the ones Where to level next found: Questie's own list misses a whole side's quests for
	-- some of Forever's races)
	local mine = ln.byNpc
	if type(mine) == "table" and next(mine) then
		local merged = {}
		if type(byNpc) == "table" then for npc, qs in pairs(byNpc) do merged[npc] = qs end end
		for npc, qs in pairs(mine) do
			if type(merged[npc]) == "table" then
				local both = {}
				for q in pairs(merged[npc]) do both[q] = true end
				for q in pairs(qs) do both[q] = true end
				merged[npc] = both
			else
				merged[npc] = qs
			end
		end
		byNpc = merged
	end
	if not (px and py and level and level > 0 and QDB and type(byNpc) == "table") then return {} end
	if not yardsPerUnit then pcall(M.Corners) end
	local ypu = yardsPerUnit
	local green = GreenRange(level)
	local okf, side = pcall(UnitFactionGroup, "player")
	side = okf and side or "Horde"
	local best = {}
	local budget = 120              -- new givers looked up per call (the rest next time: no hitch at login)
	for npcID, qs in pairs(byNpc) do
		if type(qs) == "table" and (npcPoints[npcID] ~= nil or budget > 0) then
			local pts = npcPoints[npcID]
			if pts == nil then
				budget = budget - 1
				pts = {}
				local ok, npc = pcall(QDB.GetNPC, QDB, npcID)
				if ok and npc then
					AddSpawns(pts, npc.spawns, ZoneDB)
					pts.name = npc.name
				end
				npcPoints[npcID] = pts
			end
			-- the giver's nearest spot
			local bu, bv, bd
			for _, p in ipairs(pts) do
				local d = (p[1] - px) ^ 2 + (p[2] - py) ^ 2
				if not bd or d < bd then bu, bv, bd = p[1], p[2], d end
			end
			if bd then
				local dist = sqrt(bd)
				local yd = ypu and dist * ypu
				for qid in pairs(qs) do
					local q = not OnQuest(qid) and not QuestDone(qid) and QuestInfo(QDB, qid)
					if q and not ForMySide(q.races, side) then q = nil end
					local f = friends and friends[qid]
					if q and (f or (yd and yd < REC_RANGE) or (not yd and dist < REC_RANGE_U)) then
						local ql = q.level > 0 and q.level or level
						if (f or ql >= level - green) and ql <= level + 4 then
							-- yards, plus 300 a level away from one above yours; a friend's quest goes first
							local score = (yd or dist / REC_RANGE_U * REC_RANGE) + math.abs(ql - (level + 1)) * 300 - (f and 6000 or 0)
							local old = best[qid]
							if not old or score < old.score then
								best[qid] = { qid = qid, score = score, u = bu, v = bv, q = q, ql = ql, giver = pts.name or "Quest giver", f = f }
							end
						end
					end
				end
			end
		end
	end
	local list = {}
	for _, b in pairs(best) do list[#list + 1] = b end
	table.sort(list, function(a, b) return a.score < b.score end)
	local out = {}
	for _, b in ipairs(list) do
		if #out >= MAX_REC then break end
		local tag = QuestTag(QDB, b.qid)
		if not (tag == "r" and level < 58) then
			if b.f then tag = "f" .. tag end
			out[#out + 1] = ("RQ|%d|%d|%d|%d|%d|%s|%s|%s"):format(b.qid, b.ql, b.q.req, floor(b.u * SCALE + 0.5), floor(b.v * SCALE + 0.5),
				tag, Clean(b.giver):sub(1, 30), Clean(b.q.name):sub(1, 50))
		end
	end
	return out
end

--------------------------------------------------------------------------------
-- Gathering spots from GatherMate2 (the ones it shows: its own filters) and rares from SilverDragon,
-- near you, for the map's layers. "G|kind|u|v|name|icon" (kind h herb, o ore, f fish, t treasure;
-- icon: GatherMate2's Artwork path, e.g. Herb/peacebloom) and "S|mobID|u|v|spots|lastSeen|name"
-- icon: the file name in GatherMate2's Artwork folder for the kind) (lastSeen: seconds ago, -1 never). A rare SilverDragon has just seen: "RS|mobID|u|v|age|dead|name".
--------------------------------------------------------------------------------

local GM_KINDS = { ["Herb Gathering"] = "h", ["Mining"] = "o", ["Fishing"] = "f", ["Treasure"] = "t" }
local NODE_RANGE, MAX_NODES = 0.035, 120
local zoneBoxes                 -- { { id, u0, v0, u1, v1 } } the zones on the world map

local function ZoneBoxes()
	if zoneBoxes and #zoneBoxes > 0 then return zoneBoxes end
	zoneBoxes = {}
	for _, l in ipairs(M.Zones()) do
		local id, a, b, c, d = l:match("^Z|(%d+)|(%d+)|(%d+)|(%d+)|(%d+)")
		if id then zoneBoxes[#zoneBoxes + 1] = { tonumber(id), a / 1e6, b / 1e6, c / 1e6, d / 1e6 } end
	end
	return zoneBoxes
end
-- the zones whose box comes within r of a point
local function ZonesNear(px, py, r)
	local out = {}
	for _, z in ipairs(ZoneBoxes()) do
		if px + r >= z[2] and px - r <= z[4] and py + r >= z[3] and py - r <= z[5] then out[#out + 1] = z[1] end
	end
	return out
end

local function GatherMate()
	local AceAddon = LibStub and LibStub("AceAddon-3.0", true)
	local gm = AceAddon and AceAddon:GetAddon("GatherMate2", true)
	if gm and gm.GetNodesForZone and gm.DecodeLoc and gm.reverseNodeIDs then return gm end
end

function M.NodesNear(px, py)
	local gm = GatherMate()
	if not (gm and px) then return {} end
	local found = {}
	for _, zone in ipairs(ZonesNear(px, py, NODE_RANGE)) do
		for dbName, kind in pairs(GM_KINDS) do
			local ok, iter, state, init = pcall(gm.GetNodesForZone, gm, zone, dbName, false)
			if ok and iter then
				for coord, nodeID in iter, state, init do
					local x, y = gm:DecodeLoc(coord)
					local u, v = ToWorld(zone, x, y)
					if u then
						local d = (u - px) ^ 2 + (v - py) ^ 2
						if d < NODE_RANGE * NODE_RANGE then
							local name = gm.reverseNodeIDs[dbName] and gm.reverseNodeIDs[dbName][nodeID] or "?"
							local tex = gm.nodeTextures and gm.nodeTextures[dbName] and gm.nodeTextures[dbName][nodeID]
							-- (the icon's file name; its folder goes with the kind)
							tex = type(tex) == "string" and tex:match("([^\\/]+)%.%a+$") or ""
							found[#found + 1] = { d = d, line = ("G|%s|%d|%d|%s|%s"):format(kind, floor(u * SCALE + 0.5), floor(v * SCALE + 0.5), Clean(name):sub(1, 24), tex:sub(1, 24)) }
						end
					end
				end
			end
		end
	end
	table.sort(found, function(a, b) return a.d < b.d end)
	local out = {}
	for i = 1, min(MAX_NODES, #found) do out[i] = found[i].line end
	return out
end

-- SilverDragon's rares: every spawn point, read once (a few hundred mobs a frame) into world points
local SD_RANGE, MAX_RARES = 0.06, 25
local rarePoints, rareBuilding     -- { { id, u, v, zone } }
local function SilverDragon()
	local sd = rawget(_G, "SilverDragon")
	if sd and sd.datasources and sd.db and sd.db.global then return sd end
end
local function BuildRares()
	local sd = SilverDragon()
	if not sd or rareBuilding then return end
	rareBuilding = true
	local list, pts = {}, {}
	for source, data in pairs(sd.datasources) do
		if sd.db.global.datasources == nil or sd.db.global.datasources[source] ~= false then
			for id, mob in pairs(data) do if type(mob) == "table" and mob.locations then list[#list + 1] = { id, mob } end end
		end
	end
	local i = 1
	local function Step()
		local n = 0
		while i <= #list and n < 200 do
			local id, mob = list[i][1], list[i][2]
			for zone, coords in pairs(mob.locations) do
				if type(coords) == "table" then
					for _, c in ipairs(coords) do
						if type(c) == "number" then
							local u, v = ToWorld(zone, floor(c / 10000) / 10000, (c % 10000) / 10000)
							if u then pts[#pts + 1] = { id, u, v, zone } end
						end
					end
				end
			end
			i, n = i + 1, n + 1
		end
		if i <= #list and C_Timer then C_Timer.After(0, Step) else rarePoints, rareBuilding = pts, false end
	end
	Step()
end
function M.RaresNear(px, py)
	local sd = SilverDragon()
	if not (sd and px) then return {} end
	if not rarePoints then BuildRares() return {} end
	local best, spots = {}, {}
	for _, p in ipairs(rarePoints) do
		local d = (p[2] - px) ^ 2 + (p[3] - py) ^ 2
		if d < SD_RANGE * SD_RANGE then
			spots[p[1]] = (spots[p[1]] or 0) + 1
			if not best[p[1]] or d < best[p[1]].d then best[p[1]] = { d = d, u = p[2], v = p[3], zone = p[4] } end
		end
	end
	local list = {}
	for id, b in pairs(best) do
		local ok, ignore = pcall(sd.ShouldIgnoreMob, sd, id, b.zone)
		if not (ok and ignore) then list[#list + 1] = { id = id, b = b } end
	end
	table.sort(list, function(a, b) return a.b.d < b.b.d end)
	local out, now = {}, time and time() or 0
	local seen = sd.db.global.mob_seen or {}
	for i = 1, min(MAX_RARES, #list) do
		local id, b = list[i].id, list[i].b
		local okn, name = pcall(sd.GetMobLabel, sd, id)
		local last = (type(seen[id]) == "number" and seen[id] > 0) and (now - seen[id]) or -1
		out[#out + 1] = ("S|%d|%d|%d|%d|%d|%s"):format(id, floor(b.u * SCALE + 0.5), floor(b.v * SCALE + 0.5), spots[id] or 1, last, Clean(okn and name or "Rare"):sub(1, 30))
	end
	return out
end
-- rares SilverDragon has just seen (its "Seen" callback), for 10 minutes
local seenRares = {}
function M.HookSilverDragon()
	local sd = SilverDragon()
	if not sd or not sd.RegisterCallback or M.sdHooked then return end
	M.sdHooked = true
	sd.RegisterCallback(M, "Seen", function(_, id, zone, x, y, dead)
		if type(id) ~= "number" then return end
		local u, v = ToWorld(zone, x or 0, y or 0)
		if not u or (x == 0 and y == 0) then
			-- (no spot given: where you are)
			local m = C_Map.GetBestMapForUnit and C_Map.GetBestMapForUnit("player")
			local pos = m and C_Map.GetPlayerMapPosition(m, "player")
			if pos then u, v = ToWorld(m, pos:GetXY()) end
		end
		if not u then return end
		local okn, name = pcall(sd.GetMobLabel, sd, id)
		seenRares[id] = { u = u, v = v, t = GetTime(), dead = dead and 1 or 0, name = okn and name or "Rare" }
	end)
end
function M.SeenRareLines()
	local out, now = {}, GetTime()
	for id, r in pairs(seenRares) do
		if now - r.t > 60 then seenRares[id] = nil   -- (a minute on the map, then gone)
		else out[#out + 1] = ("RS|%d|%d|%d|%d|%d|%s"):format(id, floor(r.u * SCALE + 0.5), floor(r.v * SCALE + 0.5), floor(now - r.t), r.dead, Clean(r.name):sub(1, 30)) end
	end
	return out
end

--------------------------------------------------------------------------------
-- Gear upgrades: rewards of the quests in your log, and drops in the dungeons for your level
-- (ForeverDungeonJournal's loot lists), against what you're wearing. Scored with weights for your
-- class and spec (the talent tree with the most points; a levelling default below 10), only things you
-- can wear. "GS|spec" then "GU|src|ref|itemID|quality|pct|slot|name|vs|diff|where" for each upgrade
-- (src q quest in your log: ref its ID; d dungeon: ref its name; pct: better by, 999 for an empty slot)
--------------------------------------------------------------------------------

local SLOTS = { INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 }, INVTYPE_CHEST = { 5 }, INVTYPE_ROBE = { 5 },
	INVTYPE_WAIST = { 6 }, INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 }, INVTYPE_WRIST = { 9 }, INVTYPE_HAND = { 10 },
	INVTYPE_FINGER = { 11, 12 }, INVTYPE_TRINKET = { 13, 14 }, INVTYPE_CLOAK = { 15 }, INVTYPE_WEAPON = { 16 },
	INVTYPE_WEAPONMAINHAND = { 16 }, INVTYPE_2HWEAPON = { 16 }, INVTYPE_WEAPONOFFHAND = { 17 }, INVTYPE_SHIELD = { 17 },
	INVTYPE_HOLDABLE = { 17 }, INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 }, INVTYPE_THROWN = { 18 }, INVTYPE_RELIC = { 18 } }
local SLOT_NAME = { "Head", "Neck", "Shoulders", "Shirt", "Chest", "Waist", "Legs", "Feet", "Wrists", "Hands", "Ring", "Ring",
	"Trinket", "Trinket", "Back", "Main hand", "Off hand", "Ranged" }
local STAT = { ITEM_MOD_STRENGTH_SHORT = "STR", ITEM_MOD_AGILITY_SHORT = "AGI", ITEM_MOD_STAMINA_SHORT = "STA",
	ITEM_MOD_INTELLECT_SHORT = "INT", ITEM_MOD_SPIRIT_SHORT = "SPI", RESISTANCE0_NAME = "ARM", ITEM_MOD_ARMOR_SHORT = "ARM",
	ITEM_MOD_DAMAGE_PER_SECOND_SHORT = "DPS", ITEM_MOD_ATTACK_POWER_SHORT = "AP", ITEM_MOD_SPELL_POWER_SHORT = "SP",
	ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "SP", ITEM_MOD_SPELL_HEALING_DONE_SHORT = "HEAL", ITEM_MOD_MANA_REGENERATION_SHORT = "MP5",
	ITEM_MOD_POWER_REGEN0_SHORT = "MP5", ITEM_MOD_DEFENSE_SKILL_RATING_SHORT = "DEF", ITEM_MOD_DODGE_RATING_SHORT = "DODGE",
	ITEM_MOD_PARRY_RATING_SHORT = "PARRY", ITEM_MOD_BLOCK_RATING_SHORT = "BLOCK", ITEM_MOD_BLOCK_VALUE_SHORT = "BLOCKV" }
local STAT_LABEL = { STR = "Str", AGI = "Agi", STA = "Sta", INT = "Int", SPI = "Spi", ARM = "Armour", DPS = "DPS", AP = "AP", SP = "Spell", HEAL = "Healing", MP5 = "Mp5",
	DEF = "Defense", DODGE = "Dodge", PARRY = "Parry", BLOCK = "Block", BLOCKV = "Block value" }
local W = {
	Enhancement = { STR = 1, AGI = 0.8, STA = 0.5, INT = 0.3, SPI = 0.1, AP = 0.45, ARM = 0.02, DPS = 4, SP = 0.2, MP5 = 0.3 },
	Elemental = { INT = 1, SP = 1, STA = 0.5, SPI = 0.3, MP5 = 1.2, ARM = 0.01, STR = 0.05, AGI = 0.05, DPS = 0.3, HEAL = 0.3 },
	Restoration = { INT = 1, HEAL = 0.8, SP = 0.6, MP5 = 1.6, SPI = 0.5, STA = 0.5, ARM = 0.01, DPS = 0.2 },
	Balance = { INT = 1, SP = 1, STA = 0.5, SPI = 0.4, MP5 = 1, ARM = 0.01, DPS = 0.2 },
	Feral = { AGI = 1, STR = 0.9, STA = 0.7, AP = 0.5, ARM = 0.05, INT = 0.1, DPS = 0.5 },
	Melee = { STR = 1, AGI = 0.7, STA = 0.6, AP = 0.45, ARM = 0.03, DPS = 4 },
	Agile = { AGI = 1, STR = 0.6, STA = 0.5, AP = 0.45, ARM = 0.02, DPS = 4 },
	Ranged = { AGI = 1, AP = 0.45, STA = 0.5, INT = 0.3, STR = 0.1, ARM = 0.02, DPS = 3 },
	Holy = { INT = 1, STR = 0.5, STA = 0.6, SP = 0.4, HEAL = 0.6, ARM = 0.03, DPS = 3 },
	Caster = { INT = 1, SP = 1, STA = 0.6, SPI = 0.6, MP5 = 1, HEAL = 0.4, ARM = 0.01, DPS = 2 },
	-- tanks: a bear lives on armour, stamina and agility; shield tanks on stamina, defense and armour
	Bear = { STA = 1, ARM = 0.12, AGI = 0.9, STR = 0.4, DEF = 1.2, DODGE = 1, AP = 0.2, INT = 0.05, DPS = 0.3 },
	Protection = { STA = 1, ARM = 0.1, DEF = 1.5, DODGE = 1, PARRY = 0.9, BLOCK = 0.6, BLOCKV = 0.3, STR = 0.5, AGI = 0.6, AP = 0.2, DPS = 2 },
	Healer = { INT = 1, HEAL = 0.8, SP = 0.5, MP5 = 1.5, SPI = 0.7, STA = 0.5, ARM = 0.01, DPS = 0.2 },
}
-- each class: its talent trees' weights (nil: the levelling default, first)
local SPECS = {
	SHAMAN = { "Enhancement", "Elemental", "Enhancement", "Restoration" }, DRUID = { "Feral", "Balance", "Feral", "Restoration" },
	WARRIOR = { "Melee", "Melee", "Melee", "Melee" }, PALADIN = { "Melee", "Holy", "Melee", "Melee" }, ROGUE = { "Agile", "Agile", "Agile", "Agile" },
	HUNTER = { "Ranged", "Ranged", "Ranged", "Ranged" }, PRIEST = { "Caster", "Caster", "Caster", "Caster" },
	MAGE = { "Caster", "Caster", "Caster", "Caster" }, WARLOCK = { "Caster", "Caster", "Caster", "Caster" },
}
local SPEC_NAME = { Melee = "Melee", Agile = "Melee", Ranged = "Ranged", Holy = "Holy", Caster = "Caster", Bear = "Bear tank",
	Protection = "Tank", Healer = "Healer" }
-- weights for the role you play in the party, when it isn't what your talents say
local ROLE_SPEC = {
	TANK = { DRUID = "Bear", default = "Protection" },
	HEALER = { SHAMAN = "Restoration", DRUID = "Restoration", PALADIN = "Holy", default = "Healer" },
	DAMAGER = { SHAMAN = "Enhancement", DRUID = "Feral", PALADIN = "Melee", PRIEST = "Caster", default = nil },
}
local HEAL_SPEC = { Restoration = true, Holy = true, Healer = true }
local ROLE_WORD = { TANK = "tank", HEALER = "healer", DAMAGER = "damage" }
local SPEC_LABEL = { Enhancement = "Enhancement", Elemental = "Elemental", Restoration = "Restoration", Balance = "Balance",
	Feral = "Feral (cat)", Melee = "Melee", Agile = "Melee", Ranged = "Ranged", Holy = "Holy", Caster = "Caster", Bear = "Bear",
	Protection = "Protection", Healer = "" }

-- your role: /partymap role tank|healer|dps (saved for each character), else the role the party
-- leader gave you, else none (upgrades then follow your talents)
function M.CharKey()
	local n = UnitName and UnitName("player") or "?"
	local r = GetRealmName and GetRealmName() or ""
	return (n or "?") .. "-" .. (r or "")
end
function M.SetRole(role)
	if not PartyMapDB then return end
	PartyMapDB.roles = PartyMapDB.roles or {}
	PartyMapDB.roles[M.CharKey()] = role
end
function M.Role()
	local db = PartyMapDB
	if db and db.role then   -- (saved by an earlier version for everyone: now this character's)
		db.roles = db.roles or {}
		db.roles[M.CharKey()] = db.roles[M.CharKey()] or db.role
		db.role = nil
	end
	local set = db and db.roles and db.roles[M.CharKey()]
	if set == "tank" then return "TANK", "set" elseif set == "healer" then return "HEALER", "set" elseif set == "dps" then return "DAMAGER", "set" end
	if UnitGroupRolesAssigned and IsInGroup and IsInGroup() then
		local ok, r = pcall(UnitGroupRolesAssigned, "player")
		if ok and (r == "TANK" or r == "HEALER" or r == "DAMAGER") then return r, "party" end
	end
end
-- what each class can wear and wield (armour subclasses; mail and plate from 40), weapon subclasses, relic subclass
local CAN = {
	WARRIOR = { armor = { 1, 2, 3, 4, 6 }, late = { [4] = 40 }, weapon = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 13, 15, 16, 18 } },
	PALADIN = { armor = { 1, 2, 3, 4, 6, 7 }, late = { [4] = 40 }, weapon = { 0, 1, 4, 5, 6, 7, 8 } },
	HUNTER = { armor = { 1, 2, 3 }, late = { [3] = 40 }, weapon = { 0, 1, 2, 3, 6, 7, 8, 10, 13, 15, 16, 18 } },
	ROGUE = { armor = { 1, 2 }, weapon = { 2, 3, 4, 7, 13, 15, 16, 18 } },
	PRIEST = { armor = { 1 }, weapon = { 4, 10, 15, 19 } },
	SHAMAN = { armor = { 1, 2, 3, 6, 9 }, late = { [3] = 40 }, weapon = { 0, 1, 4, 5, 10, 13, 15 } },
	MAGE = { armor = { 1 }, weapon = { 7, 10, 15, 19 } },
	WARLOCK = { armor = { 1 }, weapon = { 7, 10, 15, 19 } },
	DRUID = { armor = { 1, 2, 8 }, weapon = { 4, 5, 6, 10, 13, 15 } },
}

local function Spec(class, level)
	local specs = SPECS[class]
	if not specs then return "Melee" end
	if level and level >= 10 and GetTalentTabInfo then
		local best, bestN = nil, 0
		for i = 1, 3 do
			local ok, a, b, c, d, e = pcall(GetTalentTabInfo, i)
			-- (classic: name, icon, pointsSpent; newer: id, name, description, icon, pointsSpent)
			local n = ok and (type(c) == "number" and c or type(e) == "number" and e) or 0
			if n > bestN then best, bestN = i, n end
		end
		if best then return specs[best + 1] end
	end
	return specs[1]
end

local function ItemStats(link)
	local get = (C_Item and C_Item.GetItemStats) or GetItemStats
	local ok, raw = pcall(get, link)
	local out = {}
	if ok and type(raw) == "table" then
		for k, v in pairs(raw) do
			local key = STAT[k]
			if key and type(v) == "number" then out[key] = (out[key] or 0) + v end
		end
	end
	return out
end
local function Score(stats, w)
	local s = 0
	for k, v in pairs(stats) do s = s + (w[k] or 0) * v end
	return s
end
local function CanUse(class, level, itemID)
	local can = CAN[class]
	local instant = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
	if not can or not instant then return true end
	local ok, _, _, _, equipLoc, _, classID, subID = pcall(instant, itemID)
	if not ok then return true end
	if classID == 4 then          -- armour (0: jewellery, cloaks, held items)
		if subID == 0 then return true end
		if subID == 1 and equipLoc == "INVTYPE_CLOAK" then return true end
		for _, a in ipairs(can.armor) do
			if a == subID then return not (can.late and can.late[subID] and level < can.late[subID]) end
		end
		return false
	elseif classID == 2 then      -- weapons
		for _, a in ipairs(can.weapon) do if a == subID then return true end end
		return false
	end
	return true
end
local function ItemInfo(item)
	local get = (C_Item and C_Item.GetItemInfo) or GetItemInfo
	local ok, name, link, quality, ilvl, req, _, _, _, equipLoc = pcall(get, item)
	if ok and name then return name, link, quality or 1, ilvl or 0, req or 0, equipLoc end
	if C_Item and C_Item.RequestLoadItemDataByID and type(item) == "number" then pcall(C_Item.RequestLoadItemDataByID, item) end
end

-- what's equipped: [slot] = { name, stats, score }
local function Equipped(w)
	local out = {}
	for slot = 1, 18 do
		local link = GetInventoryItemLink and GetInventoryItemLink("player", slot)
		if link then
			local name = ItemInfo(link)
			local st = ItemStats(link)
			out[slot] = { name = name or "?", stats = st, score = Score(st, w) }
		end
	end
	return out
end

-- the quest log's reward items: { { link, questID, title, usable } } (each quest read once; not while
-- the quest log is open, as reading one selects it)
local rewardCache = {}
local function QuestLogOpen()
	for _, f in ipairs({ "QuestLogFrame", "QuestLogExFrame", "ClassicQuestLog", "QuestMapFrame" }) do
		local fr = rawget(_G, f)
		if fr and fr.IsVisible and fr:IsVisible() then return true end
	end
end
local function QuestRewardItems(quests)
	local out = {}
	if not GetQuestLogItemLink then return out end
	local prev = C_QuestLog and C_QuestLog.GetSelectedQuest and C_QuestLog.GetSelectedQuest()
	local prevIdx = GetQuestLogSelection and GetQuestLogSelection()
	local open, changed = QuestLogOpen(), false
	for _, q in ipairs(quests or {}) do
		local cached = rewardCache[q.id]
		if cached or open then
			for _, r in ipairs(cached or {}) do out[#out + 1] = r end
		else
		changed = true
		local mine = {}
		if C_QuestLog and C_QuestLog.SetSelectedQuest then pcall(C_QuestLog.SetSelectedQuest, q.id)
		elseif SelectQuestLogEntry and q.index then pcall(SelectQuestLogEntry, q.index) end
		for _, kind in ipairs({ "choice", "reward" }) do
			local count = kind == "choice" and GetNumQuestLogChoices or GetNumQuestLogRewards
			local n = 0
			if count then
				local ok, v = pcall(count, q.id)
				if not (ok and type(v) == "number") then ok, v = pcall(count) end
				n = ok and type(v) == "number" and v or 0
			end
			for i = 1, min(n, 6) do
				local ok, link = pcall(GetQuestLogItemLink, kind, i, q.id)
				if not (ok and type(link) == "string") then ok, link = pcall(GetQuestLogItemLink, kind, i) end
				local usable = true
				local info = kind == "choice" and GetQuestLogChoiceInfo or GetQuestLogRewardInfo
				if info then
					local ok2, _, _, _, _, isUsable = pcall(info, i, q.id)
					if ok2 and isUsable == false then usable = false end
				end
				if ok and type(link) == "string" then mine[#mine + 1] = { link = link, ref = q.id, where = q.title, usable = usable } end
			end
		end
		rewardCache[q.id] = mine
		for _, r in ipairs(mine) do out[#out + 1] = r end
		end
	end
	if changed then
		if prev and C_QuestLog and C_QuestLog.SetSelectedQuest then pcall(C_QuestLog.SetSelectedQuest, prev)
		elseif prevIdx and SelectQuestLogEntry then pcall(SelectQuestLogEntry, prevIdx) end
	end
	return out
end

-- ForeverDungeonJournal's loot in the dungeons for your level: { { itemID, dungeon, boss } }
local function DungeonDrops(level)
	local fdj = rawget(_G, "ForeverDungeonJournal_NS")
	local db = fdj and fdj.DB
	local out = {}
	if type(db) ~= "table" then return out end
	for name, d in pairs(db) do
		local lo, hi = tostring(d.level or ""):match("(%d+)%s*%-%s*(%d+)")
		lo, hi = tonumber(lo), tonumber(hi)
		if lo and level >= lo - 2 and level <= hi and type(d.bosses) == "table" then
			for _, b in ipairs(d.bosses) do
				for _, it in ipairs(b.loot or {}) do
					if type(it) == "table" and type(it[1]) == "number" then out[#out + 1] = { item = it[1], ref = name, where = b.name or "" } end
				end
			end
		end
	end
	return out
end

function M.Gear(quests, level, class)
	level = level or 1
	-- your role decides, your talents fill in the rest: a Feral druid who tanks gets bear gear, one
	-- doing damage cat gear; a Balance druid doing damage caster gear; any healer healing gear
	local spec = Spec(class, level)
	local role, from = M.Role()
	if role then
		local r = ROLE_SPEC[role]
		local pick = r[class] or r.default
		if role == "DAMAGER" and not HEAL_SPEC[spec] then pick = nil end   -- (damage: your talents' kind of damage)
		if pick then spec = pick end
	end
	local name = SPEC_LABEL[spec] or spec
	local label
	if role then
		label = name == "" and ROLE_WORD[role]:gsub("^%l", string.upper) or (name .. " " .. ROLE_WORD[role])
	else
		label = (spec == "Agile" and "Melee" or spec) .. " talents"
	end
	local w = W[spec] or W.Melee
	local eq = Equipped(w)
	local out = { "GS|" .. label .. "|" .. (from or "talents") }
	local seen = {}
	local function Consider(item, src, ref, where, usable)
		local name, link, quality, ilvl, req, equipLoc = ItemInfo(item)
		if not name or not SLOTS[equipLoc] or usable == false then return end
		if seen[name .. src .. ref] then return end
		seen[name .. src .. ref] = true
		local id = type(item) == "number" and item or tonumber(tostring(link):match("item:(%d+)")) or 0
		if src == "d" and (req or 0) > level + 3 then return end
		if not CanUse(class, level, id) then return end
		local st = ItemStats(link)
		local sc = Score(st, w)
		-- the slot it would go in: the weaker of two rings or trinkets; a two-hander against both hands
		local slots = SLOTS[equipLoc]
		local cur, slot = nil, slots[1]
		for _, sl in ipairs(slots) do
			if not eq[sl] then cur, slot = nil, sl break end
			if not cur or eq[sl].score < cur.score then cur, slot = eq[sl], sl end
		end
		local curScore = cur and cur.score or 0
		if equipLoc == "INVTYPE_2HWEAPON" and eq[17] then curScore = curScore + eq[17].score end
		if sc <= curScore * 1.03 + 0.5 then return end
		local pct = (cur and curScore > 0) and floor((sc - curScore) / curScore * 100 + 0.5) or 999
		-- what changes: the stats that differ
		local diff, keys = {}, {}
		for k in pairs(st) do keys[k] = true end
		if cur then for k in pairs(cur.stats) do keys[k] = true end end
		for _, k in ipairs({ "DPS", "STR", "AGI", "STA", "INT", "SPI", "AP", "SP", "HEAL", "MP5", "ARM" }) do
			if keys[k] then
				local d = (st[k] or 0) - (cur and cur.stats[k] or 0)
				if math.abs(d) >= 0.05 then diff[#diff + 1] = (d > 0 and "+" or "") .. (k == "DPS" and ("%.1f"):format(d) or floor(d + 0.5)) .. " " .. STAT_LABEL[k] end
			end
		end
		out[#out + 1] = ("GU|%s|%s|%d|%d|%d|%s|%s|%s|%s|%s"):format(src, Clean(tostring(ref)), id, quality, pct, SLOT_NAME[slot] or "",
			Clean(name):sub(1, 40), Clean(cur and cur.name or ""):sub(1, 40), table.concat(diff, ", "), Clean(where or ""):sub(1, 40))
	end
	for _, r in ipairs(QuestRewardItems(quests)) do pcall(Consider, r.link, "q", r.ref, r.where, r.usable) end
	for _, r in ipairs(DungeonDrops(level)) do pcall(Consider, r.item, "d", r.ref, r.where, true) end
	return out
end

--------------------------------------------------------------------------------
-- Up-ranking: when you learn a new rank of a spell, the buttons with the rank you had swap to the new
-- one (Forever leaves your bars alone). Only the previous top rank is replaced, so lower ranks kept on
-- purpose (a small Healing Wave) stay. Never in combat (the game forbids it): it waits for combat to end.
-- /partymap uprank: every outdated rank on your bars, now. PartyMapDB.uprank = false: not automatically.
--------------------------------------------------------------------------------

local function SpellName(id)
	if C_Spell and C_Spell.GetSpellName then local ok, n = pcall(C_Spell.GetSpellName, id); if ok and n then return n end end
	if GetSpellInfo then local ok, n = pcall(GetSpellInfo, id); if ok then return n end end
end
local function SpellRank(id)
	local get = (C_Spell and C_Spell.GetSpellSubtext) or GetSpellSubtext
	if not get then return end
	local ok, sub = pcall(get, id)
	return ok and type(sub) == "string" and tonumber(sub:match("(%d+)")) or nil
end
-- the highest rank you know of each spell: [name] = { rank, spellID }
local function TopRanks()
	local out = {}
	local function Add(id, name, sub)
		if not (id and name) then return end
		local r = type(sub) == "string" and tonumber(sub:match("(%d+)")) or SpellRank(id)
		if r and (not out[name] or r > out[name][1]) then out[name] = { r, id } end
	end
	if C_SpellBook and C_SpellBook.GetNumSpellBookSkillLines and C_SpellBook.GetSpellBookItemInfo then
		local bank = Enum and Enum.SpellBookSpellBank and Enum.SpellBookSpellBank.Player or 0
		for t = 1, C_SpellBook.GetNumSpellBookSkillLines() or 0 do
			local info = C_SpellBook.GetSpellBookSkillLineInfo(t)
			if info then
				for i = info.itemIndexOffset + 1, info.itemIndexOffset + info.numSpellBookItems do
					local it = C_SpellBook.GetSpellBookItemInfo(i, bank)
					if it and it.spellID and not it.isPassive and not it.isOffSpec then Add(it.spellID, it.name, it.subName) end
				end
			end
		end
	elseif GetNumSpellTabs and GetSpellTabInfo and GetSpellBookItemInfo then
		local book = BOOKTYPE_SPELL or "spell"
		for t = 1, GetNumSpellTabs() or 0 do
			local _, _, offset, n = GetSpellTabInfo(t)
			for i = (offset or 0) + 1, (offset or 0) + (n or 0) do
				local kind, id = GetSpellBookItemInfo(i, book)
				if kind == "SPELL" and id then
					local name, sub = GetSpellBookItemName(i, book)
					Add(id, name, sub)
				end
			end
		end
	end
	return out
end
local MAX_SLOT = 180
local upPending, upTop, upLog = nil, nil, {}
-- swap one button to a spell (out of combat, empty cursor)
local function Swap(slot, id)
	local pick = (C_Spell and C_Spell.PickupSpell) or PickupSpell
	if not (pick and PlaceAction) then return false end
	local ok = pcall(pick, id)
	if not ok or not GetCursorInfo() then ClearCursor() return false end
	pcall(PlaceAction, slot)
	ClearCursor()
	local kind, now = GetActionInfo(slot)
	return kind == "spell" and now == id
end
-- replace on every bar: wanted[name] = { fromRank (nil: any lower), toRank, toID }
local function Replace(wanted)
	if InCombatLockdown and InCombatLockdown() then return nil end
	if GetCursorInfo and GetCursorInfo() then return nil end    -- (you're holding something: later)
	local done = {}
	for slot = 1, MAX_SLOT do
		local ok, kind, id = pcall(GetActionInfo, slot)
		if ok and kind == "spell" and id then
			local name = SpellName(id)
			local w = name and wanted[name]
			if w and id ~= w[3] then
				local r = SpellRank(id)
				if r and r < w[2] and (not w[1] or r == w[1]) and Swap(slot, w[3]) then
					done[name] = (done[name] or 0) + 1
				end
			end
		end
	end
	local t = time and time() or 0
	for name, n in pairs(done) do
		local r = wanted[name][2]
		upLog[#upLog + 1] = { name = name, rank = r, n = n, t = t }
		while #upLog > 12 do table.remove(upLog, 1) end
		print(("|cffF0B04AParty Map|r %s → Rank %d on your bars (%d button%s)."):format(name, r, n, n == 1 and "" or "s"))
	end
	return done
end
-- after the spellbook changed: what got a new top rank, swapped where the old top rank was
function M.CheckRanks()
	local top = TopRanks()
	if not upTop then upTop = top return end
	local wanted = upPending or {}
	for name, t in pairs(top) do
		local old = upTop[name]
		if old and t[1] > old[1] then
			-- (two ranks learned at the trainer at once: from the rank you had then)
			local was = wanted[name] and wanted[name][1] or old[1]
			wanted[name] = { was, t[1], t[2] }
		end
	end
	upTop = top
	if next(wanted) == nil then upPending = nil return end
	if PartyMapDB and PartyMapDB.uprank == false then upPending = nil return end
	local done = Replace(wanted)
	upPending = (done == nil) and wanted or nil      -- (in combat or holding something: try again later)
end
function M.RetryRanks()
	if upPending then
		local done = Replace(upPending)
		if done ~= nil then upPending = nil end
	end
end
-- every outdated rank on your bars (the slash command)
function M.UprankAll()
	local wanted = {}
	for name, t in pairs(TopRanks()) do wanted[name] = { nil, t[1], t[2] } end
	local done = Replace(wanted)
	if done == nil then print("|cffF0B04AParty Map|r can't change your bars in combat (or while you're holding something). Try again in a moment.") return end
	if next(done) == nil then print("|cffF0B04AParty Map|r every spell on your bars is already its highest rank.") end
end
-- the last swaps, for the window: "UP|name|rank|buttons|secondsAgo" (the last 15 minutes)
function M.UprankLines()
	local out, now = {}, time and time() or 0
	for _, u in ipairs(upLog) do
		if now - u.t < 900 then out[#out + 1] = ("UP|%s|%d|%d|%d"):format(Clean(u.name), u.rank, u.n, now - u.t) end
	end
	return out
end

--------------------------------------------------------------------------------
-- Where to level next (0.16.2): every quest Questie says you could take, whatever your level, that's
-- worth it from here (not grey, at most 3 levels above you, picked up from someone or something, not
-- repeatable or for a holiday), by the zone it belongs to; and the zones you've explored. Scanned a
-- slice at a time, so there's no hitch; again after a turn-in, a new quest or a new level, and every
-- few minutes. Sent with your quest log, so the party's maps get it too:
--   "LL|level|quests"                       when it was worked out
--   "L<areaID>|<quest>,<quest>,..."         a quest: its ID in base 36, with ":<level>" when it needs a
--                                           level above yours (a long zone takes several lines)
--   "LX|<uiMapID>,..."                      the zones you've explored (base 36)
--   "LC|<quest>,<quest>,..."                (0.16.4) your class quests: QuestieDB files them under the
--                                           class, not a zone (older apps skip the line)
--------------------------------------------------------------------------------

local LN_SOON = 3               -- levels above yours still worth knowing about
local LN_SLICE = 200            -- quests looked at per frame
local LN_EVERY = 300            -- seconds: a fresh scan anyway
local LN_MAX = 320              -- quests sent at most (the ones closest to your level)
-- QuestieDB's class sorts (a class quest's zoneOrSort); Questie's own test keeps only your class's
local LN_CLASS = { [-61] = true, [-81] = true, [-82] = true, [-141] = true, [-161] = true, [-162] = true, [-261] = true, [-262] = true, [-263] = true }

local B36D = "0123456789abcdefghijklmnopqrstuvwxyz"
local function B36(n)
	n = floor(n)
	if n <= 0 then return "0" end
	local s = ""
	while n > 0 do
		local d = n % 36
		s = B36D:sub(d + 1, d + 1) .. s
		n = (n - d) / 36
	end
	return s
end
M.B36 = B36

-- a quest log change (a turn-in, a new quest, a new level): scan again in a moment, once Questie has it
function M.LevelNextDirty()
	ln.wantAt = (GetTime and GetTime() or 0) + 3
end


-- Questie's IsDoable without its race test (the side is tested above): its other tests (done,
-- earlier quests, class, reputation, professions, breadcrumbs...) stand
local function DoableAnyRace(QDB, qid)
	local orig = QDB.QueryQuestSingle
	QDB.QueryQuestSingle = function(id, key, ...)
		if key == "requiredRaces" then return nil end
		return orig(id, key, ...)
	end
	local ok, doable = pcall(QDB.IsDoable, qid)
	QDB.QueryQuestSingle = orig
	return ok and doable == true
end

local function LevelNextCheck(QDB, qid, L, green, found)
	local function Q(f)
		local ok, v = pcall(QDB.QueryQuestSingle, qid, f)
		if ok then return v end
	end
	local req = tonumber(Q("requiredLevel")) or 0
	if req > L + LN_SOON then return end
	local ql = tonumber(Q("questLevel")) or 0
	if ql <= 0 or ql < L - green or ql > L + LN_SOON + 3 then return end
	local zone = tonumber(Q("zoneOrSort")) or 0
	if zone < 0 and LN_CLASS[zone] then zone = 0                         -- (a class quest: "LC")
	elseif zone <= 0 then return end
	local flags = tonumber(Q("specialFlags")) or 0
	if flags % 2 == 1 or floor(flags / 2) % 2 == 1 then return end        -- (repeatable, or needs an event)
	local sb = Q("startedBy")
	if type(sb) ~= "table" or not ((type(sb[1]) == "table" and next(sb[1])) or (type(sb[2]) == "table" and next(sb[2]))) then return end
	if OnQuest(qid) then return end
	if not ForMySide(Q("requiredRaces"), ln.side) then return end
	if not DoableAnyRace(QDB, qid) then return end
	if L < 58 and QDB.IsRaidQuest then
		local okr, raid = pcall(QDB.IsRaidQuest, qid)
		if okr and raid then return end
	end
	found[#found + 1] = { qid = qid, zone = zone, req = req, off = math.abs(math.max(ql, req) - (L + 1)), npcs = req <= L and type(sb[1]) == "table" and sb[1] or nil }
end

-- one slice of the scan; true when a scan has just finished with something new
function M.LevelNextStep(now, level)
	if not ln.keys then
		local due = (ln.wantAt > 0 and now >= ln.wantAt) or now - ln.at > LN_EVERY
		if not due or not level or level <= 0 then return false end
		if InCombatLockdown and InCombatLockdown() then return false end
		local QDB = Questie("QuestieDB")
		if not (QDB and type(QDB.QuestPointers) == "table" and QDB.IsDoable and QDB.QueryQuestSingle) then return false end
		ln.keys = {}
		for id in pairs(QDB.QuestPointers) do if type(id) == "number" then ln.keys[#ln.keys + 1] = id end end
		ln.i, ln.found, ln.level, ln.wantAt, ln.QDB = 0, {}, level, 0, QDB
		local okf, side = pcall(UnitFactionGroup, "player")
		ln.side = okf and side or "Horde"
		ln.green = GreenRange(level)
	end
	local stop = math.min(#ln.keys, ln.i + LN_SLICE)
	for k = ln.i + 1, stop do
		pcall(LevelNextCheck, ln.QDB, ln.keys[k], ln.level, ln.green, ln.found)
	end
	ln.i = stop
	if stop < #ln.keys then return false end
	-- done: the ones closest to your level first, then by zone
	local found, L = ln.found, ln.level
	table.sort(found, function(a, b) if a.off ~= b.off then return a.off < b.off end return a.qid < b.qid end)
	local zones, order = {}, {}
	for i = 1, math.min(#found, LN_MAX) do
		local f = found[i]
		if not zones[f.zone] then zones[f.zone] = {}; order[#order + 1] = f.zone end
		local t = zones[f.zone]
		t[#t + 1] = f.req > L and (B36(f.qid) .. ":" .. f.req) or B36(f.qid)
	end
	table.sort(order)
	-- (the quests you can take now, by who gives them: Recommended quests near you uses these too)
	local byNpc = {}
	for _, f in ipairs(found) do
		if f.npcs then
			for _, npc in pairs(f.npcs) do
				if type(npc) == "number" then byNpc[npc] = byNpc[npc] or {}; byNpc[npc][f.qid] = true end
			end
		end
	end
	ln.byNpc = byNpc
	local okr, _, _, race = pcall(UnitRace, "player")
	local lines = { ("LL|%d|%d|%s|%s"):format(L, math.min(#found, LN_MAX), okr and tostring(race or "") or "", ln.side or "") }
	for _, z in ipairs(order) do
		local list = zones[z]
		table.sort(list)
		local tag = z == 0 and "LC|" or ("L" .. z .. "|")
		local line = tag
		local n = 0
		for _, e in ipairs(list) do
			if n > 0 and #line + #e + 1 > 180 then lines[#lines + 1] = line; line, n = tag, 0 end
			line = line .. (n > 0 and "," or "") .. e
			n = n + 1
		end
		lines[#lines + 1] = line
	end
	-- the zones you've explored (any of their map uncovered)
	local ex = {}
	if C_MapExplorationInfo and C_MapExplorationInfo.GetExploredMapTextures then
		for _, l in ipairs(M.Zones()) do
			local id = tonumber(l:match("^Z|(%d+)|"))
			local ok, t = pcall(C_MapExplorationInfo.GetExploredMapTextures, id)
			if id and ok and type(t) == "table" and #t > 0 then ex[#ex + 1] = B36(id) end
		end
	end
	if #ex > 0 then lines[#lines + 1] = "LX|" .. table.concat(ex, ",") end
	ln.keys, ln.found, ln.QDB, ln.at = nil, nil, nil, now
	local changed = table.concat(lines, "\n") ~= table.concat(ln.lines, "\n")
	ln.lines = lines
	return changed
end

function M.LevelNextLines() return ln.lines end
function M.LevelNextByNpc() return ln.byNpc end

return M
