-- Bank Alt Helper: the post button. At the auction house a small panel goes through your bags:
-- for each item worth auctioning it looks up the price again, shows what it will post, and one
-- press posts it 1 copper under the lowest (or matches it when the lowest is already yours).
-- WoW only lets an addon post on a click or key press, so it's one press per item.
local _, ns = ...
local C = ns.C
local P = {}
ns.P = P

P.done = {}       -- itemID -> "posted" | "skipped" this visit
P.skipped = {}    -- lines for the summary
P.posted = 0
P.state = "idle"  -- idle | looking | ready | posting | confirm | waiting | finished | blocked

local function AH() return C_AuctionHouse end

local function commodityStatus(loc, id)
	local ah = AH()
	if ah and ah.GetItemCommodityStatus and loc then
		local ok, st = pcall(ah.GetItemCommodityStatus, loc)
		local E = Enum and Enum.ItemCommodityStatus
		if ok and E then
			if st == E.Commodity then return true end
			if st == E.Item then return false end
		end
	end
	local _, _, _, stack = ns.ItemInfo(id)
	return (stack or 1) > 1
end

local function makeLoc(bag, slot)
	if ItemLocation and ItemLocation.CreateFromBagAndSlot then
		return ItemLocation:CreateFromBagAndSlot(bag, slot)
	end
	return nil
end

-- What's left to post from this character's bags, in bag order.
-- Stackable goods are one entry with the whole count; other items are one entry per slot.
function P.Build()
	local list, byID = {}, {}
	for _, bag in ipairs(ns.S.BagIDs()) do
		local n = (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag))
			or (GetContainerNumSlots and GetContainerNumSlots(bag)) or 0
		for slot = 1, n do
			local i = ns.S.SlotInfo(bag, slot)
			local slotKey = bag .. ":" .. slot
			if i and i.id and ns.Sellable(i) and not i.locked and not P.done[i.id] and not P.done[slotKey] and not ns.db.keep[i.id] then
				local loc = makeLoc(bag, slot)
				local e = byID[i.id]
				if e and e.commodity then
					e.qty = e.qty + i.count
				else
					local commodity = commodityStatus(loc, i.id)
					local entry = { id = i.id, qty = i.count, loc = loc, bag = bag, slot = slot, commodity = commodity,
						link = i.link, key = commodity and i.id or slotKey }
					list[#list + 1] = entry
					if commodity then byID[i.id] = entry end
				end
			end
		end
	end
	return list
end

-- ---------------------------------------------------------------- the panel

local function setText(fs, s) if fs and fs.SetText then fs:SetText(s or "") end end

function P.MakePanel()
	if P.frame then return P.frame end
	local parent = AuctionHouseFrame or UIParent
	local f = CreateFrame("Frame", "BankAltHelperPanel", parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(320, 132)
	if AuctionHouseFrame then f:SetPoint("TOPLEFT", AuctionHouseFrame, "TOPRIGHT", 6, 0) else f:SetPoint("CENTER") end
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 14,
			insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	end
	f:SetFrameStrata("HIGH")
	f:EnableMouse(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	f.title:SetPoint("TOPLEFT", 10, -9)
	f.title:SetText("Bank Alt Helper")
	f.line1 = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.line1:SetPoint("TOPLEFT", 10, -28); f.line1:SetWidth(300); f.line1:SetJustifyH("LEFT")
	f.line2 = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.line2:SetPoint("TOPLEFT", 10, -46); f.line2:SetWidth(300); f.line2:SetJustifyH("LEFT")
	f.line3 = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.line3:SetPoint("TOPLEFT", 10, -76); f.line3:SetWidth(300); f.line3:SetJustifyH("LEFT")

	local post = CreateFrame("Button", "BankAltHelperPostButton", f, "UIPanelButtonTemplate")
	post:SetSize(130, 24); post:SetPoint("BOTTOMLEFT", 10, 10)
	post:SetText("Post")
	post:SetScript("OnClick", function() ns.Safe("post", P.Press) end)
	f.post = post

	local skip = CreateFrame("Button", "BankAltHelperSkipButton", f, "UIPanelButtonTemplate")
	skip:SetSize(80, 24); skip:SetPoint("LEFT", post, "RIGHT", 6, 0)
	skip:SetText("Skip")
	skip:SetScript("OnClick", function() ns.Safe("skip", P.Skip, "skipped by you") end)
	f.skip = skip

	local prices = CreateFrame("Button", "BankAltHelperPricesButton", f, "UIPanelButtonTemplate")
	prices:SetSize(80, 24); prices:SetPoint("LEFT", skip, "RIGHT", 6, 0)
	prices:SetText("Prices")
	prices:SetScript("OnClick", function()
		ns.Safe("prices", function()
			if P.current then ns.G.Draw(P.current.id) else ns.G.Open() end
		end)
	end)
	f.prices = prices

	local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 0, 0)
	close:SetScript("OnClick", function() f:Hide() end)
	P.frame = f
	return f
end

function P.Show(state, l1, l2)
	P.state = state
	local f = P.MakePanel()
	setText(f.line1, l1)
	setText(f.line2, l2)
	local left = #P.Build()
	setText(f.line3, string.format("%d posted · %d skipped · %d to look at", P.posted, #P.skipped, left))
	local label = ({ ready = "Post", confirm = "Confirm post", looking = "Checking…", posting = "Posting…",
		waiting = "Look again", finished = "Done", blocked = "Post", idle = "Start" })[state] or "Post"
	setText(f.post, label)
	local enabled = (state == "ready" or state == "confirm" or state == "waiting" or state == "idle")
	if f.post.SetEnabled then f.post:SetEnabled(enabled) end
	if f.skip.SetEnabled then f.skip:SetEnabled(P.current ~= nil and state ~= "posting") end
	f:Show()
end

-- ---------------------------------------------------------------- the steps

-- Moves to the next item and looks up its price.
function P.Advance()
	P.current = nil
	if not ns.atAH then return end
	if ns.A.neutral and not ns.db.settings.allowNeutral then
		P.Show("blocked", "This is a neutral auction house: it takes a 15% cut.",
			"Type /bankalt neutral on to post here anyway.")
		return
	end
	local list = P.Build()
	local item = list[1]
	if not item then
		P.Show("finished", P.posted > 0 and "All done." or "Nothing in your bags to auction.",
			#P.skipped > 0 and (#P.skipped .. " skipped: /bankalt skipped lists why.") or "")
		return
	end
	P.current = item
	P.Show("looking", string.format("%s × %d", ns.ItemName(item.id), item.qty), "Checking the lowest price…")
	ns.A.Request(item.id, item.loc, function(e) P.Priced(item, e) end, true)
end

-- The fresh price came back (e is nil when the auction house didn't answer in time).
function P.Priced(item, e)
	if P.current ~= item then return end
	if not e then
		P.Show("waiting", string.format("%s × %d", ns.ItemName(item.id), item.qty),
			"The auction house didn't answer in time.")
		return
	end
	local _, _, _, _, _, sell = ns.ItemInfo(item.id)
	local duration = ns.db.settings.duration
	local deposit = ns.V.Deposit(item.id, item.qty, duration, item.loc, item.commodity)
	local cut = ns.V.Cut()
	local step = item.commodity and 1 or ns.db.settings.itemStep
	local v = ns.V.Verdict({
		vendor = sell or 0, qty = item.qty, lowest = e.min, mine = e.mine, deposit = deposit,
		cut = cut, p = 1, userMin = ns.db.floor[item.id], step = step,
		fallback = e.last, keep = ns.db.keep[item.id], seen = true,
	})
	item.verdict, item.deposit, item.duration = v, deposit, duration
	if v.action ~= "auction" then
		P.Skip((v.action == "vendor" and "vendor it: " or "") .. (v.why or v.action))
		return
	end
	local lowest = e.min and ("lowest " .. ns.Money(e.min) .. (e.mine and " (yours)" or "")) or "none listed"
	P.Show("ready",
		string.format("%s × %d at %s each", ns.ItemName(item.id), item.qty, ns.Money(v.price)),
		string.format("%s · deposit %s · you'd get %s", lowest, ns.Money(deposit), ns.Money(math.floor(v.net))))
end

-- Skipping marks every stack of that item, since the verdict is the same for all of them.
function P.Skip(why)
	local item = P.current
	if item then
		P.done[item.id] = "skipped"
		P.skipped[#P.skipped + 1] = ns.ItemName(item.id) .. ": " .. tostring(why)
	end
	P.Advance()
end

local function callPost(item, confirm)
	local ah = AH()
	local v = item.verdict
	if item.commodity then
		local fn = confirm and ah.ConfirmPostCommodity or ah.PostCommodity
		return fn(item.loc, item.duration, item.qty, v.price)
	end
	local fn = confirm and ah.ConfirmPostItem or ah.PostItem
	return fn(item.loc, item.duration, item.qty, nil, v.price)
end

-- The button. Each press does one thing: start, post, confirm, or look again.
function P.Press()
	if P.state == "idle" or P.state == "finished" then
		P.Advance()
		return
	end
	if P.state == "waiting" and P.current then
		local item = P.current
		P.Show("looking", string.format("%s × %d", ns.ItemName(item.id), item.qty), "Checking the lowest price…")
		ns.A.Request(item.id, item.loc, function(e) P.Priced(item, e) end, true)
		return
	end
	local item = P.current
	if not item or not item.verdict then return end
	if not item.loc then
		P.Skip("this game version gives no way to point at a bag slot")
		return
	end
	if P.state == "ready" or P.state == "confirm" then
		local confirm = P.state == "confirm"
		P.Show("posting", string.format("%s × %d at %s each", ns.ItemName(item.id), item.qty, ns.Money(item.verdict.price)), "Posting…")
		P.postStarted = GetTime and GetTime() or 0
		local ok, err = pcall(callPost, item, confirm)
		if not ok then P.Failed(tostring(err)) end
	end
end

function P.Created()
	local item = P.current
	if not item then return end
	-- Gear is one auction per slot, so only that slot is done; a stackable item went up whole.
	P.done[item.key or item.id] = "posted"
	P.posted = P.posted + 1
	-- Your auction is now the lowest: the next copy of it matches instead of undercutting you.
	-- (Not a history point: your own posts would skew the price history.)
	local e = ns.Prices()[item.id]
	if type(e) == "table" then e.min, e.mine = item.verdict.price, true end
	ns.After(0.3, P.Advance)
end

function P.Failed(msg)
	local item = P.current
	if not item then return end
	-- Some houses take only whole silver for gear: switch to that once, and say so.
	if not item.commodity and ns.db.settings.itemStep == 1 then
		ns.db.settings.itemStep = 100
		ns.Print("this auction house only took whole silver for that item; gear now undercuts by 1 silver.")
		local e = ns.Prices()[item.id]
		P.Priced(item, e or { min = nil })
		return
	end
	P.Skip("couldn't post: " .. tostring(msg or "the auction house said no"))
end

-- ---------------------------------------------------------------- events

ns.On("AUCTION_HOUSE_SHOW", function()
	P.done, P.skipped, P.posted, P.current = {}, {}, 0, nil
	P.Show("idle", "Press Start to go through your bags.", "One press per item posts it 1 copper under the lowest.")
end)

ns.On("AUCTION_HOUSE_CLOSED", function()
	P.current = nil
	P.state = "idle"
	if P.frame then P.frame:Hide() end
	if P.posted > 0 or #P.skipped > 0 then
		ns.Print(string.format("posted %d, skipped %d.", P.posted, #P.skipped))
	end
end)

ns.On("AUCTION_HOUSE_AUCTION_CREATED", function()
	if P.state == "posting" or P.state == "confirm" then P.Created() end
end)

ns.On("AUCTION_HOUSE_POST_WARNING", function()
	if P.state ~= "posting" then return end
	local item = P.current
	if not item then return end
	P.Show("confirm", string.format("%s × %d at %s each", ns.ItemName(item.id), item.qty, ns.Money(item.verdict.price)),
		"The game says this price is unusual. Press again to post it anyway, or Skip.")
end)

ns.On("AUCTION_HOUSE_SHOW_ERROR", function()
	if P.state == "posting" then P.Failed("the auction house said no") end
end)

ns.On("UI_ERROR_MESSAGE", function(_, msg)
	if P.state ~= "posting" then return end
	local t = GetTime and GetTime() or 0
	if P.postStarted and t - P.postStarted < 3 then P.Failed(msg) end
end)
