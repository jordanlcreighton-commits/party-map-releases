-- Umberhide Skies: darker nights, lights, colour moods, rain, snow, fog, sounds and lightning for WoW Forever.
-- Core: settings, presets, the night curve, the update loop and /skies.
-- Everything is drawn with see-through layers on the game world, under the interface. Nothing here
-- presses keys, uses protected actions or reads anything the addon API doesn't offer.
local ADDON, ns = ...
UmberhideSkies = ns
ns.VERSION = "1.1.0"
ns.PATH = "Interface\\AddOns\\UmberhideSkies\\"
ns.errors = 0
ns.lastError = nil

local function Secret(v) return issecretvalue and issecretvalue(v) or false end
ns.Secret = Secret

-- Colour moods: what the world is multiplied by at full strength (r, g, b)
ns.COLOURS = {
	{ key = "moon", name = "Moonlight", r = 0.29, g = 0.37, b = 0.63 },
	{ key = "plain", name = "Plain", r = 0.55, g = 0.55, b = 0.55 },
	{ key = "dawn", name = "Dawn pink", r = 0.94, g = 0.70, b = 0.67 },
	{ key = "gold", name = "Golden hour", r = 1.00, g = 0.77, b = 0.54 },
	{ key = "grove", name = "Grove green", r = 0.64, g = 0.83, b = 0.60 },
	{ key = "frost", name = "Frost", r = 0.71, g = 0.82, b = 0.94 },
	{ key = "ember", name = "Firelight", r = 1.00, g = 0.62, b = 0.40 },
}
function ns.Colour(key)
	for _, c in ipairs(ns.COLOURS) do if c.key == key then return c end end
	return ns.COLOURS[1]
end

-- Presets: one press sets the look; every meter can still be moved afterwards
ns.PRESETS = {
	{ key = "live", name = "Live weather", live = true }, -- the zone's own weather, rolling in and out by itself
	{ key = "off", name = "Off", dark = 0, vig = 0, colour = "plain", cstr = 0, fog = 0, rain = 0, wind = 0, snow = 0, ff = 0, storm = false, frost = false },
	{ key = "night", name = "Real night", dark = 0.80, vig = 0.42, colour = "moon", cstr = 0.62, fog = 0.18, rain = 0, wind = 0.15, snow = 0, ff = 0, storm = false, frost = false },
	{ key = "storm", name = "Stormy night", dark = 0.78, vig = 0.40, colour = "moon", cstr = 0.60, fog = 0.25, rain = 0.65, wind = 0.35, snow = 0, ff = 0, storm = true, frost = false },
	{ key = "drizzle", name = "Grey drizzle", dark = 0.30, vig = 0.25, colour = "frost", cstr = 0.35, fog = 0.35, rain = 0.30, wind = 0.10, snow = 0, ff = 0, storm = false, frost = false },
	{ key = "mist", name = "Misty dawn", dark = 0.22, vig = 0.20, colour = "dawn", cstr = 0.35, fog = 0.75, rain = 0, wind = 0.08, snow = 0, ff = 0, storm = false, frost = false },
	{ key = "snow", name = "Snowy night", dark = 0.60, vig = 0.38, colour = "frost", cstr = 0.60, fog = 0.35, rain = 0, wind = 0.25, snow = 0.65, ff = 0, storm = false, frost = true },
	{ key = "flies", name = "Firefly meadow", dark = 0.70, vig = 0.42, colour = "moon", cstr = 0.50, fog = 0.15, rain = 0, wind = 0.05, snow = 0, ff = 0.70, storm = false, frost = false },
	{ key = "gold", name = "Golden hour", dark = 0, vig = 0.25, colour = "gold", cstr = 0.45, fog = 0.12, rain = 0, wind = 0.10, snow = 0, ff = 0, storm = false, frost = false },
	{ key = "camp", name = "Campfire", dark = 0.62, vig = 0.60, colour = "ember", cstr = 0.55, fog = 0.05, rain = 0, wind = 0.05, snow = 0, ff = 0.20, storm = false, frost = false },
	{ key = "gloom", name = "Dungeon gloom", dark = 0.55, vig = 0.80, colour = "plain", cstr = 0.50, fog = 0.10, rain = 0, wind = 0, snow = 0, ff = 0, storm = false, frost = false },
	{ key = "grove", name = "Druid grove", dark = 0.30, vig = 0.30, colour = "grove", cstr = 0.45, fog = 0.30, rain = 0, wind = 0.05, snow = 0, ff = 0.40, storm = false, frost = false },
}
local PRESET_FIELDS = { "dark", "vig", "colour", "cstr", "fog", "rain", "wind", "snow", "ff", "storm", "frost" }
function ns.Preset(key)
	for _, p in ipairs(ns.PRESETS) do if p.key == key then return p end end
end

ns.DEFAULTS = {
	on = true, preset = "live",
	dark = 0.80, clock = "pc", vig = 0.42, -- clock: "pc" (your computer's clock), "game" or "always" (always night)
	meOn = true, mikaOn = true, lsize = 1.0, lstr = 0.85, lightX = 0.50, lightY = 0.69,
	horizon = 0.23, colour = "moon", cstr = 0.62,
	fog = 0.18, rain = 0, wind = 0.15, snow = 0, ff = 0, splash = true, storm = false, frost = false,
	live = true, wstr = 1.0,            -- live weather by zone, and how strong it comes
	boltRate = 0.5, boltBright = 0.75,  -- lightning: how often, how bright
	cat = true, prowl = true, lowhp = true, sound = true, indoors = "off", -- "off" or "gloom" inside buildings and dungeons
}

local function Clamp(v, a, b) if v < a then return a elseif v > b then return b end return v end
ns.Clamp = Clamp

-- settings, filled from SavedVariables at ADDON_LOADED (defaults until then)
ns.s = {}
for k, v in pairs(ns.DEFAULTS) do ns.s[k] = v end

local function LoadSettings()
	UmberhideSkiesDB = type(UmberhideSkiesDB) == "table" and UmberhideSkiesDB or {}
	local db = UmberhideSkiesDB
	db.settings = type(db.settings) == "table" and db.settings or {}
	local s = db.settings
	-- (before 1.0.5 a tick box, "follow", chose between the game's clock and always night)
	if s.clock ~= "pc" and s.clock ~= "game" and s.clock ~= "always" then
		s.clock = s.follow == false and "always" or "pc"
	end
	s.follow = nil
	for k, v in pairs(ns.DEFAULTS) do
		if type(s[k]) ~= type(v) then s[k] = v end
		if type(v) == "number" then s[k] = Clamp(s[k], k == "lsize" and 0.3 or 0, k == "lsize" and 2.5 or 1) end
	end
	if not ns.Preset(s.preset) then s.preset = "custom" end
	if s.indoors ~= "off" and s.indoors ~= "gloom" then s.indoors = "off" end
	ns.Colour(s.colour) -- an unknown colour falls back to Moonlight when drawn
	ns.s = s
end
ns.LoadSettings = LoadSettings

function ns.ApplyPreset(key)
	local p = ns.Preset(key)
	if not p then return false end
	if p.live then
		-- the zone's own weather; your darkness, colour and lights stay as they are
		ns.s.live = true
		if ns.Live then ns.Live.forced = nil end
	else
		for _, f in ipairs(PRESET_FIELDS) do ns.s[f] = p[f] end
		ns.s.live = false
	end
	ns.s.preset = key
	if key ~= "off" then ns.s.on = true end
	ns.Changed()
	return true
end

-- Something moved by hand: the look is no longer exactly a preset
function ns.Touched()
	ns.s.preset = "custom"
	ns.Changed()
end

ns.listeners = {}
function ns.Changed()
	for _, fn in ipairs(ns.listeners) do pcall(fn) end
end

-- ---------------------------------------------------------------- time of day
-- Night falls 19:00 to 22:00 and lifts 05:00 to 08:00, by your computer's clock (the default since
-- 1.0.5: WoW Forever's own clock can be hours out from your evening) or the game's
function ns.NightCurve(h)
	if type(h) ~= "number" then return 1 end
	h = h % 24
	if h >= 22 or h < 5 then return 1 end
	if h >= 19 then return (h - 19) / 3 end
	if h < 8 then return (8 - h) / 3 end
	return 0
end

function ns.GameHour()
	if not GetGameTime then return nil end
	local ok, h, m = pcall(GetGameTime)
	if not ok or type(h) ~= "number" or type(m) ~= "number" or Secret(h) or Secret(m) then return nil end
	return h + m / 60
end

function ns.PCHour()
	if not date then return nil end
	local ok, t = pcall(date, "*t")
	if not ok or type(t) ~= "table" or type(t.hour) ~= "number" or type(t.min) ~= "number" then return nil end
	return t.hour + t.min / 60
end

-- The hour the night follows (nil when it can't be told)
function ns.Hour()
	if ns.s.clock == "game" then return ns.GameHour() end
	return ns.PCHour() or ns.GameHour()
end

ns.CLOCKS = { { key = "pc", name = "your PC's clock" }, { key = "game", name = "the game's clock" }, { key = "always", name = "always night" } }
function ns.ClockName(key)
	for _, c in ipairs(ns.CLOCKS) do if c.key == key then return c.name end end
	return ns.CLOCKS[1].name
end

-- Where you are: "out", "in" (a building or cave) or "instance" (a dungeon or raid)
function ns.Place()
	if IsInInstance then
		local ok, inside = pcall(IsInInstance)
		if ok and inside and not Secret(inside) then return "instance" end
	end
	if IsIndoors then
		local ok, inside = pcall(IsIndoors)
		if ok and inside and not Secret(inside) then return "in" end
	end
	return "out"
end

-- Your form and sneaking (Druids): cat form lifts the night, prowling closes it in
function ns.InCatForm()
	if not GetShapeshiftFormID then return false end
	local ok, id = pcall(GetShapeshiftFormID)
	return ok and id == 1 or false
end
function ns.Prowling()
	if not IsStealthed then return false end
	local ok, v = pcall(IsStealthed)
	return ok and v and not Secret(v) and true or false
end

-- How low is the lowest of you and your party (0..1, nil when unknown)
function ns.LowestHealth()
	local low
	local units = { "player", "party1", "party2", "party3", "party4" }
	for _, u in ipairs(units) do
		if UnitExists == nil or UnitExists(u) then
			local ok, hp, max = pcall(function() return UnitHealth(u), UnitHealthMax(u) end)
			if ok and type(hp) == "number" and type(max) == "number" and not Secret(hp) and not Secret(max) and max > 0 then
				local dead = UnitIsDeadOrGhost and UnitIsDeadOrGhost(u)
				if not dead then
					local f = hp / max
					if not low or f < low then low = f end
				end
			end
		end
	end
	return low
end

-- How dark it is right now (0..0.97), everything considered
function ns.Darkness()
	local s = ns.s
	if not s.on then return 0 end
	local d = s.dark
	if s.clock ~= "always" then
		local h = ns.Hour()
		if h then d = d * ns.NightCurve(h) end
	end
	local place = ns.Place()
	if place ~= "out" then
		if s.indoors == "gloom" then d = math.max(d * 0.5, 0.45) else d = 0 end
	end
	if s.cat and ns.InCatForm() then d = d * 0.45 end
	return Clamp(d, 0, 0.97)
end

-- ---------------------------------------------------------------- the loop
local parts = {} -- modules: each may have Init(), Update(elapsed, now), Hide()
function ns.Register(name, mod) parts[#parts + 1] = { name = name, mod = mod } end

local function Catch(name, fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok then
		ns.errors = ns.errors + 1
		ns.lastError = name .. ": " .. tostring(err)
	end
	return ok
end

local events = CreateFrame("Frame", "UmberhideSkiesEvents")
local started = false
local function Start()
	if started then return end
	started = true
	for _, p in ipairs(parts) do
		if p.mod.Init then Catch(p.name, p.mod.Init) end
	end
	ns.Changed()
end
ns.Start = Start

local acc, now = 0, 0
function ns.Tick(elapsed)
	if not started then return end
	elapsed = Clamp(type(elapsed) == "number" and elapsed or 0, 0, 0.25)
	now = now + elapsed
	ns.now = now
	for _, p in ipairs(parts) do
		if p.mod.Update then Catch(p.name, p.mod.Update, elapsed, now) end
	end
end

events:SetScript("OnEvent", function(_, event, arg)
	if event == "ADDON_LOADED" and arg == ADDON then
		LoadSettings()
		Start()
	elseif event == "PLAYER_LOGOUT" then
		-- nothing to tidy: settings live in UmberhideSkiesDB already
	end
end)
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGOUT")
events:SetScript("OnUpdate", function(_, elapsed) ns.Tick(elapsed) end)

-- ---------------------------------------------------------------- /skies
local function Say(msg) print("|cff9fb7e6Umberhide Skies:|r " .. msg) end
ns.Say = Say

local function PresetList()
	local names = {}
	for _, p in ipairs(ns.PRESETS) do names[#names + 1] = p.key end
	return table.concat(names, ", ")
end

function ns.Slash(msg)
	msg = (type(msg) == "string" and msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
	local cmd, rest = msg:match("^(%S*)%s*(.-)$")
	if cmd == "" or cmd == "options" or cmd == "settings" then
		if ns.Options and ns.Options.Toggle then ns.Options.Toggle() end
	elseif cmd == "off" then
		ns.s.on = false
		ns.Changed()
		Say("off. /skies on brings it back.")
	elseif cmd == "on" then
		ns.s.on = true
		ns.Changed()
		Say("on (" .. ((ns.Preset(ns.s.preset) or {}).name or "your own look") .. ").")
	elseif cmd == "preset" or ns.Preset(cmd) then
		local key = ns.Preset(cmd) and cmd or rest
		if ns.ApplyPreset(key) then Say(ns.Preset(key).name .. ".") else Say("presets: " .. PresetList()) end
	elseif cmd == "reset" then
		for k, v in pairs(ns.DEFAULTS) do ns.s[k] = v end
		ns.Changed()
		Say("back to the starting settings.")
	elseif cmd == "weather" or cmd == "live" then
		-- /skies weather storm brings a storm in now; /skies weather live (or /skies live) goes back
		-- to the zone's own weather
		local kind = cmd == "live" and "live" or rest
		if kind == "" or kind == "live" then
			ns.ApplyPreset("live")
			Say("live weather: " .. ns.Live.Describe() .. ".")
		elseif ns.Live.Force(kind) then
			ns.s.preset = "live"
			ns.Changed()
			Say(ns.Live.NAMES[kind] .. " coming in (/skies weather live for the zone's own weather).")
		else
			Say("/skies weather clear, cloudy, mist, drizzle, rain, storm, snow, blizzard, dust or live.")
		end
	elseif cmd == "status" then
		Say("weather: " .. (ns.Live and ns.Live.Describe() or "?") .. ".")
		local h = ns.Hour()
		Say(("version %s, %s, preset %s, darkness now %d%%, night follows %s (%s), %s, %d errors%s"):format(ns.VERSION,
			ns.s.on and "on" or "off", ns.s.preset, math.floor(ns.Darkness() * 100 + 0.5), ns.ClockName(ns.s.clock),
			h and ("%02d:%02d"):format(math.floor(h), math.floor((h % 1) * 60 + 0.5) % 60) or "unknown", ns.Place(),
			ns.errors, ns.lastError and (" (last: " .. ns.lastError .. ")") or ""))
	else
		Say("/skies opens the settings. /skies on, /skies off, /skies <preset> (" .. PresetList() .. "), /skies weather <kind>, /skies reset, /skies status.")
	end
end

SLASH_UMBERHIDESKIES1 = "/skies"
SLASH_UMBERHIDESKIES2 = "/umberhideskies"
SlashCmdList = SlashCmdList or {}
SlashCmdList.UMBERHIDESKIES = ns.Slash
