-- Bank Alt Helper: sales on your other characters. WoW only tells a character about its own auctions,
-- and only by mail, so whenever any character opens its mailbox the addon notes its "Auction
-- successful" and "Auction expired" mails. Logging in on another character then shows what sold since
-- you last looked there, and /bankalt sales lists the latest.
local _, ns = ...
local SL = {}
ns.SL = SL

SL.MAX = 300

-- A mail subject format ("Auction successful: %s") as a pattern that captures the item.
local function pattern(fmt, fallback)
	if type(fmt) ~= "string" or not fmt:find("%%s") then fmt = fallback end
	local p = fmt:gsub("([%(%)%.%+%-%*%?%[%]%^%$])", "%%%1")
	p = p:gsub("%%s", "(.+)")
	return "^" .. p .. "$"
end

function SL.Patterns()
	return pattern(AUCTION_SOLD_MAIL_SUBJECT, "Auction successful: %s"),
		pattern(AUCTION_EXPIRED_MAIL_SUBJECT, "Auction expired: %s")
end

function SL.Store()
	local db = ns.db
	if type(db.sales) ~= "table" then db.sales = {} end
	if type(db.salesKeys) ~= "table" then db.salesKeys = {} end
	if type(db.lastLook) ~= "table" then db.lastLook = {} end
	return db.sales, db.salesKeys, db.lastLook
end

-- Reads the mailbox for auction mails it hasn't noted yet. A mail is known again by its subject,
-- money and when it expires (to the hour, allowing an hour either side), so reopening the mailbox
-- never counts it twice.
function SL.Scan()
	if not GetInboxNumItems or not ns.db then return 0 end
	local sales, keys = SL.Store()
	local soldP, expiredP = SL.Patterns()
	local me, now = ns.Me(), ns.Now()
	local added = 0
	for i = 1, GetInboxNumItems() or 0 do
		local _, _, _, subject, money, _, daysLeft = GetInboxHeaderInfo(i)
		if type(subject) == "string" then
			local kind, item = "sold", subject:match(soldP)
			if not item then kind, item = "expired", subject:match(expiredP) end
			if item then
				local count = tonumber(item:match("%((%d+)%)%s*$"))
				item = item:gsub("%s*%(%d+%)%s*$", "")
				if kind == "sold" and GetInboxInvoiceInfo then
					local ok, itype, _, _, _, _, _, _, _, _, _, qty = pcall(GetInboxInvoiceInfo, i)
					if ok and itype == "seller" and tonumber(qty) then count = count or tonumber(qty) end
				end
				money = tonumber(money) or 0
				local expires = now + (tonumber(daysLeft) or 0) * 86400
				local hour = math.floor(expires / 3600)
				local base = me .. "|" .. kind .. "|" .. subject .. "|" .. money .. "|"
				if not (keys[base .. hour] or keys[base .. (hour - 1)] or keys[base .. (hour + 1)]) then
					keys[base .. hour] = expires
					sales[#sales + 1] = { t = now, who = me, kind = kind, item = item, count = count or 1, money = money }
					added = added + 1
				end
			end
		end
	end
	for k, exp in pairs(keys) do if type(exp) ~= "number" or exp < now - 86400 then keys[k] = nil end end
	while #sales > SL.MAX do table.remove(sales, 1) end
	return added
end

-- Sales by other characters since this one last looked: { [who] = { sold, gold, expired, items } }.
function SL.Since(t, me)
	local sales = SL.Store()
	local by = {}
	for _, s in ipairs(sales) do
		if type(s) == "table" and (s.t or 0) > t and s.who ~= me then
			local w = by[s.who]
			if not w then w = { sold = 0, gold = 0, expired = 0, items = {} }; by[s.who] = w end
			if s.kind == "sold" then
				w.sold = w.sold + 1
				w.gold = w.gold + (s.money or 0)
				w.items[#w.items + 1] = s.item .. ((s.count or 1) > 1 and (" ×" .. s.count) or "")
			else
				w.expired = w.expired + 1
			end
		end
	end
	return by
end

-- One line per character, for chat.
function SL.Lines(by)
	local names, lines = {}, {}
	for who in pairs(by) do names[#names + 1] = who end
	table.sort(names)
	for _, who in ipairs(names) do
		local w = by[who]
		local parts = {}
		if w.sold > 0 then
			local shown = {}
			for i = 1, math.min(3, #w.items) do shown[i] = w.items[i] end
			local more = #w.items > 3 and (" and " .. (#w.items - 3) .. " more") or ""
			parts[#parts + 1] = "sold " .. w.sold .. " for " .. ns.Money(w.gold) .. " (" .. table.concat(shown, ", ") .. more .. ")"
		end
		if w.expired > 0 then parts[#parts + 1] = w.expired .. " came back unsold" end
		lines[#lines + 1] = who .. ": " .. table.concat(parts, " · ")
	end
	return lines
end

-- Gold from sales in the last day, all characters.
function SL.Today()
	local sales = SL.Store()
	local since, gold, n = ns.Now() - 86400, 0, 0
	for _, s in ipairs(sales) do
		if type(s) == "table" and s.kind == "sold" and (s.t or 0) > since then gold = gold + (s.money or 0); n = n + 1 end
	end
	return gold, n
end

-- Shown when you log in: what your other characters sold since you were last on this one.
function SL.Report()
	local _, _, look = SL.Store()
	local me = ns.Me()
	local by = SL.Since(look[me] or 0, me)
	local lines = SL.Lines(by)
	if #lines > 0 then
		ns.Print("|cffffd100since you were last on " .. me .. ":|r")
		for _, l in ipairs(lines) do ns.Print("  " .. l) end
	end
	look[me] = ns.Now()
	return #lines
end

ns.On("MAIL_INBOX_UPDATE", function() SL.Scan() end)
ns.On("PLAYER_ENTERING_WORLD", function(isLogin, isReload)
	if isReload then return end
	ns.After(5, SL.Report)
end)
