-- Bank Alt Helper: send lists. Pick a character on the left, tick items on the right: each tick is
-- saved, and that item goes to that character whenever you're at a mailbox. An item ticked for two
-- characters is asked about before it goes in a mail. Quick buttons tick every herb, cloth... in
-- your bags at once.
local _, ns = ...
local W = {}
ns.W = W

W.ROWS = 12
W.CHARS = 12
W.QUICK = { "herbs", "cloth", "leather", "ore", "gear", "reagents" }

local function setText(fs, s) if fs and fs.SetText then fs:SetText(s or "") end end

-- Characters you can send to: every one seen or added, except the one you're on.
function W.Chars()
	local me, names, seen = ns.Me(), {}, {}
	local function add(n) if type(n) == "string" and n ~= me and not seen[n] then seen[n] = true; names[#names + 1] = n end end
	for n in pairs(ns.db.chars) do add(n) end
	for n in pairs(ns.R.Lists()) do add(n) end
	for n in pairs(ns.R.Alts()) do add(n) end
	table.sort(names)
	return names
end

local function countOn(name)
	local list, n = ns.R.Lists()[name], 0
	if type(list) == "table" then for _ in pairs(list) do n = n + 1 end end
	return n
end

-- The rows for the selected character: items in your bags (or on every character), plus everything
-- already ticked for them. filter matches part of the name.
function W.Rows(filter, scope, who)
	local counts = {}
	if scope == "all" then
		for name in pairs(ns.db.chars) do
			for id, n in pairs(ns.S.AllItems(name)) do counts[id] = (counts[id] or 0) + n end
		end
	else
		local c = ns.db.chars[ns.Me()]
		if c and type(c.bags) == "table" and type(c.bags.items) == "table" then
			for id, n in pairs(c.bags.items) do counts[id] = n end
		end
	end
	local list = who and ns.R.Lists()[who]
	if type(list) == "table" then for id in pairs(list) do counts[id] = counts[id] or 0 end end
	local want = type(filter) == "string" and filter:lower():gsub("^%s+", ""):gsub("%s+$", "") or ""
	local rows = {}
	for id, n in pairs(counts) do
		local name, _, quality, _, icon = ns.ItemInfo(id)
		name = name or ("item " .. id)
		if want == "" or name:lower():find(want, 1, true) then
			local others = {}
			for _, o in ipairs(ns.R.ListsFor(id, true)) do if o ~= who then others[#others + 1] = o end end
			rows[#rows + 1] = { id = id, name = name, count = n, icon = icon or 134400, quality = quality,
				ticked = type(list) == "table" and list[id] == true, others = others, never = ns.db.settings.stay[id] }
		end
	end
	table.sort(rows, function(a, b)
		if a.ticked ~= b.ticked then return a.ticked end
		if a.name ~= b.name then return a.name < b.name end
		return a.id < b.id
	end)
	return rows
end

function W.Tick(id, on)
	if not W.sel or not id then return end
	ns.R.SetListed(W.sel, id, on)
	if on then ns.db.settings.stay[id] = nil end
end

-- Ticks every item of a category in your bags for the selected character.
function W.TickCategory(cat)
	if not W.sel then return 0 end
	local c = ns.db.chars[ns.Me()]
	local n = 0
	if c and type(c.bags) == "table" and type(c.bags.items) == "table" then
		for id in pairs(c.bags.items) do
			local a, b = ns.R.CategoryOf(id)
			if a == cat or b == cat then ns.R.SetListed(W.sel, id, true); n = n + 1 end
		end
	end
	return n
end

-- ---------------------------------------------------------------- the window

function W.MakeWindow()
	if W.frame then return W.frame end
	local f = CreateFrame("Frame", "BankAltHelperRules", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:Hide()
	f:SetSize(600, 170 + W.ROWS * 26)
	f:SetPoint("CENTER", 0, 40)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 14,
			insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	end
	f:SetFrameStrata("DIALOG")
	f:EnableMouse(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
	if UISpecialFrames then table.insert(UISpecialFrames, "BankAltHelperRules") end

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	f.title:SetPoint("TOPLEFT", 14, -12)
	f.title:SetText("Send lists")
	f.lead = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.lead:SetPoint("TOPLEFT", 14, -34); f.lead:SetWidth(570); f.lead:SetJustifyH("LEFT")

	-- left: the characters
	f.charHead = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	f.charHead:SetPoint("TOPLEFT", 14, -56)
	f.charHead:SetText("Send to:")
	f.chars = {}
	for i = 1, W.CHARS do
		local b = CreateFrame("Button", "BankAltHelperListChar" .. i, f, "UIPanelButtonTemplate")
		b:SetSize(160, 22)
		b:SetPoint("TOPLEFT", 12, -72 - (i - 1) * 24)
		b:SetScript("OnClick", function(self)
			if not self.who then return end
			W.sel = self.who
			W.page = 1
			ns.Safe("lists", W.Draw)
			-- at a mailbox: their ticked items go straight into the mail, with their name
			if ns.atMail and ns.M then ns.Safe("fill mail", ns.M.FillFor, self.who) end
		end)
		f.chars[i] = b
	end
	local add = CreateFrame("EditBox", "BankAltHelperListAdd", f, "InputBoxTemplate")
	add:SetSize(110, 20); add:SetPoint("BOTTOMLEFT", 18, 44)
	add:SetAutoFocus(false)
	add:SetScript("OnEnterPressed", function(self)
		ns.Safe("add", function()
			local n = ns.NormName(self:GetText())
			if n and n ~= ns.Me() then ns.L.AddChar(n); W.sel = n end
			self:SetText(""); self:ClearFocus()
			W.Draw()
		end)
	end)
	add:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
	f.add = add
	local addBtn = CreateFrame("Button", "BankAltHelperListAddButton", f, "UIPanelButtonTemplate")
	addBtn:SetSize(46, 22); addBtn:SetPoint("LEFT", add, "RIGHT", 4, 0)
	addBtn:SetText("Add")
	addBtn:SetScript("OnClick", function() add:GetScript("OnEnterPressed")(add) end)

	-- right: the items
	local box = CreateFrame("EditBox", "BankAltHelperRulesSearch", f, "InputBoxTemplate")
	box:SetSize(150, 20); box:SetPoint("TOPLEFT", 196, -54)
	box:SetAutoFocus(false)
	box:SetScript("OnTextChanged", function() W.page = 1; ns.Safe("lists", W.Draw) end)
	box:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
	box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
	f.box = box
	local scope = CreateFrame("Button", "BankAltHelperRulesScope", f, "UIPanelButtonTemplate")
	scope:SetSize(150, 22); scope:SetPoint("LEFT", box, "RIGHT", 10, 0)
	scope:SetScript("OnClick", function()
		W.scope = (W.scope == "all") and "bags" or "all"
		W.page = 1
		ns.Safe("lists", W.Draw)
	end)
	f.scope = scope

	f.quick = {}
	for i, cat in ipairs(W.QUICK) do
		local b = CreateFrame("Button", "BankAltHelperQuick" .. cat, f, "UIPanelButtonTemplate")
		b:SetSize(62, 18)
		b:SetPoint("TOPLEFT", 190 + (i - 1) * 64, -96)
		b:SetText(cat:sub(1, 1):upper() .. cat:sub(2))
		b:SetScript("OnClick", function()
			ns.Safe("quick tick", function()
				local n = W.TickCategory(cat)
				ns.Print(n .. " kinds of " .. ns.R.LABEL[cat] .. " ticked for " .. tostring(W.sel) .. ".")
				W.Draw()
			end)
		end)
		f.quick[i] = b
	end
	f.quickLabel = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.quickLabel:SetPoint("TOPLEFT", 194, -82)

	f.rows = {}
	for i = 1, W.ROWS do
		local r = CreateFrame("Frame", nil, f)
		r:SetSize(390, 24)
		r:SetPoint("TOPLEFT", 192, -120 - (i - 1) * 26)
		local cb = CreateFrame("CheckButton", "BankAltHelperListItem" .. i, r, "UICheckButtonTemplate")
		cb:SetSize(24, 24); cb:SetPoint("LEFT", 0, 0)
		cb:SetScript("OnClick", function(self)
			if not r.id then return end
			ns.Safe("tick", function()
				W.Tick(r.id, self:GetChecked() and true or false)
				W.Draw(false)
				if ns.atMail and ns.M then ns.M.AutoName(); ns.M.Refresh() end
			end)
		end)
		r.check = cb
		r.icon = r:CreateTexture(nil, "ARTWORK")
		r.icon:SetSize(20, 20); r.icon:SetPoint("LEFT", 28, 0)
		r.name = r:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		r.name:SetPoint("LEFT", 54, 0); r.name:SetWidth(180); r.name:SetJustifyH("LEFT")
		r.count = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
		r.count:SetPoint("LEFT", 238, 0)
		r.note = r:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
		r.note:SetPoint("LEFT", 278, 0); r.note:SetWidth(112); r.note:SetJustifyH("LEFT")
		f.rows[i] = r
	end

	local prev = CreateFrame("Button", "BankAltHelperRulesPrev", f, "UIPanelButtonTemplate")
	prev:SetSize(40, 22); prev:SetPoint("BOTTOMLEFT", 192, 14); prev:SetText("<")
	prev:SetScript("OnClick", function() W.page = math.max(1, (W.page or 1) - 1); ns.Safe("lists", W.Draw) end)
	local nxt = CreateFrame("Button", "BankAltHelperRulesNext", f, "UIPanelButtonTemplate")
	nxt:SetSize(40, 22); nxt:SetPoint("LEFT", prev, "RIGHT", 4, 0); nxt:SetText(">")
	nxt:SetScript("OnClick", function() W.page = (W.page or 1) + 1; ns.Safe("lists", W.Draw) end)
	f.prev, f.next = prev, nxt
	f.page = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.page:SetPoint("LEFT", nxt, "RIGHT", 10, 0)

	local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 0, 0)
	close:SetScript("OnClick", function() f:Hide() end)
	W.frame = f
	return f
end

-- resort = false keeps the rows where they are (after a tick), so the next click hits the same item.
function W.Draw(resort)
	local f = W.frame
	if not f then return end
	local chars = W.Chars()
	local found = false
	for _, n in ipairs(chars) do if n == W.sel then found = true end end
	if not found then W.sel = chars[1] end

	for i = 1, W.CHARS do
		local b, who = f.chars[i], chars[i]
		if who then
			b.who = who
			local n = countOn(who)
			setText(b, (who == W.sel and "|cffffd100> " or "") .. who .. (n > 0 and (" (" .. n .. ")") or "") .. (who == W.sel and "|r" or ""))
			b:Show()
		else
			b.who = nil
			b:Hide()
		end
	end

	W.scope = W.scope or "bags"
	setText(f.scope, W.scope == "all" and "Showing: everything" or "Showing: my bags")
	if not W.sel then
		setText(f.lead, "No other characters yet. Log in once on each alt, or type a name bottom left and press Add.")
		for _, r in ipairs(f.rows) do r.id = nil; r:Hide() end
		for _, q in ipairs(f.quick) do q:Hide() end
		setText(f.quickLabel, ""); setText(f.page, "")
		W.shown = {}
		f:Show()
		return
	end
	if ns.atMail then
		setText(f.lead, "|cffffd100At the mailbox:|r click a character on the left to put everything ticked for them in the mail, "
			.. "with their name. Then press Send. What doesn't fit goes in the next mail.")
	else
		setText(f.lead, "Tick what goes to |cffffd100" .. W.sel .. "|r. Ticks are saved. At a mailbox, click a character here "
			.. "to put their ticked items in the mail.")
	end
	for _, q in ipairs(f.quick) do q:Show() end
	setText(f.quickLabel, "Tick everything in my bags that's:")

	local rows = W.Rows(f.box:GetText(), W.scope, W.sel)
	if resort == false and W.order then
		local pos = {}
		for i, id in ipairs(W.order) do pos[id] = i end
		table.sort(rows, function(a, b)
			local pa, pb = pos[a.id] or math.huge, pos[b.id] or math.huge
			if pa ~= pb then return pa < pb end
			return a.id < b.id
		end)
	end
	W.order = {}
	for i, row in ipairs(rows) do W.order[i] = row.id end
	local pages = math.max(1, math.ceil(#rows / W.ROWS))
	W.page = math.min(math.max(1, W.page or 1), pages)
	local first = (W.page - 1) * W.ROWS
	for i = 1, W.ROWS do
		local r, row = f.rows[i], rows[first + i]
		if row then
			r.id = row.id
			r.check:SetChecked(row.ticked)
			if r.icon.SetTexture then r.icon:SetTexture(row.icon) end
			setText(r.name, row.name)
			setText(r.count, row.count > 0 and ("× " .. row.count) or "")
			local note = ""
			if #row.others > 0 then note = "|cffff8040also: " .. table.concat(row.others, ", ") .. "|r" end
			setText(r.note, note)
			r:Show()
		else
			r.id = nil
			r:Hide()
		end
	end
	setText(f.page, #rows == 0 and "nothing in your bags" or string.format("page %d of %d · %d items", W.page, pages, #rows))
	if f.prev.SetEnabled then f.prev:SetEnabled(W.page > 1) end
	if f.next.SetEnabled then f.next:SetEnabled(W.page < pages) end
	W.shown = rows
	f:Show()
end

function W.Open(who)
	W.MakeWindow()
	if who then W.sel = who end
	ns.S.ScanBags()
	W.Draw()
end
