-- Bank Alt Helper: the price window. Search an item (type its name, or shift-click it) and see a
-- graph of its lowest auction price over time, how many were listed, the vendor price as a line,
-- the low, high and average, who holds it and what to do with it.
-- The graph uses prices your characters have seen at the auction house: the items you hold, and
-- anything you search for there yourself. Blizzard's hourly online history comes with the app.
local _, ns = ...
local G = {}
ns.G = G

G.W, G.H = 380, 150      -- the chart area, in pixels
G.WEEK = 7 * 86400

-- ---------------------------------------------------------------- the sums (tested on their own)

-- An item's saved points as { {t, price, listed}, ... } oldest first. price 0 = none listed then.
function G.Series(id)
	local e = ns.V.PriceOf(id)
	local out = {}
	if not e or type(e.hist) ~= "table" then return out end
	for _, p in ipairs(e.hist) do
		if type(p) == "table" and type(p[1]) == "number" then
			out[#out + 1] = { p[1], tonumber(p[2]) or 0, tonumber(p[3]) or 0 }
		end
	end
	table.sort(out, function(a, b) return a[1] < b[1] end)
	return out
end

-- Low, high and average of the prices seen in the last week (points with nothing listed skipped),
-- plus the newest price and how it compares with the week's average.
function G.Stats(points, now)
	now = now or ns.Now()
	local low, high, sum, n, newest
	for _, p in ipairs(points) do
		if p[2] > 0 then
			newest = p
			if now - p[1] <= G.WEEK then
				low = (not low or p[2] < low) and p[2] or low
				high = (not high or p[2] > high) and p[2] or high
				sum, n = (sum or 0) + p[2], (n or 0) + 1
			end
		end
	end
	local r = { low = low, high = high, n = n or 0, newest = newest and newest[2], newestT = newest and newest[1] }
	if n and n > 0 then r.avg = math.floor(sum / n + 0.5) end
	if r.avg and r.newest and r.avg > 0 then r.vsAvg = (r.newest - r.avg) / r.avg end
	return r
end

-- Where each point goes on a w x h chart: { x, y, gap } where gap = nothing listed (the line breaks).
-- The price scale runs from a little under the lowest to a little over the highest, and includes the
-- vendor price when it's near, so the vendor line sits in view. Returns points, lo, hi, t0, t1.
function G.Layout(points, w, h, vendor)
	local lo, hi, t0, t1
	for _, p in ipairs(points) do
		t0 = (not t0 or p[1] < t0) and p[1] or t0
		t1 = (not t1 or p[1] > t1) and p[1] or t1
		if p[2] > 0 then
			lo = (not lo or p[2] < lo) and p[2] or lo
			hi = (not hi or p[2] > hi) and p[2] or hi
		end
	end
	local out = {}
	if not t0 then return out end
	if lo and vendor and vendor > 0 and vendor >= lo * 0.5 then
		lo = math.min(lo, vendor); hi = math.max(hi, vendor)
	end
	if lo then
		local pad = (hi - lo) * 0.1
		if pad == 0 then pad = math.max(1, lo * 0.1) end
		lo, hi = math.max(0, lo - pad), hi + pad
	end
	local span = (t1 > t0) and (t1 - t0) or 1
	for _, p in ipairs(points) do
		local x = (t1 > t0) and ((p[1] - t0) / span * w) or (w / 2)
		if p[2] > 0 and lo then
			out[#out + 1] = { x = x, y = (p[2] - lo) / (hi - lo) * h }
		else
			out[#out + 1] = { x = x, gap = true }
		end
	end
	return out, lo, hi, t0, t1
end

-- Finds an item by link, number or name (any item in the price book or anyone's stock).
function G.FindItem(text)
	if type(text) ~= "string" then return nil end
	local id = ns.ItemID(text)
	if id then return id end
	local want = text:lower():gsub("^%s+", ""):gsub("%s+$", "")
	if want == "" then return nil end
	local partial
	local function try(iid)
		local name = ns.ItemInfo(iid)
		if not name then return nil end
		local l = name:lower()
		if l == want then return iid end
		if not partial and l:find(want, 1, true) then partial = iid end
	end
	for _, book in pairs(ns.db.prices) do
		if type(book) == "table" then
			for iid in pairs(book) do local hit = try(iid); if hit then return hit end end
		end
	end
	for name in pairs(ns.db.chars) do
		for iid in pairs(ns.S.AllItems(name)) do local hit = try(iid); if hit then return hit end end
	end
	return partial
end

-- ---------------------------------------------------------------- the window

local function setText(fs, s) if fs and fs.SetText then fs:SetText(s or "") end end

local function line(parent, pool, i)
	local l = pool[i]
	if not l then
		if parent.CreateLine then
			l = parent:CreateLine(nil, "OVERLAY")
			l.dot = false
		else
			l = parent:CreateTexture(nil, "OVERLAY") -- no lines on this client: dots instead
			l.dot = true
		end
		pool[i] = l
	end
	return l
end

function G.MakeWindow()
	if G.frame then return G.frame end
	local f = CreateFrame("Frame", "BankAltHelperGraph", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(G.W + 60, G.H + 150)
	f:SetPoint("CENTER")
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 14,
			insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	end
	f:SetFrameStrata("DIALOG")
	f:EnableMouse(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
	if UISpecialFrames then table.insert(UISpecialFrames, "BankAltHelperGraph") end -- Esc closes it

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	f.title:SetPoint("TOPLEFT", 12, -10)
	f.title:SetText("Bank Alt Helper: prices")

	local box = CreateFrame("EditBox", "BankAltHelperGraphSearch", f, "InputBoxTemplate")
	box:SetSize(220, 20); box:SetPoint("TOPLEFT", 16, -30)
	box:SetAutoFocus(false)
	box:SetScript("OnEnterPressed", function(self)
		ns.Safe("graph search", G.Search, self:GetText())
		self:ClearFocus()
	end)
	box:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
	f.box = box
	f.hint = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.hint:SetPoint("LEFT", box, "RIGHT", 8, 0)
	f.hint:SetText("type a name or shift-click an item")

	f.name = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightLarge")
	f.name:SetPoint("TOPLEFT", 16, -58)

	local area = CreateFrame("Frame", nil, f)
	area:SetSize(G.W, G.H)
	area:SetPoint("TOPLEFT", 48, -82)
	f.bg = area:CreateTexture(nil, "BACKGROUND")
	if f.bg.SetAllPoints then f.bg:SetAllPoints() end
	if f.bg.SetColorTexture then f.bg:SetColorTexture(1, 1, 1, 0.05) end
	f.area = area
	f.hiLabel = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.hiLabel:SetPoint("TOPRIGHT", area, "TOPLEFT", -4, 0)
	f.loLabel = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.loLabel:SetPoint("BOTTOMRIGHT", area, "BOTTOMLEFT", -4, 0)
	f.t0Label = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.t0Label:SetPoint("TOPLEFT", area, "BOTTOMLEFT", 0, -3)
	f.t1Label = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.t1Label:SetPoint("TOPRIGHT", area, "BOTTOMRIGHT", 0, -3)
	f.empty = f:CreateFontString(nil, "OVERLAY", "GameFontDisable")
	f.empty:SetPoint("CENTER", area, "CENTER")
	f.empty:SetWidth(G.W - 20)

	f.stats = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.stats:SetPoint("TOPLEFT", area, "BOTTOMLEFT", -32, -20)
	f.stats:SetWidth(G.W + 30); f.stats:SetJustifyH("LEFT")
	f.verdict = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.verdict:SetPoint("TOPLEFT", f.stats, "BOTTOMLEFT", 0, -4)
	f.verdict:SetWidth(G.W + 30); f.verdict:SetJustifyH("LEFT")
	f.held = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.held:SetPoint("TOPLEFT", f.verdict, "BOTTOMLEFT", 0, -4)
	f.held:SetWidth(G.W + 30); f.held:SetJustifyH("LEFT")

	local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 0, 0)
	close:SetScript("OnClick", function() f:Hide() end)
	f.lines, f.bars = {}, {}
	G.frame = f
	return f
end

local function dateText(t)
	if not t then return "" end
	if date then return date("%d/%m %H:%M", t) end
	return tostring(t)
end

-- Draws the chart for an item.
function G.Draw(id)
	local f = G.MakeWindow()
	for _, l in ipairs(f.lines) do l:Hide() end
	for _, b in ipairs(f.bars) do b:Hide() end
	G.id = id
	local _, _, _, _, _, sell = ns.ItemInfo(id)
	sell = sell or 0
	setText(f.name, ns.ItemName(id))
	local points = G.Series(id)
	local layout, lo, hi, t0, t1 = G.Layout(points, G.W, G.H, sell)
	local drawn, maxListed = 0, 0
	for _, p in ipairs(points) do if p[3] > maxListed then maxListed = p[3] end end

	-- how many were listed: faint bars along the bottom (up to a quarter of the height)
	for i, p in ipairs(points) do
		if maxListed > 0 and p[3] > 0 then
			local b = f.bars[i]
			if not b then b = f.area:CreateTexture(nil, "BORDER"); f.bars[i] = b end
			local hgt = math.max(1, p[3] / maxListed * G.H * 0.25)
			b:ClearAllPoints()
			b:SetPoint("BOTTOMLEFT", f.area, "BOTTOMLEFT", math.max(0, layout[i].x - 2), 0)
			b:SetSize(4, hgt)
			if b.SetColorTexture then b:SetColorTexture(0.5, 0.6, 0.8, 0.35) end
			b:Show()
		end
	end

	-- the price line, broken where nothing was listed
	local n = 0
	for i = 2, #layout do
		local a, b = layout[i - 1], layout[i]
		if not a.gap and not b.gap then
			n = n + 1
			local l = line(f.area, f.lines, n)
			if l.dot then
				l:ClearAllPoints(); l:SetPoint("CENTER", f.area, "BOTTOMLEFT", b.x, b.y); l:SetSize(3, 3)
			else
				l:SetStartPoint("BOTTOMLEFT", f.area, a.x, a.y)
				l:SetEndPoint("BOTTOMLEFT", f.area, b.x, b.y)
				l:SetThickness(2)
			end
			if l.SetColorTexture then l:SetColorTexture(0.83, 0.63, 0.09, 1) end
			l:Show()
			drawn = drawn + 1
		end
	end
	-- a lone point still shows: a short dash
	if drawn == 0 then
		for _, p in ipairs(layout) do
			if not p.gap then
				n = n + 1
				local l = line(f.area, f.lines, n)
				if not l.dot then
					l:SetStartPoint("BOTTOMLEFT", f.area, math.max(0, p.x - 6), p.y)
					l:SetEndPoint("BOTTOMLEFT", f.area, math.min(G.W, p.x + 6), p.y)
					l:SetThickness(2)
				end
				if l.SetColorTexture then l:SetColorTexture(0.83, 0.63, 0.09, 1) end
				l:Show()
				drawn = drawn + 1
			end
		end
	end
	-- the vendor price, as a grey line across, when it's in view
	G.vendorShown = false
	if lo and sell > 0 and sell >= lo and sell <= hi then
		n = n + 1
		local l = line(f.area, f.lines, n)
		local y = (sell - lo) / (hi - lo) * G.H
		if not l.dot then
			l:SetStartPoint("BOTTOMLEFT", f.area, 0, y)
			l:SetEndPoint("BOTTOMLEFT", f.area, G.W, y)
			l:SetThickness(1)
		end
		if l.SetColorTexture then l:SetColorTexture(0.7, 0.7, 0.7, 0.6) end
		l:Show()
		G.vendorShown = true
	end
	G.drawn = drawn

	setText(f.hiLabel, hi and ns.Money(math.floor(hi)) or "")
	setText(f.loLabel, lo and ns.Money(math.floor(lo)) or "")
	setText(f.t0Label, dateText(t0))
	setText(f.t1Label, (t1 and t1 ~= t0) and dateText(t1) or "")
	if drawn == 0 then
		setText(f.empty, #points == 0 and "No prices seen yet. Open the auction house on any character, or search for it there."
			or "Seen, but none were listed then.")
		f.empty:Show()
	else
		f.empty:Hide()
	end

	local st = G.Stats(points)
	local e = ns.V.PriceOf(id)
	local parts = {}
	if st.newest then
		local trend = ""
		if st.vsAvg and math.abs(st.vsAvg) >= 0.05 then
			trend = string.format(" (%d%% %s the week's average)", math.floor(math.abs(st.vsAvg) * 100 + 0.5), st.vsAvg < 0 and "below" or "above")
		end
		parts[#parts + 1] = "now " .. ns.Money(st.newest) .. trend
	end
	if st.low then parts[#parts + 1] = "week low " .. ns.Money(st.low) .. ", high " .. ns.Money(st.high) .. ", average " .. ns.Money(st.avg) end
	if e and e.qty and e.qty > 0 then parts[#parts + 1] = e.qty .. " listed" end
	if sell > 0 then parts[#parts + 1] = "vendor " .. ns.Money(sell) end
	parts[#parts + 1] = #points .. " price" .. (#points == 1 and "" or "s") .. " seen"
	setText(f.stats, table.concat(parts, " · "))

	local v = ns.V.ForItem(id, 1)
	local what
	if v.action == "auction" then what = "|cff40ff40Auction it|r at " .. ns.Money(v.price) .. " each"
	elseif v.action == "vendor" then what = "|cffff8040Vendor it|r: " .. (v.why or "")
	elseif v.action == "keep" then what = "Keep: " .. (v.why or "")
	else what = "No verdict yet: no price seen." end
	if st.vsAvg and st.vsAvg <= -0.2 and v.action == "auction" then
		what = what .. " · cheap right now: worth holding for a better price"
	end
	setText(f.verdict, what)

	local rows = ns.R.Find(id)
	local held = {}
	for _, r in ipairs(rows) do held[#held + 1] = r.name .. " " .. r.n end
	local home = ns.R.Home(id)
	setText(f.held, (#held > 0 and ("You have: " .. table.concat(held, ", ")) or "None on your characters")
		.. (home and (" · belongs on " .. home) or ""))
	f:Show()
end

function G.Search(text)
	local f = G.MakeWindow()
	local id = G.FindItem(text)
	if not id then
		setText(f.name, "Couldn't find \"" .. tostring(text) .. "\"")
		setText(f.stats, "Try its exact name, shift-click it, or open the auction house and search for it there first.")
		setText(f.verdict, ""); setText(f.held, "")
		for _, l in ipairs(f.lines) do l:Hide() end
		for _, b in ipairs(f.bars) do b:Hide() end
		f:Show()
		return nil
	end
	G.Draw(id)
	return id
end

function G.Open(text)
	local f = G.MakeWindow()
	f:Show()
	if text and text ~= "" then return G.Search(text) end
	if G.id then G.Draw(G.id) end
end

-- Shift-clicking an item while the search box has the focus puts it in the box and searches.
table.insert(ns.OnLoad, function()
	if hooksecurefunc and ChatEdit_InsertLink then
		hooksecurefunc("ChatEdit_InsertLink", function(link)
			local f = G.frame
			if f and f:IsShown() and f.box and f.box.HasFocus and f.box:HasFocus() then
				ns.Safe("graph link", function()
					f.box:SetText(link)
					G.Search(link)
				end)
			end
		end)
	end
end)

-- Redraw when new prices for the shown item come in.
function G.Refresh(id)
	if G.frame and G.frame:IsShown() and G.id == id then G.Draw(id) end
end
