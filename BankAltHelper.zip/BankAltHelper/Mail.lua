-- Bank Alt Helper: the mail helper. At a mailbox, a small panel lines up a mail for each of your
-- bank alts with just the items that belong to them. One press attaches up to 12 stacks and fills in
-- the name, another sends it. Items better sold to a vendor aren't sent (no postage on rubbish).
local _, ns = ...
local M = {}
ns.M = M

M.MAX = ATTACHMENTS_MAX_SEND or 12
M.choice = {}   -- [itemID] = name: who an item on several send lists goes to, this mailbox visit

local function setText(fs, s) if fs and fs.SetText then fs:SetText(s or "") end end

local function attachedCount()
	local n = 0
	if GetSendMailItem then
		for a = 1, M.MAX do if GetSendMailItem(a) then n = n + 1 end end
	end
	return n
end

function M.MakePanel()
	if M.frame then return M.frame end
	local parent = MailFrame or UIParent
	local f = CreateFrame("Frame", "BankAltHelperMailPanel", parent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:SetSize(300, 116)
	if MailFrame then f:SetPoint("TOPLEFT", MailFrame, "TOPRIGHT", 6, 0) else f:SetPoint("CENTER") end
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 14,
			insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	end
	f:SetFrameStrata("HIGH")
	f:EnableMouse(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	f.title:SetPoint("TOPLEFT", 10, -9)
	f.title:SetText("Send to your alts")
	f.line1 = f:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	f.line1:SetPoint("TOPLEFT", 10, -28); f.line1:SetWidth(280); f.line1:SetJustifyH("LEFT")
	f.line2 = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.line2:SetPoint("TOPLEFT", 10, -46); f.line2:SetWidth(280); f.line2:SetJustifyH("LEFT")

	local attach = CreateFrame("Button", "BankAltHelperAttachButton", f, "UIPanelButtonTemplate")
	attach:SetSize(150, 24); attach:SetPoint("BOTTOMLEFT", 10, 10)
	attach:SetText("Attach")
	attach:SetScript("OnClick", function() ns.Safe("attach", M.Attach) end)
	f.attach = attach

	local send = CreateFrame("Button", "BankAltHelperSendButton", f, "UIPanelButtonTemplate")
	send:SetSize(120, 24); send:SetPoint("LEFT", attach, "RIGHT", 6, 0)
	send:SetText("Send")
	send:SetScript("OnClick", function() ns.Safe("send", M.Send) end)
	f.send = send

	local rules = CreateFrame("Button", "BankAltHelperRulesButton", f, "UIPanelButtonTemplate")
	rules:SetSize(130, 20); rules:SetPoint("TOPRIGHT", -26, -6)
	rules:SetText("Send lists")
	rules:SetScript("OnClick", function() ns.Safe("rules", ns.W.Open) end)
	f.rules = rules

	local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 0, 0)
	close:SetScript("OnClick", function() f:Hide() end)
	M.frame = f
	return f
end

-- Works out who's next and what goes to them, and shows it.
function M.Refresh()
	if not ns.atMail then return end
	local out, order, ask = ns.R.Outgoing()
	local f = M.MakePanel()
	M.out, M.order, M.ask = out, order, ask
	local alt = M.target and out[M.target] and M.target or order[1]
	M.target = alt
	local waiting = attachedCount()
	local asking = ask and #ask > 0
	if M.fillFor and waiting == 0 then
		local left = #M.TickedStacks(M.fillFor)
		if left > 0 then
			setText(f.line1, M.fillFor .. ": " .. left .. " more stack" .. (left == 1 and "" or "s") .. " ticked for them.")
			setText(f.line2, "Attach puts the next mail together.")
			f.attach:SetText("Attach next for " .. M.fillFor)
			f.attach:SetEnabled(true)
			f.send:SetEnabled(false)
			f:Show()
			return
		end
		M.fillFor = nil
	end
	if M.fillFor and waiting > 0 then
		local left = #M.TickedStacks(M.fillFor)
		setText(f.line1, M.fillFor .. ": " .. waiting .. " stack" .. (waiting == 1 and "" or "s") .. " in the mail.")
		setText(f.line2, left > 0 and (left .. " more wait for the next mail.") or "Press Send.")
		f.attach:SetText("Attach more")
		f.attach:SetEnabled(waiting < M.MAX and left > 0)
		f.send:SetEnabled(true)
		f:Show()
		return
	end
	if not alt and asking then
		setText(f.line1, ns.ItemName(ask[1].id) .. " is ticked for " .. table.concat(ask[1].on, " and ") .. ".")
		setText(f.line2, "Press Choose to say who gets it this time.")
		f.attach:SetText("Choose")
		f.attach:SetEnabled(true)
		f.send:SetEnabled(false)
		f:Show()
		return
	end
	if not alt then
		local anyList = next(ns.R.Lists()) or next(ns.R.Alts())
		setText(f.line1, anyList and "Nothing in your bags is ticked for another character." or
			"Tick items for your alts: press Send lists.")
		setText(f.line2, "")
		f.attach:SetEnabled(false)
		f.send:SetEnabled(waiting > 0 and M.sendTo ~= nil)
		f:Show()
		return
	end
	local list = out[alt]
	local stacks = 0
	for _, it in ipairs(list) do stacks = stacks + M.Stacks(it.id) end
	local mails = math.ceil(stacks / M.MAX)
	setText(f.line1, string.format("%s: %d kinds, %d stacks (%d mail%s)", alt, #list, stacks, mails, mails == 1 and "" or "s"))
	local more = #order > 1 and (" · then " .. table.concat(order, ", ", 2)) or ""
	local free = ns.db.chars[alt] and ns.db.chars[alt].bags and ns.db.chars[alt].bags.free
	local room = free and (" · " .. free .. " free bag slots") or ""
	local askNote = asking and (" · " .. #ask .. " item" .. (#ask == 1 and "" or "s") .. " ticked for two: Attach asks") or ""
	setText(f.line2, M.mixed and ("This mail mixes items for " .. table.concat(M.mixed, " and ") .. ": split it up.")
		or ((ns.R.Describe(alt) or "") .. room .. more .. askNote))
	f.attach:SetText(waiting > 0 and "Attach more" or ("Attach for " .. alt))
	f.attach:SetEnabled(waiting < M.MAX)
	f.send:SetEnabled(waiting > 0)
	f:Show()
end

-- How many bag slots hold this item.
function M.Stacks(id)
	local n = 0
	for _, bag in ipairs(ns.S.BagIDs()) do
		local slots = (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag)) or 0
		for slot = 1, slots do
			local i = ns.S.SlotInfo(bag, slot)
			if i and i.id == id and ns.Sellable(i) and not i.locked then n = n + 1 end
		end
	end
	return n
end

local function showSendTab()
	if MailFrameTab_OnClick then pcall(MailFrameTab_OnClick, nil, 2) end
end

-- ---------------------------------------------------------------- "send it to whom?"

-- A small box: "Peacebloom is ticked for more than one character. Send it to:" and a button each.
-- "Always" also unticks it for the others, so it won't ask again.
function M.MakeAsk()
	if M.askFrame then return M.askFrame end
	local a = CreateFrame("Frame", "BankAltHelperAsk", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	a:Hide()
	a:SetSize(300, 150)
	a:SetPoint("CENTER", 0, 120)
	if a.SetBackdrop then
		a:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 14,
			insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	end
	a:SetFrameStrata("FULLSCREEN_DIALOG")
	a:EnableMouse(true)
	a.icon = a:CreateTexture(nil, "ARTWORK")
	a.icon:SetSize(28, 28); a.icon:SetPoint("TOPLEFT", 12, -12)
	a.text = a:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
	a.text:SetPoint("TOPLEFT", 46, -12); a.text:SetWidth(240); a.text:SetJustifyH("LEFT")
	a.buttons = {}
	for i = 1, 6 do
		local b = CreateFrame("Button", "BankAltHelperAsk" .. i, a, "UIPanelButtonTemplate")
		b:SetSize(276, 22)
		b:SetPoint("TOPLEFT", 12, -50 - (i - 1) * 24)
		b:SetScript("OnClick", function(self) ns.Safe("choose", M.Chosen, self.who) end)
		a.buttons[i] = b
	end
	local always = CreateFrame("CheckButton", "BankAltHelperAskAlways", a, "UICheckButtonTemplate")
	always:SetSize(22, 22)
	a.always = always
	a.alwaysText = a:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	a.alwaysText:SetText("Always send it there (untick it for the others)")
	local close = CreateFrame("Button", nil, a, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 0, 0)
	close:SetScript("OnClick", function() a:Hide() end)
	M.askFrame = a
	return a
end

-- Asks who an item goes to; andThen runs after a choice.
function M.Ask(id, on, andThen)
	local a = M.MakeAsk()
	a.id, a.on, a.andThen = id, on, andThen
	local _, _, _, _, icon = ns.ItemInfo(id)
	if a.icon.SetTexture then a.icon:SetTexture(icon or 134400) end
	setText(a.text, ns.ItemName(id) .. " is ticked for more than one character. Send it to:")
	for i, b in ipairs(a.buttons) do
		local who = on[i]
		b.who = who
		if who then setText(b, who); b:Show() else b:Hide() end
	end
	local n = math.min(#on, #a.buttons)
	a.always:SetChecked(false)
	a.always:ClearAllPoints()
	a.always:SetPoint("TOPLEFT", 10, -52 - n * 24)
	a.alwaysText:ClearAllPoints()
	a.alwaysText:SetPoint("LEFT", a.always, "RIGHT", 2, 0)
	a:SetHeight(90 + n * 24)
	a:Show()
end

function M.Chosen(who)
	local a = M.askFrame
	if not a or not a.id or not who then return end
	M.choice[a.id] = who
	if a.always:GetChecked() then
		for _, other in ipairs(a.on) do if other ~= who then ns.R.SetListed(other, a.id, false) end end
		ns.Print(ns.ItemName(a.id) .. " now always goes to " .. who .. ".")
	end
	local andThen = a.andThen
	a.id, a.on, a.andThen = nil, nil, nil
	a:Hide()
	if andThen then andThen() end
	M.Refresh()
end

-- One press: attaches up to 12 stacks for the alt shown and fills in its name. If an item in your
-- bags is ticked for two characters, it asks about that first.
function M.Attach()
	if M.fillFor then
		M.FillFor(M.fillFor)
		return
	end
	if M.ask and #M.ask > 0 then
		local first = M.ask[1]
		M.Ask(first.id, first.on)
		return
	end
	local alt = M.target
	local list = alt and M.out and M.out[alt]
	if not list then return end
	if M.sendTo and M.sendTo ~= alt and attachedCount() > 0 then
		ns.Print("send or clear the mail for " .. M.sendTo .. " first.")
		return
	end
	showSendTab()
	local want = {}
	for _, it in ipairs(list) do want[it.id] = true end
	local room = M.MAX - attachedCount()
	local use = (C_Container and C_Container.UseContainerItem) or UseContainerItem
	local added = 0
	for _, bag in ipairs(ns.S.BagIDs()) do
		local slots = (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag)) or 0
		for slot = 1, slots do
			if added >= room then break end
			local i = ns.S.SlotInfo(bag, slot)
			if i and want[i.id] and ns.Sellable(i) and not i.locked then
				M.adding = true
				use(bag, slot)
				M.adding = false
				added = added + 1
			end
		end
	end
	if SendMailNameEditBox and SendMailNameEditBox.SetText then SendMailNameEditBox:SetText(alt) end
	if SendMailSubjectEditBox and SendMailSubjectEditBox.SetText then
		SendMailSubjectEditBox:SetText("For " .. (ns.R.Describe(alt) or "the bank"))
	end
	M.sendTo = alt
	ns.After(0.2, M.Refresh)
end

-- One press: sends what's attached to the alt it was attached for.
function M.Send()
	local to = M.sendTo
	if not to or attachedCount() == 0 then return end
	local subject = SendMailSubjectEditBox and SendMailSubjectEditBox.GetText and SendMailSubjectEditBox:GetText()
	SendMail(to, (subject and subject ~= "") and subject or "Bank Alt Helper", "")
end

-- Drop items into a mail yourself and the name fills itself in: if everything attached belongs
-- on one alt, that alt's name goes in the To box, so the game's own Send button sends it there.
-- A name you typed yourself is never replaced.
function M.AutoName()
	if not ns.atMail or not ns.db.settings.autoName then return end
	if M.fillFor and M.sendTo == M.fillFor then return end -- (you picked who this mail is for)
	local box = SendMailNameEditBox
	if not box or not box.GetText or not box.SetText then return end
	local typed = box:GetText() or ""
	local ours = typed == "" or typed == M.autoFilled
	local homes, list = {}, {}
	if GetSendMailItem then
		for a = 1, M.MAX do
			local name, id = GetSendMailItem(a)
			if name or id then
				id = id or (GetSendMailItemLink and ns.ItemID(GetSendMailItemLink(a)))
				local home, why, several
				if id then home, why, several = ns.R.Home(id) end
				if several then
					-- dropped in by hand, but ticked for two: ask, then fill in the name
					if not (M.askFrame and M.askFrame:IsShown() and M.askFrame.id == id) then
						M.Ask(id, several, M.AutoName)
					end
					return
				end
				local key = home or "(no alt)"
				if not homes[key] then homes[key] = true; list[#list + 1] = key end
			end
		end
	end
	M.mixed = nil
	if #list == 0 then
		if M.autoFilled and typed == M.autoFilled then box:SetText("") end
		M.autoFilled = nil
		return
	end
	if #list > 1 then
		table.sort(list)
		M.mixed = list
		if ours and M.autoFilled then box:SetText("") ; M.autoFilled = nil end
		return
	end
	local home = list[1]
	if home == "(no alt)" or home == ns.Me() or not ours then return end
	box:SetText(home)
	M.autoFilled = home
	if SendMailSubjectEditBox and SendMailSubjectEditBox.GetText and (SendMailSubjectEditBox:GetText() or "") == "" then
		SendMailSubjectEditBox:SetText("For " .. (ns.R.Describe(home) or "the bank"))
	end
end

-- ---------------------------------------------------------------- fill the mail for a character
-- Clicking a character in Send lists at a mailbox: every item ticked for them goes into the mail
-- (up to 12 stacks) and their name goes in, ready for you to press Send. What doesn't fit waits:
-- after the send, Attach (or clicking them again) fills the next mail. An item ticked for two
-- characters goes to the one you clicked.

-- Stacks in your bags ticked for who, not already in a mail: a list of {bag, slot}.
function M.TickedStacks(who)
	local list = ns.R.Lists()[who]
	local out = {}
	if type(list) ~= "table" then return out end
	for _, bag in ipairs(ns.S.BagIDs()) do
		local slots = (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag)) or 0
		for slot = 1, slots do
			local i = ns.S.SlotInfo(bag, slot)
			if i and i.id and list[i.id] and ns.Sellable(i) and not i.locked and not ns.db.settings.stay[i.id] then
				out[#out + 1] = { bag = bag, slot = slot, id = i.id }
			end
		end
	end
	return out
end

function M.FillFor(who)
	if not ns.atMail or type(who) ~= "string" or who == ns.Me() then return 0, 0 end
	showSendTab()
	local box = SendMailNameEditBox
	local typed = box and box.GetText and box:GetText() or ""
	local n = attachedCount()
	if n > 0 then
		local current = M.sendTo or (typed ~= "" and ns.Resolve(typed)) or nil
		if current and current ~= who then
			ns.Print("send or clear the mail for " .. current .. " first.")
			return 0, 0
		end
	end
	local stacks = M.TickedStacks(who)
	if #stacks == 0 then
		ns.Print("nothing ticked for " .. who .. " is in your bags.")
		M.fillFor = nil
		M.Refresh()
		return 0, 0
	end
	local use = (C_Container and C_Container.UseContainerItem) or UseContainerItem
	local room = M.MAX - n
	local added = 0
	M.adding = true
	for _, s in ipairs(stacks) do
		if added >= room then break end
		if pcall(use, s.bag, s.slot) then added = added + 1 end
	end
	M.adding = false
	if box and box.SetText then box:SetText(who) end
	if SendMailSubjectEditBox and SendMailSubjectEditBox.SetText then
		SendMailSubjectEditBox:SetText("For " .. who)
	end
	M.sendTo, M.fillFor, M.autoFilled = who, who, who
	local left = #stacks - added
	ns.Print(added .. " stack" .. (added == 1 and "" or "s") .. " in the mail for " .. who
		.. (left > 0 and (" · " .. left .. " more go in the next mail") or "") .. ": press Send.")
	ns.After(0.2, M.Refresh)
	return added, left
end

-- ---------------------------------------------------------------- every stack at once

local function sendTabOpen()
	if SendMailFrame and SendMailFrame.IsShown then return SendMailFrame:IsShown() end
	return ns.atMail
end

-- You put one stack of something in a mail: the rest of that item from your bags goes in too,
-- as many as the mail has room for. This runs inside your own click, which WoW requires.
function M.AddStacks(id, exceptBag, exceptSlot)
	if M.adding or not id or not ns.atMail or not ns.db.settings.autoStacks then return 0, 0 end
	if not sendTabOpen() then return 0, 0 end
	local use = (C_Container and C_Container.UseContainerItem) or UseContainerItem
	if not use then return 0, 0 end
	local room = M.MAX - attachedCount()
	local added, left = 0, 0
	M.adding = true
	for _, bag in ipairs(ns.S.BagIDs()) do
		local slots = (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag)) or 0
		for slot = 1, slots do
			if not (bag == exceptBag and slot == exceptSlot) then
				local i = ns.S.SlotInfo(bag, slot)
				if i and i.id == id and ns.Sellable(i) and not i.locked then
					if added < room then
						local ok = pcall(use, bag, slot)
						if ok then added = added + 1 else left = left + 1 end
					else
						left = left + 1
					end
				end
			end
		end
	end
	M.adding = false
	if added > 0 or left > 0 then
		ns.Print("added " .. added .. " more stack" .. (added == 1 and "" or "s") .. " of " .. ns.ItemName(id)
			.. (left > 0 and (" · " .. left .. " didn't fit: send this mail, then put one in again") or "") .. ".")
	end
	return added, left
end

-- A right-click on a bag item while the send tab is open (the game attaches it).
function M.OnUseItem(bag, slot)
	if M.adding or not ns.atMail then return end
	local i = ns.S.SlotInfo(bag, slot)
	local id = i and i.id
	if not id then
		-- (the slot already emptied: the newest attachment is the one)
		local n = attachedCount()
		if n > 0 and GetSendMailItem then id = select(2, GetSendMailItem(n)) end
	end
	if id then M.AddStacks(id, bag, slot) end
end

-- An item dragged onto one of the mail's attachment slots.
function M.OnDropItem(index)
	if M.adding or not ns.atMail or not GetSendMailItem then return end
	local _, id = GetSendMailItem(index or attachedCount())
	if id then M.AddStacks(id) end
end

table.insert(ns.OnLoad, function()
	if not hooksecurefunc then return end
	local hook = function(bag, slot) ns.Safe("add stacks", M.OnUseItem, bag, slot) end
	if C_Container and C_Container.UseContainerItem then hooksecurefunc(C_Container, "UseContainerItem", hook) end
	if UseContainerItem then hooksecurefunc("UseContainerItem", hook) end
	if ClickSendMailItemButton then
		hooksecurefunc("ClickSendMailItemButton", function(index) ns.Safe("add stacks", M.OnDropItem, index) end)
	end
end)

function M.Opened()
	ns.atMail = true
	M.target, M.sendTo, M.autoFilled, M.fillFor = nil, nil, nil, nil
	M.choice = {}
	ns.After(0.3, M.Refresh)
end

ns.On("MAIL_SHOW", M.Opened)
-- A backup in case the mailbox event is missed: the mail window showing does the same.
table.insert(ns.OnLoad, function()
	if MailFrame and MailFrame.HookScript then
		MailFrame:HookScript("OnShow", function() if not ns.atMail then ns.Safe("mail open", M.Opened) end end)
		MailFrame:HookScript("OnHide", function()
			if ns.atMail then
				ns.atMail = false
				if M.frame then M.frame:Hide() end
				M.sendTo, M.autoFilled = nil, nil
			end
		end)
	end
end)
ns.On("MAIL_CLOSED", function()
	if M.frame then M.frame:Hide() end
	if M.askFrame then M.askFrame:Hide() end
	M.sendTo, M.autoFilled, M.choice, M.fillFor = nil, nil, {}, nil
end)
ns.On("MAIL_SEND_SUCCESS", function() M.sendTo, M.autoFilled = nil, nil; ns.After(0.5, M.Refresh) end)
ns.On("MAIL_SEND_INFO_UPDATE", function()
	if not ns.atMail then return end
	M.AutoName()
	ns.After(0.1, M.Refresh)
end)
