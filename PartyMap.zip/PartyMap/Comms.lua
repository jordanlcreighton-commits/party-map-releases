-- Party Map: swaps positions, quest logs and quest markers with party members who also run
-- Party Map, using WoW's hidden addon messages (nothing shows in chat).
--
--   prefix PartyMapP (position, about once a second while it changes):
--     1|u|v|facing|mapID|flags|form     u, v: world map position x 100000 (-1: unknown); facing x 1000;
--                                        form: shapeshift form (0 none), for when their portrait changes
--   prefix PartyMapD (data, when it changes, in pieces of up to ~230 bytes):
--     1|kind|rev|i|n|piece               kind: q = quest log, m = markers, k = pins, b = bags; piece i of n
--                                        (b: "bag|size|slot,slot,..." lines, a slot "itemID" or "itemID*count",
--                                        empty ""; "off" = not sharing)
--     1|R                                "please send me everything" (someone new heard you)
--     1|s|kind|key|ver|i|n|piece         one section of it (since 16/11): only the part that changed goes,
--                                        e.g. one quest and its objectives ("q<questID>"), the XP line ("XP"),
--                                        one quest's markers ("M<questID>"); piece i of n of version ver
--     1|x|kind|ver|i|n|keys              the sections there are now, in order ("q123,q456,XP,...")
--   (since 0.15.0, read by 0.15.0 and newer only; older addons ignore them)
--     1|v|kind|listver|i|n|vers          the version of every section, in the list's order: a friend
--                                        who has an older copy of one asks for just that one
--     1|w|kind|who|keys                  "who, please send me these sections again" (keys "*": all,
--                                        "|list": the list)
--     1|S|kind|key,ver,len;...|texts     several whole sections in one message (only while everyone
--                                        in the group who runs Party Map is on 0.15.0 or newer)
--     1|R|version                        "send me everything", with the asker's Party Map version
--   PartyMapP gains an 8th field, the sender's Party Map version, and (0.15.1) a 9th: the oldest
--   version its update can reach with just a /reload (older addons ignore both)
-- WoW lets an addon send about one message a second per prefix (more are dropped), so data goes
-- through its own queue at that pace; what's waiting is always sent as it is at that moment, so a
-- quest that changes five times while it waits goes once. Every few seconds one section is sent
-- again anyway (round and round), so anything lost gets mended.

local addonName, ns = ...

local C = {}
ns.Comms = C

local P_POS, P_DATA = "PartyMapP", "PartyMapD"
local PIECE = 230
local MSG_MAX = 250                     -- (WoW's limit for one addon message is 255 bytes)

-- this addon's version: the same number as the TOC's, the app's and Mika's zips (test/check_all.py
-- checks). Written here rather than read from the TOC, which the game only reads when it starts, so
-- a /reload brings the new number with it.
C.VERSION = "0.16.6"
-- from an addon older than this, the update needs a full WoW restart (a new addon file, the TOC's
-- file list or the strip format changed); from this or newer a /reload is enough
C.RESTART_SINCE = "0.15.0"
ns.VERSION = C.VERSION
C.PROTO = 2                             -- party message format: 2 = sections, digests and packs (0.15.0)

-- a.b.c >= x.y.z
local function AtLeast(v, want)
	if type(v) ~= "string" then return false end
	local a = { v:match("^(%d+)%.(%d+)%.?(%d*)") }
	local b = { want:match("^(%d+)%.(%d+)%.?(%d*)") }
	if not a[1] then return false end
	for i = 1, 3 do
		local x, y = tonumber(a[i]) or 0, tonumber(b[i]) or 0
		if x ~= y then return x > y end
	end
	return true
end
C.AtLeast = AtLeast

-- errors the addon catches itself, counted so /partymap check can show them (a feature quietly
-- failing would otherwise never be seen)
ns.errors = ns.errors or { n = 0, last = nil, where = {} }
function ns.Err(where, e)
	local E = ns.errors
	E.n = E.n + 1
	E.where[where] = (E.where[where] or 0) + 1
	E.last = where .. ": " .. tostring(e):sub(1, 200)
end
C.unknown = 0                           -- messages in a format this version doesn't know (ignored)
local POS_EVERY, POS_IDLE = 1.0, 5.0    -- seconds: while moving, and at least this often anyway

ns.Others = ns.Others or {}            -- [name] = { u, v, facing, mapID, flags, seen, quests, markers, asm = {} }

-- test mode (/partymap test): everything you send also comes back to you as a pretend friend,
-- "<you> (echo)", standing just beside you
C.test = false
local ECHO_DU, ECHO_DV = 0.0025, 0.0018

local function GroupChannel()
	if IsInGroup and IsInGroup(LE_PARTY_CATEGORY_INSTANCE or 2) then return "INSTANCE_CHAT" end
	if IsInRaid and IsInRaid() then return "RAID" end
	if IsInGroup and IsInGroup() then return "PARTY" end
	if C.test then return "WHISPER", UnitName("player") end
end

-- a character's own name, the way addon messages name them: no realm, and no surname (WoW Forever
-- shows "Bron Umberhide" where the character is "Bron"; names never contain spaces)
local function Short(name)
	if not name then return end
	if Ambiguate then name = Ambiguate(name, "short") end
	return (name:gsub("%-.*$", ""):gsub("%s.*$", ""))
end

-- of two names for someone, the fuller one ("Mika Underhide" over "Mika")
local function Fuller(old, new)
	if type(new) ~= "string" or new == "" then return old end
	if type(old) == "string" and old:find(" ") and not new:find(" ") then return old end
	return new
end

-- the name to show: the full one, surname and all
local function Display(name)
	if type(name) ~= "string" or name == "" then return end
	return (name:gsub("%-.*$", ""))
end

local me = Short(UnitName("player"))

-- sending, kept under WoW's limits: ChatThrottleLib when another addon has loaded it, else a
-- small queue of our own (a burst of a few, then one every half second)
local queue, tokens, lastRefill = {}, 8, 0
local BURST, PER_SEC = 8, 1.0
local function RawSend(prefix, msg, chan, target)
	if C_ChatInfo and C_ChatInfo.SendAddonMessage then
		return pcall(C_ChatInfo.SendAddonMessage, prefix, msg, chan, target)
	elseif SendAddonMessage then
		return pcall(SendAddonMessage, prefix, msg, chan, target)
	end
end
local OnMessage
local function Send(prefix, msg, prio)
	local chan, target = GroupChannel()
	if not chan then return end
	if prefix == P_DATA then
		queue[#queue + 1] = { msg = msg }
	elseif ChatThrottleLib and ChatThrottleLib.SendAddonMessage then
		pcall(ChatThrottleLib.SendAddonMessage, ChatThrottleLib, prio or "NORMAL", prefix, msg, chan, target)
	else
		RawSend(prefix, msg, chan, target)
	end
	-- in test mode, also hand it straight back (in case the game doesn't echo whispers to yourself)
	if C.test and OnMessage and prefix ~= P_DATA then pcall(OnMessage, prefix, msg, "LOCAL", UnitName("player"), true) end
end
local MessagesFor   -- (below: a waiting section's messages, made as it is now)
local refreshAt, refreshI, indexAt = 0, 0, 0
local AllKeys, Digests, Reask, Pack
local again, Agains = {}, nil   -- (below: sections to send once more)
function C.Pump(now)
	tokens = math.min(BURST, tokens + (now - lastRefill) * PER_SEC)
	lastRefill = now
	-- (nothing waiting: send one section again, round and round, and the lists of sections now and
	-- then, so a lost message is mended)
	if #queue == 0 and GroupChannel() and now >= refreshAt and tokens >= BURST - 1 then
		refreshAt = now + 4
		if now >= indexAt then
			indexAt = now + 30
			for _, kind in ipairs({ "q", "m", "k", "b" }) do queue[#queue + 1] = { kind = kind, index = true } end
		else
			local all = AllKeys()
			if #all > 0 then
				refreshI = refreshI % #all + 1
				queue[#queue + 1] = all[refreshI]
			end
		end
	end
	C.LegacyPump(now)
	Digests(now)
	Reask(now)
	Agains(now)
	while tokens >= 1 and #queue > 0 do
		local m = table.remove(queue, 1)
		local chan, target = GroupChannel()
		if not chan then wipe(queue); return end
		local msgs = m.msg and { m.msg } or Pack(m) or MessagesFor(m)
		for k, msg in ipairs(msgs) do
			local ok, res = RawSend(P_DATA, msg, chan, target)
			-- (the game said too many: put this and the rest back and wait a couple of seconds)
			if ok and (res == false or (type(res) == "number" and res ~= 0)) then
				for j = #msgs, k, -1 do table.insert(queue, 1, { msg = msgs[j] }) end
				tokens = -2
				return
			end
			if C.test and OnMessage then pcall(OnMessage, P_DATA, msg, "LOCAL", UnitName("player"), true) end
			tokens = tokens - 1
		end
	end
end

-- my own data (set by Core.lua), cut into sections: one quest with its heading and objectives, one
-- quest's markers, or all the lines of one kind (XP, bags, money...)
local mine = {}
for _, kind in ipairs({ "q", "m", "k", "b" }) do mine[kind] = { text = "", secs = {}, ver = {}, order = {}, iver = 0 } end
local lastPos, lastPosT = nil, 0

local function Sections(text)
	local secs, order, heading, cur = {}, {}, nil, nil
	local function add(key, line)
		if not secs[key] then secs[key] = {}; order[#order + 1] = key end
		local t = secs[key]; t[#t + 1] = line
	end
	for line in text:gmatch("[^\n]+") do
		local tag, rest = line:match("^([^|]*)|?(.*)$")
		if tag == "H" then
			heading, cur = line, nil
		elseif tag == "Q" then
			cur = "q" .. (rest:match("^([^|]*)") or "")
			if heading then add(cur, heading) end
			add(cur, line)
		elseif tag == "O" and cur then
			add(cur, line)
		else
			cur = nil
			if tag == "M" then tag = "M" .. (rest:match("^([^|]*)") or "") end
			add((tag ~= "" and tag or "_"):gsub("[|,;]", "_"):sub(1, 24), line)
		end
	end
	for k, t in pairs(secs) do secs[k] = table.concat(t, "\n") end
	return secs, order
end

local function Waiting(kind, key, index)
	for i, m in ipairs(queue) do
		if m.kind == kind and not m.digest and (index and m.index or (not index and not m.index and m.key == key)) then return i end
	end
end
-- (something already waiting that should go first now, a quest that just changed behind a full
-- resend, say, moves to the front)
local function Queue(kind, key, front)
	local at = Waiting(kind, key, key == nil)
	if at then
		if front and at > 1 then table.insert(queue, 1, table.remove(queue, at)) end
		return
	end
	local e = { kind = kind, key = key, index = key == nil }
	if front then table.insert(queue, 1, e) else queue[#queue + 1] = e end
end
C.QueueForTest = function() return queue end
-- sections to send once more: { t, kind, key }
function C.Again(kind, key)
	for _, a in ipairs(again) do if a.kind == kind and a.key == key then a.t = GetTime() + 2; return end end
	again[#again + 1] = { t = GetTime() + 2, kind = kind, key = key }
end
Agains = function(now)
	local i = 1
	while i <= #again do
		local a = again[i]
		if now >= a.t then
			table.remove(again, i)
			if mine[a.kind] and mine[a.kind].secs[a.key] then Queue(a.kind, a.key, true) end
		else
			i = i + 1
		end
	end
end

MessagesFor = function(m)
	local d = mine[m.kind]
	local out = {}
	if m.digest then
		local v = {}
		for i, key in ipairs(d.order) do v[i] = tostring(d.ver[key] or 0) end
		local list = table.concat(v, ",")
		local n = math.max(1, math.ceil(#list / PIECE))
		for i = 1, n do out[#out + 1] = ("1|v|%s|%d|%d|%d|%s"):format(m.kind, d.iver, i, n, list:sub((i - 1) * PIECE + 1, i * PIECE)) end
		return out
	end
	if m.index then
		local list = table.concat(d.order, ",")
		local n = math.max(1, math.ceil(#list / PIECE))
		for i = 1, n do out[#out + 1] = ("1|x|%s|%d|%d|%d|%s"):format(m.kind, d.iver, i, n, list:sub((i - 1) * PIECE + 1, i * PIECE)) end
		return out
	end
	local text = d.secs[m.key]
	if not text then return out end   -- (gone since: the list says so)
	local n = math.max(1, math.ceil(#text / PIECE))
	for i = 1, n do
		out[#out + 1] = ("1|s|%s|%s|%d|%d|%d|%s"):format(m.kind, m.key, d.ver[m.key] or 0, i, n, text:sub((i - 1) * PIECE + 1, i * PIECE))
	end
	return out
end

AllKeys = function()
	local all = {}
	for _, kind in ipairs({ "q", "m", "k", "b" }) do
		for _, key in ipairs(mine[kind].order) do all[#all + 1] = { kind = kind, key = key } end
	end
	return all
end

-- who in the group runs Party Map 0.15.0 or newer (they say so in their messages)
local function PeersNew()
	local any, all = false, true
	for name, o in pairs(ns.Others) do
		if o.pm and not name:find(" %(echo%)$") then
			if AtLeast(o.version, "0.15.0") then any = true else all = false end
		end
	end
	return any, any and all
end
C.PeersNew = PeersNew

-- the newest Party Map anyone in the group runs, if it's newer than this one (and the oldest version
-- that can reach it with a /reload)
function C.NewestPeer()
	local best, since
	for name, o in pairs(ns.Others) do
		if o.pm and o.version and not name:find(" %(echo%)$") and AtLeast(o.version, "0.0.0") and not AtLeast(C.VERSION, o.version) then
			if not best or not AtLeast(best, o.version) then best, since = o.version, o.restartSince end
		end
	end
	return best, since
end

-- the versions of my sections, now and then, so friends on 0.15.0+ notice a lost message within
-- seconds (the quest log every 8 s, the rest every 30 s)
local DIGEST_EVERY = { q = 6, m = 30, k = 30, b = 30 }
local digestAt = {}
Digests = function(now)
	if not GroupChannel() then return end
	if not PeersNew() then return end
	for _, kind in ipairs({ "q", "m", "k", "b" }) do
		if #mine[kind].order > 0 and now >= (digestAt[kind] or 0) then
			digestAt[kind] = now + DIGEST_EVERY[kind]
			local waiting = false
			for _, m in ipairs(queue) do if m.digest and m.kind == kind then waiting = true end end
			if not waiting then queue[#queue + 1] = { kind = kind, digest = true } end
		end
	end
end

-- someone we hear moving but have no quest log from yet: ask again (the first ask can be lost)
local askedAt = {}
Reask = function(now)
	for name, o in pairs(ns.Others) do
		local a = askedAt[name]
		if a and o.seen and now - o.seen < 10 and (o.quests or "") == "" and now - a.t >= 10 and a.n < 4 then
			a.t, a.n = now, a.n + 1
			queue[#queue + 1] = { msg = "1|R|" .. C.VERSION }
		end
	end
end

-- several whole sections of one kind in one message, when everyone can read that
Pack = function(m)
	if not (m.kind and m.key and not m.index and not m.digest and not m.legacy) then return end
	local _, all = PeersNew()
	if not all then return end
	local d = mine[m.kind]
	local entries, texts, used = {}, {}, 0
	local head = ("1|S|%s|"):format(m.kind)
	local function try(key)
		local text = d.secs[key]
		if not text then return false end
		local e = ("%s,%d,%d"):format(key, d.ver[key] or 0, #text)
		local size = #head + used + #text + #e + #entries + 2
		if size > MSG_MAX then return false end
		entries[#entries + 1], texts[#texts + 1], used = e, text, used + #text + #e
		return true
	end
	if not try(m.key) then return end   -- (too long to go whole: the usual pieces)
	local i = 1
	while i <= #queue do
		local q = queue[i]
		if q.kind == m.kind and q.key and not q.index and not q.digest and not q.legacy and try(q.key) then
			table.remove(queue, i)
		else
			i = i + 1
		end
	end
	return { head .. table.concat(entries, ";") .. "|" .. table.concat(texts) }
end

local function SendData(kind)
	local d = mine[kind]
	Queue(kind, nil, true)
	for _, key in ipairs(d.order) do Queue(kind, key) end
end

function C.SetMine(kind, text)
	local d = mine[kind]
	if d.text == text then return end
	d.text = text
	local secs, order = Sections(text)
	local listChanged = #order ~= #d.order
	if not listChanged then for i, k in ipairs(order) do if d.order[i] ~= k then listChanged = true; break end end end
	local changed = {}
	for _, k in ipairs(order) do
		if secs[k] ~= d.secs[k] then d.ver[k] = ((d.ver[k] or 0) + 1) % 10000; changed[#changed + 1] = k end
	end
	d.secs, d.order = secs, order
	if listChanged then d.iver = (d.iver + 1) % 10000 end
	if not GroupChannel() then return end
	if listChanged then Queue(kind, nil, true) end
	-- (quest log changes first: they're what the others are watching; each goes once more a couple
	-- of seconds later, so one lost message doesn't leave a friend's count behind)
	for _, k in ipairs(changed) do
		Queue(kind, k, kind == "q")
		if kind == "q" then C.Again(kind, k) end
	end
end

-- Someone in the party on an older Party Map (before 16/11) can only read whole copies ("1|q|rev|i|n|piece"),
-- so while anyone is heard sending those, whole copies go too, at most one a kind every 20 seconds
local LEGACY_EVERY = 20
local legacySent, legacyRev = {}, {}
local function LegacyWanted()
	local now = GetTime()
	for _, o in pairs(ns.Others) do
		if o.legacyAt and now - o.legacyAt < 180 then return true end
	end
end
function C.LegacyPump(now)
	if not LegacyWanted() then return end
	for _, kind in ipairs({ "q", "b", "k", "m" }) do
		local d = mine[kind]
		if d.legacyDirty and now - (legacySent[kind] or -1e9) >= LEGACY_EVERY then
			local waiting
			for _, m in ipairs(queue) do if m.legacy == kind then waiting = true end end
			if not waiting then
				d.legacyDirty = false
				legacySent[kind] = now
				queue[#queue + 1] = { legacy = kind }
			end
		end
	end
end
local Sections0 = MessagesFor
MessagesFor = function(m)
	if not m.legacy then return Sections0(m) end
	local d = mine[m.legacy]
	legacyRev[m.legacy] = ((legacyRev[m.legacy] or 0) + 1) % 10000
	local out, text = {}, d.text
	local n = math.max(1, math.ceil(#text / PIECE))
	for i = 1, n do
		out[#out + 1] = ("1|%s|%d|%d|%d|%s"):format(m.legacy, legacyRev[m.legacy], i, n, text:sub((i - 1) * PIECE + 1, i * PIECE))
	end
	return out
end
local SetMine0 = C.SetMine
function C.SetMine(kind, text)
	if mine[kind].text ~= text then mine[kind].legacyDirty = true end
	return SetMine0(kind, text)
end
local function LegacyAll()
	for _, kind in ipairs({ "q", "m", "k", "b" }) do mine[kind].legacyDirty = true; legacySent[kind] = nil end
end

-- Pins: spots marked on the map for the party ("K|id|u|v|label" lines, u/v x100000), five each at most,
-- gone after 30 minutes. Dropped with /partymap pin, Alt+click on the world map, or pasted from the
-- Party Map window.
local PIN_MAX, PIN_LIFE = 5, 1800
C.myPins = {}
local pinSeq = 0

local function SharePins()
	local out = {}
	for _, p in ipairs(C.myPins) do
		out[#out + 1] = ("K|%d|%d|%d|%s"):format(p.id, math.floor(p.u * 100000 + 0.5), math.floor(p.v * 100000 + 0.5), p.label)
	end
	C.SetMine("k", table.concat(out, "\n"))
end

function C.AddPin(u, v, label)
	if not (u and v) then return end
	label = (label or ""):gsub("[|\r\n]", " "):sub(1, 30)
	pinSeq = pinSeq + 1
	table.insert(C.myPins, { id = (time() % 100000) * 10 + pinSeq % 10, u = u, v = v, label = label, t = GetTime() })
	while #C.myPins > PIN_MAX do table.remove(C.myPins, 1) end
	SharePins()
	return true
end

function C.ClearPins()
	wipe(C.myPins)
	SharePins()
end

local function PrunePins(now)
	local changed = false
	for i = #C.myPins, 1, -1 do
		if now - C.myPins[i].t > PIN_LIFE then table.remove(C.myPins, i); changed = true end
	end
	if changed then SharePins() end
end

local told = {}
function C.TheirPins(o, text, name)
	o.pins = {}
	for line in text:gmatch("[^\n]+") do
		local id, u, v, label = line:match("^K|(%d+)|(%d+)|(%d+)|(.*)$")
		if id then
			o.pins[#o.pins + 1] = { id = tonumber(id), u = tonumber(u) / 100000, v = tonumber(v) / 100000, label = label }
			local key = name .. id
			if not told[key] then
				told[key] = true
				print(("|cffF0B04AParty Map|r %s dropped a pin%s."):format(o.display or name, label ~= "" and (": " .. label) or ""))
			end
		end
	end
end

-- called every frame by Core.lua with my position
local lastPrune = 0
function C.Tick(now, u, v, facing, mapID, flags)
	C.Pump(now)
	if now - lastPrune > 5 then lastPrune = now; PrunePins(now) end
	if not GroupChannel() then return end
	-- (the last field: your shapeshift form, so a friend's Party Map knows when your portrait changes)
	local form = GetShapeshiftFormID and GetShapeshiftFormID() or 0
	local msg = ("1|%d|%d|%d|%d|%d|%d|%s|%s"):format(u and math.floor(u * 100000 + 0.5) or -1, v and math.floor(v * 100000 + 0.5) or -1,
		facing and math.floor(facing * 1000 + 0.5) or -1, mapID or 0, flags or 0, tonumber(form) or 0, C.VERSION, C.RESTART_SINCE)
	local moved = msg ~= lastPos
	if (moved and now - lastPosT >= POS_EVERY) or now - lastPosT >= POS_IDLE then
		Send(P_POS, msg, "ALERT")
		lastPos, lastPosT = msg, now
	end
end

local function Other(name)
	local o = ns.Others[name]
	if not o then
		o = { asm = {}, quests = "", markers = "" }
		ns.Others[name] = o
	end
	return o
end

local asked = {}
function OnMessage(prefix, msg, chan, sender, isEcho)
	local name = Short(sender)
	if not name then return end
	local echo = false
	if name == me then
		if not C.test then return end
		name, echo = me .. " (echo)", true
	end
	local o0 = ns.Others[name]
	if echo and o0 and not o0.display then o0.display = (Display(UnitName("player")) or me) .. " (echo)" end
	if prefix == P_POS then
		local ver, u, v, f, mapID, flags, form, aver, rsince = strsplit("|", msg)
		if ver ~= "1" then C.unknown = C.unknown + 1; return end
		local o = Other(name)
		o.pm = true
		if aver and aver ~= "" then o.version = aver:sub(1, 12) end
		if rsince and rsince ~= "" then o.restartSince = rsince:sub(1, 12) end
		u, v, f = tonumber(u), tonumber(v), tonumber(f)
		o.u = (u and u >= 0) and u / 100000 + (echo and ECHO_DU or 0) or nil
		o.v = (v and v >= 0) and v / 100000 + (echo and ECHO_DV or 0) or nil
		o.facing = (f and f >= 0) and f / 1000 or nil
		o.mapID, o.flags, o.seen = tonumber(mapID) or 0, tonumber(flags) or 0, GetTime()
		if form then o.form = tonumber(form) or 0 end
		if o.quests == "" and not asked[name] and not echo then
			asked[name] = true
			askedAt[name] = { t = GetTime(), n = 1 }
			Send(P_DATA, "1|R|" .. C.VERSION)
		end
	elseif prefix == P_DATA then
		local ver, kind, rev, i, n, piece = strsplit("|", msg, 6)
		if ver ~= "1" then C.unknown = C.unknown + 1; return end
		if not echo then Other(name).pm = true end
		-- "1|F|Bron|Bron Umberhide": a party member's game shows us this full name (ours only has our first)
		if kind == "F" then
			local who, full = rev, i
			if who == me and type(full) == "string" and full:find(" ") and full:sub(1, #me) == me and ns.NameLearned then
				ns.NameLearned(full:sub(1, 40))
			end
			return
		end
		if kind == "R" then
			if not echo then
				if rev and rev ~= "" then Other(name).version = rev:sub(1, 12) end
				SendData("q"); SendData("m"); SendData("k"); SendData("b"); if LegacyWanted() then LegacyAll() end
			end
			return
		end
		if kind == "s" or kind == "x" or kind == "v" or kind == "S" then return C.TheirSection(name, echo, msg) end
		if kind == "w" then return C.TheyWant(name, echo, msg) end
		if kind ~= "q" and kind ~= "m" and kind ~= "k" and kind ~= "b" then C.unknown = C.unknown + 1; return end
		rev, i, n = tonumber(rev), tonumber(i), tonumber(n)
		if not (rev and i and n) or i < 1 or i > n or n > 200 then return end
		local o = Other(name)
		-- (an older Party Map: send it whole copies too. A 0.15.0+ friend sends whole copies only for
		-- someone older, so those don't count)
		if not echo and not o.version then
			if not o.legacyAt then LegacyAll() end
			o.legacyAt = GetTime()
		end
		o.seen = o.seen or GetTime()
		local a = o.asm[kind]
		if not a or a.rev ~= rev or a.n ~= n then
			a = { rev = rev, n = n, have = 0, parts = {} }
			o.asm[kind] = a
		end
		if not a.parts[i] then
			a.parts[i] = piece or ""
			a.have = a.have + 1
		end
		if a.have == a.n then
			C.TheirText(o, name, echo, kind, table.concat(a.parts))
			o.asm[kind] = nil
		end
	end
end

-- a friend's whole quest log, markers, pins or bags, put together
function C.TheirText(o, name, echo, kind, text)
	if kind == "q" then
		o.quests = text
		local n = text:match("^N|([^|\n]*)") or text:match("\nN|([^|\n]*)")
		if n and n ~= "" then o.display = echo and (n .. " (echo)") or Fuller(o.display, n) end
	elseif kind == "k" then
		C.TheirPins(o, text, name)
	elseif kind == "b" then
		o.bags, o.bagsT = text, GetTime()   -- ("off": they've switched sharing off)
	else
		o.markers = text
	end
end

-- a section of a friend's data ("1|s|kind|key|ver|i|n|piece") or the list of them ("1|x|kind|ver|i|n|keys"):
-- each section is kept as it last came, and the whole is put back together in the list's order
local function Rebuild(o, name, echo, kind, S)
	if not S.order then return end
	local parts = {}
	for _, k in ipairs(S.order) do if S.secs[k] then parts[#parts + 1] = S.secs[k] end end
	C.TheirText(o, name, echo, kind, table.concat(parts, "\n"))
end

-- ask a friend for sections again (at most every 5 s a kind)
local function Want(o, name, kind, keys)
	local now = GetTime()
	o.wantAt = o.wantAt or {}
	if now - (o.wantAt[kind] or -1e9) < 5 then return end
	o.wantAt[kind] = now
	local list = table.concat(keys, ",")
	if #list > PIECE - 30 then list = "*" end
	queue[#queue + 1] = { msg = ("1|w|%s|%s|%s"):format(kind, name, list) }
end

function C.TheirSection(name, echo, msg)
	local o = Other(name)
	o.seen = o.seen or GetTime()
	o.sec = o.sec or {}
	local _, t, kind = strsplit("|", msg, 4)
	if kind ~= "q" and kind ~= "m" and kind ~= "k" and kind ~= "b" then return end
	local S = o.sec[kind]
	if not S then S = { secs = {}, asm = {}, vers = {} }; o.sec[kind] = S end
	S.vers = S.vers or {}
	if t == "S" then   -- several whole sections: "1|S|kind|key,ver,len;...|texts"
		local _, _, _, index, texts = strsplit("|", msg, 5)
		if not (index and texts) then return end
		local pos = 1
		for e in index:gmatch("[^;]+") do
			local key, ver, len = e:match("^([^,]+),(%d+),(%d+)$")
			len = tonumber(len)
			if not key or not len or pos + len - 1 > #texts then return end
			S.secs[key] = texts:sub(pos, pos + len - 1)
			S.vers[key] = tonumber(ver)
			pos = pos + len
		end
		return Rebuild(o, name, echo, kind, S)
	end
	local key, ver, i, n, piece
	if t == "v" then
		_, _, _, ver, i, n, piece = strsplit("|", msg, 7)
		key = "|digest"
	elseif t == "s" then
		_, _, _, key, ver, i, n, piece = strsplit("|", msg, 8)
	else
		_, _, _, ver, i, n, piece = strsplit("|", msg, 7)
		key = "|list"
	end
	ver, i, n = tonumber(ver), tonumber(i), tonumber(n)
	if not (key and ver and i and n) or i < 1 or i > n or n > 60 then return end
	local a = S.asm[key]
	if not a or a.ver ~= ver or a.n ~= n then a = { ver = ver, n = n, have = 0, parts = {} }; S.asm[key] = a end
	if not a.parts[i] then a.parts[i] = piece or ""; a.have = a.have + 1 end
	if a.have < a.n then return end
	S.asm[key] = nil
	local text = table.concat(a.parts)
	if key == "|digest" then
		-- the versions they have now: ask for whatever we're missing or have older
		if echo then return end
		if not S.order then return Want(o, name, kind, { "*" }) end
		if S.iver ~= ver then return Want(o, name, kind, { "|list" }) end
		local want, i = {}, 0
		for v in (text .. ","):gmatch("([^,]*),") do
			i = i + 1
			local k = S.order[i]
			if k and (not S.secs[k] or S.vers[k] ~= tonumber(v)) then want[#want + 1] = k end
		end
		if #want > 0 then Want(o, name, kind, want) end
		return
	end
	if key == "|list" then
		S.order = {}
		S.iver = ver
		for k in text:gmatch("[^,]+") do S.order[#S.order + 1] = k end
		-- (sections no longer listed are gone: a quest handed in, say)
		local keep = {}
		for _, k in ipairs(S.order) do keep[k] = true end
		for k in pairs(S.secs) do if not keep[k] then S.secs[k] = nil; S.vers[k] = nil end end
	else
		S.secs[key] = text
		S.vers[key] = ver
	end
	return Rebuild(o, name, echo, kind, S)
end

-- "1|w|kind|who|keys": a friend asks for sections again; only the one asked answers
function C.TheyWant(name, echo, msg)
	local _, _, kind, who, keys = strsplit("|", msg, 5)
	if who ~= me or echo or not mine[kind] then return end
	if keys == "*" then SendData(kind) return end
	for key in (keys or ""):gmatch("[^,]+") do
		if key == "|list" then Queue(kind, nil, true) elseif mine[kind].secs[key] then Queue(kind, key, kind == "q") end
	end
end

-- the game's own positions for party members (works without their addon, in the open world)
local function Secret(v) return issecretvalue and issecretvalue(v) or false end
local lastParty = 0
function C.ScanParty(now)
	if now - lastParty < 0.05 then return end
	lastParty = now
	-- everyone in the group: party1-4, or raid1-40 in a raid (skipping yourself)
	local units = {}
	if IsInRaid and IsInRaid() then
		for i = 1, math.min(GetNumGroupMembers and GetNumGroupMembers() or 0, 40) do
			local u = "raid" .. i
			if not (UnitIsUnit and UnitIsUnit(u, "player")) then units[#units + 1] = u end
		end
	else
		for i = 1, math.min(GetNumSubgroupMembers and GetNumSubgroupMembers() or 0, 4) do units[#units + 1] = "party" .. i end
	end
	for _, o in pairs(ns.Others) do o.unit = nil end
	for _, unit in ipairs(units) do
		local full = UnitName(unit)
		local name = (full and not Secret(full)) and Short(full) or nil
		if name and name ~= me then
			local o = Other(name)
			o.display = Fuller(o.display, Display(full))
			-- tell them their full name, which their own game doesn't give them (now and then)
			local d = Display(full)
			if d and d:find(" ") and (o.toldName ~= d or now - (o.toldAt or 0) > 120) then
				o.toldName, o.toldAt = d, now
				Send(P_DATA, ("1|F|%s|%s"):format(name, d), "BULK")
			end
			o.unit = unit
			local _, class = UnitClass(unit)
			o.class, o.level = class or o.class, UnitLevel(unit) or o.level
			local ok, mapID = pcall(C_Map.GetBestMapForUnit, unit)
			if ok and mapID and not Secret(mapID) then
				local okp, pos = pcall(C_Map.GetPlayerMapPosition, mapID, unit)
				if okp and pos then
					local okxy, x, y = pcall(pos.GetXY, pos)
					if okxy and x and y and not Secret(x) and not Secret(y) and (x ~= 0 or y ~= 0) and ns.ToWorld then
						local u, v = ns.ToWorld(mapID, x, y)
						if u then o.gu, o.gv, o.gSeen = u, v, now end
					end
				end
			end
		end
	end
end

-- where party members are, as OpenMap shares it ("L1 map x y class level"): a fallback position for
-- someone in the group. OpenMap also shares with Battle.net friends and the guild; those who aren't in
-- the group are left off the map (since 0.15.10).
local function InGroup(name)
	return name and UnitInParty and (UnitInParty(name) or (UnitInRaid and UnitInRaid(name))) and true or false
end
local function OnOpenMap(text, name)
	if not name or name == me or type(text) ~= "string" then return end
	if not InGroup(name) then return end
	local kind, mapID, x, y, class, level = strsplit("\t", text)
	if kind == "L1" then
		mapID, x, y = tonumber(mapID), tonumber(x), tonumber(y)
		if mapID and x and y and ns.ToWorld then
			local u, v = ns.ToWorld(mapID, x, y)
			if u then
				local o = Other(name)
				o.ou, o.ov, o.oSeen = u, v, GetTime()
				o.class, o.level = class ~= "" and class or o.class, tonumber(level) or o.level
			end
		end
	elseif kind == "L0" then
		local o = ns.Others[name]
		if o then o.oSeen = nil end
	end
end

function C.SetTest(on)
	C.test = on
	local echo = (me or "") .. " (echo)"
	if on then
		lastPosT = 0
		SendData("q"); SendData("m"); SendData("k"); SendData("b")
	else
		ns.Others[echo] = nil
	end
end

-- names in the group now; true when someone is new since last time
local roster = {}
function C.RosterGrew()
	local now, grew = {}, false
	local n = (IsInRaid and IsInRaid()) and math.min(GetNumGroupMembers and GetNumGroupMembers() or 0, 40) or math.min(GetNumSubgroupMembers and GetNumSubgroupMembers() or 0, 4)
	for i = 1, n do
		local unit = ((IsInRaid and IsInRaid()) and "raid" or "party") .. i
		local nm = Short(UnitName(unit))
		if nm and nm ~= me then
			now[nm] = true
			if not roster[nm] then grew = true end
		end
	end
	roster = now
	return grew
end

-- party members who left are dropped (and anyone else: only the group is shown)
local function Prune()
	for name in pairs(ns.Others) do
		local isEcho = C.test and name == (me or "") .. " (echo)"
		if not isEcho and not InGroup(name) then
			ns.Others[name] = nil
			asked[name] = nil
			askedAt[name] = nil
		end
	end
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:RegisterEvent("CHAT_MSG_ADDON")
f:RegisterEvent("GROUP_ROSTER_UPDATE")
f:RegisterEvent("BN_CHAT_MSG_ADDON")
f:SetScript("OnEvent", function(_, ev, ...)
	if ev == "CHAT_MSG_ADDON" then
		local prefix, msg, chan, sender = ...
		if prefix == P_POS or prefix == P_DATA then
			local ok, e = pcall(OnMessage, prefix, msg, chan, sender)
			if not ok then ns.Err("comms", e) end
		elseif prefix == "OpenMapLoc" then pcall(OnOpenMap, msg, Short(sender)) end
	elseif ev == "BN_CHAT_MSG_ADDON" then
		local prefix, msg, _, id = ...
		if prefix == "OpenMapLoc" and C_BattleNet and C_BattleNet.GetGameAccountInfoByID then
			local ok, info = pcall(C_BattleNet.GetGameAccountInfoByID, id)
			if ok and info and info.characterName then pcall(OnOpenMap, msg, Short(info.characterName)) end
		end
	elseif ev == "PLAYER_LOGIN" then
		me = Short(UnitName("player"))
		if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
			C_ChatInfo.RegisterAddonMessagePrefix(P_POS)
			C_ChatInfo.RegisterAddonMessagePrefix(P_DATA)
		elseif RegisterAddonMessagePrefix then
			RegisterAddonMessagePrefix(P_POS); RegisterAddonMessagePrefix(P_DATA)
		end
		if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then pcall(C_ChatInfo.RegisterAddonMessagePrefix, "OpenMapLoc") end
	elseif ev == "GROUP_ROSTER_UPDATE" then
		Prune()
		if GroupChannel() then
			lastPosT = 0
			-- (the game sends this for all sorts of group changes; everything goes again only when
			-- someone new is in the group)
			if C.RosterGrew() then SendData("q"); SendData("m"); SendData("k"); SendData("b") end
		end
	end
end)

function C.Best(o, now)
	local pm = o.u and o.seen and now - o.seen < 6
	-- the game's own party position is live (Party Map's messages are limited to about one a second),
	-- so it wins whenever there is one; Party Map still supplies the facing
	if o.gu and o.gSeen and now - o.gSeen < 1 then return o.gu, o.gv, pm and o.facing or nil, pm and "p" or "g", now - o.gSeen end
	if pm then return o.u, o.v, o.facing, "p", now - o.seen end
	if o.gu and o.gSeen and now - o.gSeen < 3 then return o.gu, o.gv, nil, "g", now - o.gSeen end
	if o.ou and o.oSeen and now - o.oSeen < 150 then return o.ou, o.ov, nil, "o", now - o.oSeen end
end

return C
