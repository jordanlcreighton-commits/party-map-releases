-- Bank Alt Helper: the main window and the minimap button. /bankalt (or the button) opens a window
-- listing every character: their job, bag and bank space, what their stock is worth and what's on
-- its way to them. Click a character's job to choose what they take. Buttons open "Where items go"
-- and the price window.
local _, ns = ...
local H = {}
ns.H = H

H.ROWS = 10

local function setText(fs, s) if fs and fs.SetText then fs:SetText(s or "") end end

local function countItems(t)
	local n = 0
	if type(t) == "table" then for _, c in pairs(t) do n = n + (tonumber(c) or 0) end end
	return n
end

-- One row per character: you first, then bank alts, then the rest, by name.
function H.Rows()
	local me = ns.Me()
	local rows = {}
	for name, c in pairs(ns.db.chars) do
		if type(c) == "table" then
			local b, k = c.bags or {}, c.bank or {}
			local auction, vendor, unknown = ns.S.Value(ns.S.AllItems(name))
			local items, money = ns.S.Transit(name)
			rows[#rows + 1] = {
				name = name, me = name == me, job = ns.R.Describe(name),
				bagsFree = b.free, bagsTotal = b.total, bankFree = k.free, bankTotal = k.total, bankT = k.t,
				auction = auction, vendor = vendor, unknown = unknown,
				onWay = countItems(items), onWayMoney = money, money = c.money,
			}
		end
	end
	table.sort(rows, function(a, b)
		if a.me ~= b.me then return a.me end
		local aj, bj = a.job ~= nil, b.job ~= nil
		if aj ~= bj then return aj end
		return a.name < b.name
	end)
	return rows
end

-- The words in each column for a row.
function H.Cells(r)
	local bags = r.bagsTotal and r.bagsTotal > 0 and string.format("%d/%d", r.bagsFree or 0, r.bagsTotal) or "?"
	if r.job and r.bagsTotal and r.bagsTotal > 0 and (r.bagsFree or 0) < 5 then bags = "|cffff8040" .. bags .. "|r" end
	local bank = r.bankTotal and r.bankTotal > 0 and string.format("%d/%d", r.bankFree or 0, r.bankTotal) or "not opened"
	if not r.me and not (r.bagsTotal and r.bagsTotal > 0) then bags, bank = "|cff999999log in once|r", "" end
	local worth = r.auction > 0 and ns.Money(r.auction) or "-"
	if r.unknown > 0 then worth = worth .. " |cff999999+" .. r.unknown .. " unpriced|r" end
	local way = r.onWay > 0 and (r.onWay .. " items") or ""
	if r.onWayMoney and r.onWayMoney > 0 then way = (way ~= "" and (way .. ", ") or "") .. ns.Money(r.onWayMoney) end
	local ticked = 0
	local list = ns.R.Lists()[r.name]
	if type(list) == "table" then for _ in pairs(list) do ticked = ticked + 1 end end
	local job = r.job or (r.me and "you" or (ticked > 0 and "" or "|cff999999click to set|r"))
	if ticked > 0 and not r.me then job = (r.job and (r.job .. " + ") or "") .. ticked .. " ticked" end
	return { name = r.name .. (r.me and " |cff999999(you)|r" or ""), job = job, bags = bags, bank = bank, worth = worth, way = way }
end

-- ---------------------------------------------------------------- choosing a character's job

function H.MakeJobMenu()
	if H.menu then return H.menu end
	local m = CreateFrame("Frame", "BankAltHelperJobMenu", H.frame or UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	m:SetSize(200, 40 + #ns.R.CATS * 22)
	if m.SetBackdrop then
		m:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 14,
			insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	end
	m:SetFrameStrata("FULLSCREEN_DIALOG")
	m:EnableMouse(true)
	m.title = m:CreateFontString(nil, "OVERLAY", "GameFontNormal")
	m.title:SetPoint("TOPLEFT", 10, -9)
	m.buttons = {}
	for i, cat in ipairs(ns.R.CATS) do
		local b = CreateFrame("Button", "BankAltHelperJob" .. cat, m, "UIPanelButtonTemplate")
		b:SetSize(180, 20)
		b:SetPoint("TOPLEFT", 10, -28 - (i - 1) * 22)
		b.cat = cat
		b:SetScript("OnClick", function() ns.Safe("job", H.ToggleJob, m.who, cat) end)
		m.buttons[i] = b
	end
	local close = CreateFrame("Button", nil, m, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 0, 0)
	close:SetScript("OnClick", function() m:Hide() end)
	H.menu = m
	return m
end

function H.DrawJobMenu()
	local m = H.menu
	if not m or not m.who then return end
	setText(m.title, m.who .. " takes:")
	local cats = ns.R.Alts()[m.who] or {}
	for _, b in ipairs(m.buttons) do
		local on = cats[b.cat] and true or false
		setText(b, (on and "|cff40ff40✓|r " or "") .. ns.R.LABEL[b.cat])
		b.on = on
	end
end

function H.OpenJobMenu(who)
	local m = H.MakeJobMenu()
	m.who = who
	m:ClearAllPoints()
	if H.frame then m:SetPoint("TOPLEFT", H.frame, "TOPRIGHT", 4, 0) else m:SetPoint("CENTER") end
	H.DrawJobMenu()
	m:Show()
end

-- Turns one category on or off for a character (none left = not a bank alt).
function H.ToggleJob(who, cat)
	if not who or not cat then return end
	local alts = ns.R.Alts()
	local cats = alts[who] or {}
	cats[cat] = (not cats[cat]) or nil
	alts[who] = next(cats) and cats or nil
	if not alts[who] and ns.db.settings.bankAlt == who then ns.db.settings.bankAlt = nil end
	H.DrawJobMenu()
	H.Draw()
	if ns.atMail and ns.M then ns.M.Refresh() end
end

-- ---------------------------------------------------------------- the window

local COLS = { { "name", 0, 110 }, { "job", 112, 150 }, { "bags", 266, 56 }, { "bank", 324, 70 }, { "worth", 396, 80 }, { "way", 478, 90 } }
local HEAD = { name = "Character", job = "Takes", bags = "Bags free", bank = "Bank free", worth = "To auction", way = "On its way" }

function H.MakeWindow()
	if H.frame then return H.frame end
	local f = CreateFrame("Frame", "BankAltHelperHome", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	f:Hide() -- new frames start shown; this one waits to be opened
	f:SetSize(600, 146 + H.ROWS * 24)
	f:SetPoint("CENTER", 0, 60)
	if f.SetBackdrop then
		f:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark",
			edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border", tile = true, tileSize = 16, edgeSize = 14,
			insets = { left = 3, right = 3, top = 3, bottom = 3 } })
	end
	f:SetFrameStrata("DIALOG")
	f:EnableMouse(true)
	f:SetMovable(true)
	f:RegisterForDrag("LeftButton")
	f:SetScript("OnDragStart", f.StartMoving)
	f:SetScript("OnDragStop", f.StopMovingOrSizing)
	f:SetScript("OnHide", function() if H.menu then H.menu:Hide() end end)
	if UISpecialFrames then table.insert(UISpecialFrames, "BankAltHelperHome") end

	f.title = f:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
	f.title:SetPoint("TOPLEFT", 14, -12)
	f.title:SetText("Bank Alt Helper")
	f.version = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.version:SetPoint("LEFT", f.title, "RIGHT", 8, 0)
	f.version:SetText(ns.VERSION)
	f.tip = f:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
	f.tip:SetPoint("TOPLEFT", 14, -36); f.tip:SetWidth(570); f.tip:SetJustifyH("LEFT")

	f.head = {}
	for _, c in ipairs(COLS) do
		local h = f:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
		h:SetPoint("TOPLEFT", 16 + c[2], -72)
		h:SetWidth(c[3]); h:SetJustifyH("LEFT")
		h:SetText(HEAD[c[1]])
		f.head[c[1]] = h
	end
	f.rows = {}
	for i = 1, H.ROWS do
		local r = CreateFrame("Frame", nil, f)
		r:SetSize(570, 22)
		r:SetPoint("TOPLEFT", 14, -88 - (i - 1) * 24)
		r.cells = {}
		for _, c in ipairs(COLS) do
			if c[1] ~= "job" then
				local t = r:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
				t:SetPoint("LEFT", 2 + c[2], 0)
				t:SetWidth(c[3]); t:SetJustifyH("LEFT")
				r.cells[c[1]] = t
			end
		end
		local job = CreateFrame("Button", "BankAltHelperHomeJob" .. i, r, "UIPanelButtonTemplate")
		job:SetSize(150, 20); job:SetPoint("LEFT", 2 + COLS[2][2], 0)
		job:SetScript("OnClick", function() if r.who then ns.Safe("job menu", H.OpenJobMenu, r.who) end end)
		r.job = job
		f.rows[i] = r
	end

	local where = CreateFrame("Button", "BankAltHelperHomeWhere", f, "UIPanelButtonTemplate")
	where:SetSize(140, 24); where:SetPoint("BOTTOMLEFT", 14, 12)
	where:SetText("Send lists")
	where:SetScript("OnClick", function() ns.Safe("rules", ns.W.Open) end)
	local prices = CreateFrame("Button", "BankAltHelperHomePrices", f, "UIPanelButtonTemplate")
	prices:SetSize(100, 24); prices:SetPoint("LEFT", where, "RIGHT", 6, 0)
	prices:SetText("Prices")
	prices:SetScript("OnClick", function() ns.Safe("prices", ns.G.Open) end)
	local add = CreateFrame("EditBox", "BankAltHelperHomeAdd", f, "InputBoxTemplate")
	add:SetSize(130, 20); add:SetPoint("LEFT", prices, "RIGHT", 14, 0)
	add:SetAutoFocus(false)
	add:SetScript("OnEnterPressed", function(self)
		ns.Safe("add", function()
			local n = ns.NormName(self:GetText())
			if n then ns.L.AddChar(n); H.Draw() end
			self:SetText("")
			self:ClearFocus()
		end)
	end)
	add:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
	f.add = add
	local addBtn = CreateFrame("Button", "BankAltHelperHomeAddButton", f, "UIPanelButtonTemplate")
	addBtn:SetSize(100, 22); addBtn:SetPoint("LEFT", add, "RIGHT", 4, 0)
	addBtn:SetText("Add character")
	addBtn:SetScript("OnClick", function() add:GetScript("OnEnterPressed")(add) end)
	local help = CreateFrame("Button", "BankAltHelperHomeHelp", f, "UIPanelButtonTemplate")
	help:SetSize(80, 24); help:SetPoint("BOTTOMRIGHT", -14, 12)
	help:SetText("Commands")
	help:SetScript("OnClick", function() ns.Safe("help", ns.L.Command, "help") end)
	f.foot = f:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
	f.foot:SetPoint("TOPRIGHT", -30, -16)

	local close = CreateFrame("Button", nil, f, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", 0, 0)
	close:SetScript("OnClick", function() f:Hide() end)
	H.frame = f
	return f
end

function H.Draw()
	local f = H.frame
	if not f or not f:IsShown() then return end
	local rows = H.Rows()
	local alts = 0
	for _, r in ipairs(rows) do if r.job then alts = alts + 1 end end
	if next(ns.R.Lists()) then alts = alts + 1 end
	if alts == 0 then
		setText(f.tip, "|cffffd100Start here:|r press Send lists, pick a character and tick the items that go to them. "
			.. "(Or give a character a whole category with its \"Takes\" button.)")
	else
		setText(f.tip, "At a mailbox, items are lined up for the right alt. At the auction house, a panel posts 1 copper under the lowest.")
	end
	local unpriced = 0
	for _, r in ipairs(rows) do unpriced = unpriced + r.unknown end
	if unpriced > 0 then
		setText(f.tip, (f.tip.GetText and f.tip:GetText() or "") .. "\n|cffffd100" .. unpriced
			.. " kinds of item have no auction price yet:|r open the auction house once on any character.")
	end
	for i = 1, H.ROWS do
		local r, row = f.rows[i], rows[i]
		if row then
			local c = H.Cells(row)
			r.who = row.name
			for k, t in pairs(r.cells) do setText(t, c[k]) end
			setText(r.job, c.job)
			r:Show()
		else
			r.who = nil
			r:Hide()
		end
	end
	local total = 0
	for _, row in ipairs(rows) do total = total + row.auction end
	local gold, sold = ns.SL.Today()
	setText(f.foot, #rows .. " character" .. (#rows == 1 and "" or "s")
		.. (total > 0 and (" · about " .. ns.Money(total) .. " to auction") or "")
		.. (sold > 0 and (" · sold today " .. ns.Money(gold)) or "")
		.. (#rows > H.ROWS and (" · showing " .. H.ROWS) or ""))
	H.shown = rows
end

function H.Open()
	local f = H.MakeWindow()
	ns.S.ScanBags()
	f:Show()
	H.Draw()
end

function H.Toggle()
	local f = H.MakeWindow()
	if f:IsShown() then f:Hide() else H.Open() end
end

-- Keeps the window up to date while it's open.
ns.On("BAG_UPDATE_DELAYED", function() H.Draw() end)
ns.On("MAIL_SEND_SUCCESS", function() ns.After(0.6, H.Draw) end)
ns.On("BANKFRAME_OPENED", function() ns.After(0.2, H.Draw) end)

-- ---------------------------------------------------------------- the minimap button

-- How far from the minimap's centre the button sits: just outside its edge, on the ring with the
-- other addons' buttons (the way LibDBIcon places them), whatever size the minimap is.
function H.Radius()
	local w = Minimap and Minimap.GetWidth and Minimap:GetWidth()
	if type(w) ~= "number" or w <= 0 then w = 140 end
	return w / 2 + 5
end

function H.PlaceButton()
	local b = H.button
	if not b then return end
	local a = math.rad(ns.db.settings.minimapAngle or 200)
	local r = H.Radius()
	b:ClearAllPoints()
	b:SetPoint("CENTER", Minimap, "CENTER", math.cos(a) * r, math.sin(a) * r)
	H.placed = { x = math.cos(a) * r, y = math.sin(a) * r }
end

-- Where the cursor is around the minimap, as an angle in degrees.
function H.AngleFrom(mx, my, cx, cy)
	local deg = math.deg(math.atan2(my - cy, mx - cx))
	if deg < 0 then deg = deg + 360 end
	return deg
end

function H.MakeButton()
	if H.button or not Minimap then return H.button end
	local b = CreateFrame("Button", "BankAltHelperMinimapButton", Minimap)
	b:SetSize(31, 31)
	b:SetFrameStrata("MEDIUM")
	b:SetFrameLevel(8)
	if b.RegisterForClicks then b:RegisterForClicks("LeftButtonUp", "RightButtonUp") end
	if b.RegisterForDrag then b:RegisterForDrag("LeftButton") end
	b.icon = b:CreateTexture(nil, "BACKGROUND")
	b.icon:SetSize(20, 20); b.icon:SetPoint("CENTER", 0, 1)
	b.icon:SetTexture("Interface\\Icons\\INV_Misc_Coin_01")
	b.border = b:CreateTexture(nil, "OVERLAY")
	b.border:SetSize(53, 53); b.border:SetPoint("TOPLEFT")
	b.border:SetTexture("Interface\\Minimap\\MiniMap-TrackingBorder")
	if b.SetHighlightTexture then b:SetHighlightTexture("Interface\\Minimap\\UI-Minimap-ZoomButton-Highlight") end
	b:SetScript("OnClick", function(_, button)
		ns.Safe("minimap", function()
			if button == "RightButton" then ns.W.Open() else H.Toggle() end
		end)
	end)
	b:SetScript("OnDragStart", function(self)
		self:SetScript("OnUpdate", function()
			local mx, my = GetCursorPosition()
			local scale = Minimap:GetEffectiveScale()
			local cx, cy = Minimap:GetCenter()
			ns.db.settings.minimapAngle = H.AngleFrom(mx / scale, my / scale, cx, cy)
			H.PlaceButton()
		end)
	end)
	b:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
	b:SetScript("OnEnter", function(self)
		if not GameTooltip then return end
		GameTooltip:SetOwner(self, "ANCHOR_LEFT")
		GameTooltip:AddLine("Bank Alt Helper")
		GameTooltip:AddLine("Click: your characters and alts", 1, 1, 1)
		GameTooltip:AddLine("Right-click: send lists", 1, 1, 1)
		GameTooltip:AddLine("Drag: move this button", 0.7, 0.7, 0.7)
		GameTooltip:Show()
	end)
	b:SetScript("OnLeave", function() if GameTooltip then GameTooltip:Hide() end end)
	H.button = b
	H.PlaceButton()
	if Minimap.HookScript then Minimap:HookScript("OnSizeChanged", function() ns.Safe("minimap", H.PlaceButton) end) end
	if ns.db.settings.minimap == false then b:Hide() else b:Show() end
	return b
end

table.insert(ns.OnLoad, function()
	H.MakeButton()
	ns.Print(ns.VERSION .. " loaded: type /bankalt or click the coin on the minimap.")
end)
