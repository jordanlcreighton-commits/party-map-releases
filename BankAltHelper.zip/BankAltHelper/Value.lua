-- Bank Alt Helper: the sums. Vendor or auction, the undercut price, the floor.
-- Everything here is plain arithmetic on numbers, so it is tested on its own.
local _, ns = ...
local C = ns.C
local V = {}
ns.V = V

-- The auction house's cut where you are: 5% at a faction house, 15% at a neutral one.
function V.Cut()
	local sub = (GetSubZoneText and GetSubZoneText()) or ""
	local zone = (GetZoneText and GetZoneText()) or ""
	if C.NEUTRAL_PLACES[sub] or C.NEUTRAL_PLACES[zone] then return C.CUT_NEUTRAL, true end
	return C.CUT_FACTION, false
end

-- What a listing of qty is worth to you, in copper:
--   p * (1 - cut) * price * qty  -  (1 - p) * deposit
-- price is per unit; deposit is for the whole listing; p is the chance it sells (0..1).
function V.Worth(price, qty, deposit, cut, p)
	price, qty, deposit = tonumber(price) or 0, tonumber(qty) or 1, tonumber(deposit) or 0
	cut, p = tonumber(cut) or C.CUT_FACTION, tonumber(p) or 1
	if p < 0 then p = 0 elseif p > 1 then p = 1 end
	return p * (1 - cut) * price * qty - (1 - p) * deposit
end

-- The lowest unit price at which auctioning beats the vendor (or your own minimum, if higher).
--   p * (1 - cut) * floor * qty - (1 - p) * deposit >= vendor * qty
function V.Floor(vendor, qty, deposit, cut, p, userMin)
	vendor, qty, deposit = tonumber(vendor) or 0, math.max(1, tonumber(qty) or 1), tonumber(deposit) or 0
	cut, p = tonumber(cut) or C.CUT_FACTION, tonumber(p) or 1
	if p <= 0 then return math.huge end
	local f = (vendor * qty + (1 - p) * deposit) / (p * (1 - cut) * qty)
	f = math.ceil(f)
	if vendor <= 0 and deposit <= 0 then f = 1 end
	if f < 1 then f = 1 end
	if userMin and userMin > f then f = userMin end
	return f
end

-- The price to post at.
--   lowest: the lowest unit price listed now (nil if none listed)
--   mine:   true when that lowest listing is yours (your own or your account's): match it, never undercut yourself
--   step:   1 copper, or 100 if the house only takes whole silver for this kind of listing
-- Returns price, why. price is nil when there's nothing to go on.
function V.PostPrice(lowest, mine, step, fallback)
	step = step or 1
	if not lowest then
		if fallback and fallback > 0 then return fallback, "no one else is selling it: the last price seen" end
		return nil, "no one is selling it and there's no price to go on"
	end
	if mine then return lowest, "the lowest is already yours: matching it" end
	local p = lowest - step
	if step > 1 then p = math.floor(p / step) * step end
	if p < 1 then p = 1 end
	return p, "1 copper under the lowest"
end

-- The verdict for one item.
-- t = { vendor = sell price per unit, qty, lowest, mine, deposit (for qty, at the chosen length),
--       cut, p, userMin, step, fallback, keep }
-- Returns a table: action = "auction" | "vendor" | "keep" | "unknown",
--   price (per unit, auction only), net (what you'd pocket for qty), vendorTotal, why.
function V.Verdict(t)
	local qty = math.max(1, tonumber(t.qty) or 1)
	local vendor = tonumber(t.vendor) or 0
	local vendorTotal = vendor * qty
	local r = { qty = qty, vendorTotal = vendorTotal }
	if t.keep then
		r.action, r.why = "keep", "on your keep list"
		return r
	end
	local price, why = V.PostPrice(t.lowest, t.mine, t.step, t.fallback)
	if not price and t.userMin then price, why = t.userMin, "none listed: your minimum price" end
	if not price then
		-- No auction price to go on is never "vendor it": it means "look it up first".
		r.action = "unknown"
		r.why = t.seen and "none listed on the auction house, and no past price: set one with /bankalt floor"
			or "no auction price seen yet: open the auction house on any character"
		return r
	end
	local cut, p = t.cut or C.CUT_FACTION, t.p or 1
	local deposit = tonumber(t.deposit) or 0
	local vendorFloor = V.Floor(vendor, qty, deposit, cut, p)
	local floor = V.Floor(vendor, qty, deposit, cut, p, t.userMin)
	local net = V.Worth(price, qty, deposit, cut, p)
	r.price, r.net, r.floor = price, net, floor
	if price < vendorFloor then
		r.action = vendor > 0 and "vendor" or "keep"
		r.why = "after the cut and deposit it's worth " .. ns.Money(math.floor(net)) .. ", a vendor pays " .. ns.Money(vendorTotal)
		return r
	end
	if price < floor then
		r.action, r.why = "keep", "below your minimum of " .. ns.Money(t.userMin) .. ": holding it"
		return r
	end
	r.action, r.why = "auction", why
	return r
end

-- The deposit for an item at a listing length. Asks the game at the auction house; away from it,
-- uses the last deposit the game gave for that item, or the minimum.
function V.Deposit(id, qty, duration, location, commodity)
	qty, duration = qty or 1, duration or ns.db.settings.duration
	local AH = C_AuctionHouse
	local dep
	if AH and ns.atAH then
		local ok, v
		if commodity and AH.CalculateCommodityDeposit then
			ok, v = pcall(AH.CalculateCommodityDeposit, id, duration, qty)
		elseif location and AH.CalculateItemDeposit then
			ok, v = pcall(AH.CalculateItemDeposit, location, duration, qty)
		end
		if ok and type(v) == "number" then dep = v end
	end
	local book = ns.db.deposits
	local key = id .. ":" .. duration
	if dep then
		book[key] = { per = dep / qty, t = ns.Now() }
		return dep, true
	end
	local seen = book[key]
	if type(seen) == "table" and type(seen.per) == "number" then
		return math.max(ns.db.settings.minDeposit, math.ceil(seen.per * qty)), false
	end
	return ns.db.settings.minDeposit, false
end

-- Everything we know about one item's price on this faction's house.
function V.PriceOf(id)
	local e = ns.Prices()[id]
	if type(e) ~= "table" then return nil end
	return e
end

-- The verdict for an item and quantity, from what's saved (used by tooltips and lists).
function V.ForItem(id, qty)
	local _, _, _, _, _, sell = ns.ItemInfo(id)
	local e = V.PriceOf(id)
	local cut = V.Cut()
	local dep = V.Deposit(id, qty, nil, nil, e and e.commodity)
	return V.Verdict({
		vendor = sell or 0, qty = qty, lowest = e and e.min, mine = e and e.mine,
		deposit = dep, cut = cut, p = 1, userMin = ns.db.floor[id],
		step = (e and not e.commodity) and ns.db.settings.itemStep or 1,
		fallback = e and e.last, keep = ns.db.keep[id], seen = e ~= nil,
	})
end
