Bank Alt Helper 0.6.3
=====================

Install: put the BankAltHelper folder in
  ...\World of Warcraft\_retail_\_forever_\Interface\AddOns\
then restart WoW (a new addon needs a full restart, not just /reload).

Log in once on every character you want it to know about, including your bank alt.

Where to start
--------------
Type /bankalt, or click the gold coin on the minimap. The main window lists
every character it has seen, with their job, bag and bank space, what their
stock is worth and what's on its way to them. Click a character's "Takes"
button to give them a job (herbs, gear, reagents...). In chat you'll see
"Bank Alt Helper 0.6.3 loaded" when you log in.

What it does
------------
* Remembers every character's bags, bank (each time you open it) and mailbox,
  account-wide. Mail you send to another of your characters is counted as
  "on its way" until they open their mailbox.
* At the auction house it quietly looks up the prices of what you hold.
* Each item gets a verdict: auction it, vendor it, or keep. "Vendor it" means
  that after the 5% cut and the deposit you'd get less than a vendor pays.
* The panel beside the auction house goes through your bags. Press Start, then
  one press per item posts it 1 copper under the lowest price. If the lowest
  listing is already yours, it matches it instead. Items better vendored are
  skipped by themselves.
* An alt for each category: tell it which alt takes what, and the mail helper
  at any mailbox lines up a mail for each alt with just their items. One press
  attaches (up to 12 stacks), another sends. Items a real auction price says
  are better vendored aren't mailed, so you don't pay postage on them.
* Or put items in a mail yourself: if they all belong on one alt, its name fills
  itself in, so the game's own Send button sends them there. A name you type is
  never replaced; a mail mixing two alts' items is left blank.
* Put one stack of something in a mail (right-click it or drag it) and every
  other stack of it from your bags goes in too, up to the mail's 12 slots.
* Send lists (/bankalt lists): pick a character, tick the items that go to
  them (see below).
* Prices (/bankalt prices Peacebloom, or the Prices button at the auction
  house): a graph of the lowest price over time, with how many were listed and
  the vendor price, plus the week's low, high and average and the verdict.
  It uses prices your characters have seen: what you hold, and anything you
  search for at the auction house yourself. It fills up as you play.

Send lists: telling it what goes where
--------------------------------------
Press "Send lists" (main window, mail panel, or right-click the minimap coin).
1. Pick a character on the left. Your characters appear once you've logged in
   on each (it reads full names like "Bron Herbs" off the portrait), or type a
   name bottom left and press Add.
2. Tick the items that go to them. Ticks are saved. "Tick everything that's:"
   buttons tick every herb, cloth, leather... in your bags at once.
3. At a mailbox, open Send lists and click a character: everything ticked for
   them goes into the mail with their name, ready to press Send. If it's more
   than one mail holds, the rest waits: press Attach (or click them again) for
   the next mail. Or drop items in yourself: the name fills itself in.
An item ticked for two characters asks "Send it to:" before it goes in a mail
(tick "Always" to settle it for good). Item tooltips say "Sends to: ...".

Optional: give a character a whole category with its "Takes" button in the
main window (herbs, gear, reagents...). Ticks always win over categories.
If it ever can't read a character's full name it says so; then type
/bankalt iam "Bron Herbs" once on that character.

Updates
-------
If Party Map's app runs on this PC, it keeps Bank Alt Helper up to date by
itself: new versions are put in the background and arrive at your next
/reload (a version that adds a file needs a full restart). Without Party Map,
replace this folder with the new one.

Sales on your other characters
------------------------------
WoW only tells a character about its own auctions, by mail. Whenever a
character opens its mailbox, its "Auction successful" and "expired" mails are
noted. Logging in on another character shows what sold since you were last
there; /bankalt sales lists the latest.

Commands (/bankalt or /bah)
---------------------------
/bankalt                 the main window (the minimap coin does the same)
/bankalt stock           the same, printed in chat
/bankalt minimap on|off  the minimap button
/bankalt coins on|off    prices with coin pictures (on) or g s c letters
/bankalt stacks on|off   one stack in a mail brings the rest of that item
/bankalt list [name]     a character's items, best first, with the verdict
/bankalt alt <name> <categories>   what a bank alt takes (off to clear)
/bankalt alts            every bank alt, what it takes and its free space
/bankalt send <item> <name>       send one item to a particular alt (auto to undo)
/bankalt add <name> / remove <name>  add an alt before logging in on it / remove one
/bankalt iam <full name> only if it can't read this character's full name
/bankalt stay <item>     never mail it away (unstay to undo)
/bankalt find <item>     how many of it every character has
/bankalt autoname on|off fill in the alt's name when you put items in a mail
/bankalt lists           send lists: pick a character, tick its items
/bankalt sales           what sold or came back, on every character
/bankalt prices [item]   the price graph for an item
/bankalt keep <item>     never sell it (unkeep to undo; keep alone lists them)
/bankalt floor <item> <price>   never post below this, e.g. 1g20s (off to clear)
/bankalt length 12|24|48 how long auctions last (24 by default)
/bankalt neutral on|off  allow posting at Gadgetzan, Booty Bay, Everlook (15% cut)
/bankalt tooltip on|off  the price line on item tooltips
/bankalt scan            look every price up again (at the auction house)
/bankalt skipped         why items were skipped this visit

Posting from a key: make a macro containing
  /click BankAltHelperPostButton LeftButton
and put it on a key.

To try in game first
--------------------
* Posting from the button (WoW Forever's auction house works like retail's).
* Whether gear takes copper prices; if not, it switches to 1 silver under by
  itself and says so in chat.
* The deposit it shows against what the game actually takes.
* Items land in the right category (it uses the game's own item types).
* Attaching from the mail helper.
* Mail to a full name ("Bron Herbs") goes through from the To box it fills in.
