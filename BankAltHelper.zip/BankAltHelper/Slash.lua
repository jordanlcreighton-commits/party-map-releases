-- Bank Alt Helper: /bankalt (or /bah) and the line on item tooltips.
local _, ns = ...
local C = ns.C
local L = {}
ns.L = L

local function out(s) ns.Print(s) end

local function ago(t)
	if type(t) ~= "number" or t <= 0 then return "never" end
	local d = ns.Now() - t
	if d < 90 then return "just now" end
	if d < 5400 then return math.floor(d / 60 + 0.5) .. " min ago" end
	if d < 172800 then return math.floor(d / 3600 + 0.5) .. " h ago" end
	return math.floor(d / 86400 + 0.5) .. " days ago"
end
L.Ago = ago

local function countItems(t)
	local n = 0
	if type(t) == "table" then for _, c in pairs(t) do n = n + (tonumber(c) or 0) end end
	return n
end

-- One line per character: space, stock value and what's on its way.
function L.Summary()
	local names = {}
	for name in pairs(ns.db.chars) do names[#names + 1] = name end
	table.sort(names)
	if #names == 0 then out("nothing seen yet: open your bags or bank on each character.") return end
	local anyUnknown = false
	for _, name in ipairs(names) do
		local c = ns.db.chars[name]
		local parts = {}
		local b = c.bags or {}
		if b.total and b.total > 0 then parts[#parts + 1] = string.format("bags %d/%d free", b.free or 0, b.total) end
		local k = c.bank or {}
		if k.total and k.total > 0 then
			parts[#parts + 1] = string.format("bank %d/%d free (%s)", k.free or 0, k.total, ago(k.t))
		end
		local auction, vendor, unknown = ns.S.Value(ns.S.AllItems(name))
		if auction > 0 then parts[#parts + 1] = "to auction about " .. ns.Money(auction) end
		if vendor > 0 then parts[#parts + 1] = "to vendor " .. ns.Money(vendor) end
		if unknown > 0 then parts[#parts + 1] = unknown .. " kinds without an auction price yet" end
		local items, money = ns.S.Transit(name)
		local n = countItems(items)
		if n > 0 or money > 0 then
			parts[#parts + 1] = "on its way: " .. n .. " items" .. (money > 0 and (" and " .. ns.Money(money)) or "")
		end
		local role = ns.R.Describe(name)
		local label = name .. (role and (" (" .. role .. ")") or "") .. (name == ns.Me() and " (you)" or "")
		local warn = ""
		if role and b.total and b.total > 0 and (b.free or 0) < 5 then
			warn = " |cffff8040nearly full: " .. (b.free or 0) .. " bag slots left|r"
		end
		out("|cffffffff" .. label .. "|r: " .. (#parts > 0 and table.concat(parts, " · ") or "nothing yet") .. warn)
		anyUnknown = anyUnknown or unknown > 0
	end
	if anyUnknown then out("Open the auction house once on any character and it looks up prices for everything above.") end
end

-- Adds a character you haven't logged in on yet (it shows in the window, and mail can go to it).
function L.AddChar(name)
	if type(name) ~= "string" or name == "" then return end
	if not ns.db.chars[name] then ns.Char(name).added = true end
end

-- A character's items, best first, with what to do with each.
function L.List(name, limit)
	name = ns.S.ShortName(name) or ns.Me()
	if not ns.db.chars[name] then out("I haven't seen " .. name .. " yet: log in on them once.") return end
	local rows = {}
	for id, n in pairs(ns.S.AllItems(name)) do
		local v = ns.V.ForItem(id, n)
		local worth = (v.action == "vendor") and v.vendorTotal or math.floor(v.net or 0)
		rows[#rows + 1] = { id = id, n = n, v = v, worth = worth }
	end
	table.sort(rows, function(a, b) if a.worth ~= b.worth then return a.worth > b.worth end return a.id < b.id end)
	out(name .. ": " .. #rows .. " kinds of item.")
	for i = 1, math.min(limit or 15, #rows) do
		local r = rows[i]
		local what
		if r.v.action == "auction" then what = "auction at " .. ns.Money(r.v.price) .. " each, about " .. ns.Money(r.worth)
		elseif r.v.action == "vendor" then what = "vendor it, " .. ns.Money(r.worth)
		elseif r.v.action == "keep" then what = "keep (" .. (r.v.why or "") .. ")"
		else what = "no price yet" end
		out(string.format("  %s × %d: %s", ns.ItemName(r.id), r.n, what))
	end
end

local HELP = {
	"/bankalt — opens the main window: every character, their job, space and stock value",
	"/bankalt stock — the same, printed in chat",
	"/bankalt minimap on | off — the minimap button",
	"/bankalt coins on | off — prices with coin pictures (on) or g s c letters (off)",
	"/bankalt stacks on | off — put one stack in a mail and the rest of that item goes in too",
	"/bankalt list [name] — a character's items, best first, auction it or vendor it",
	"/bankalt alt <name> <categories> — what a bank alt takes, e.g. /bankalt alt \"Bron Herbs\" herbs",
	"   categories: herbs, leather, cloth, ore, cooking, enchanting, elemental, reagents, gear,",
	"   consumables, recipes, bags, everything (reagents = any crafting material no other alt takes)",
	"/bankalt alt <name> off — that character isn't a bank alt any more",
	"/bankalt alts — every bank alt and what it takes",
	"/bankalt send <item> <name> | send <item> auto — send this item to a particular alt",
	"/bankalt add <name> | remove <name> — add a character before logging in on them, or remove one",
	"/bankalt iam <full name> — only if it can't read this character's full name by itself",
	"   (names can go in quotes: \"Bron Herbs\"; a first name works when only one character has it)",
	"/bankalt stay <item> | unstay <item> — never mail this item away",
	"/bankalt find <item> — how many of it every character has",
	"/bankalt sales — what sold (or came back) on each character, seen when it opened its mailbox",
	"/bankalt prices [item] — the price window: a graph of what it's sold for, low, high, average",
	"/bankalt lists — send lists: pick a character, tick the items that go to them",
	"/bankalt autoname on | off — fill in the alt's name when you put items in a mail",
	"/bankalt bankalt <name> | off — one bank alt for everything (same as: alt <name> everything)",
	"/bankalt keep <item> | unkeep <item> | keep — never sell these",
	"/bankalt floor <item> <price> | floor <item> off — never post below this (e.g. 1g20s)",
	"/bankalt length 12 | 24 | 48 — how long auctions last",
	"/bankalt neutral on | off — allow posting at Gadgetzan, Booty Bay and Everlook (15% cut)",
	"/bankalt tooltip on | off — the price line on item tooltips",
	"/bankalt scan — look up every price again (at the auction house)",
	"/bankalt skipped — why items were skipped this visit",
	"Key bind for posting: make a macro with  /click BankAltHelperPostButton LeftButton",
}

local function onOff(word)
	if word == "on" then return true elseif word == "off" then return false end
	return nil
end

function L.Command(msg)
	msg = type(msg) == "string" and msg or ""
	local cmd, rest = msg:match("^%s*(%S*)%s*(.-)%s*$")
	cmd = (cmd or ""):lower()
	local s = ns.db.settings
	if cmd == "" or cmd == "show" or cmd == "window" then
		ns.H.Toggle()
	elseif cmd == "stock" or cmd == "summary" then
		L.Summary()
	elseif cmd == "list" or cmd == "value" then
		L.List(rest ~= "" and rest or nil)
	elseif cmd == "bankalt" then
		if rest == "" then out("bank alt: " .. (s.bankAlt or "not set"))
		elseif rest:lower() == "off" then s.bankAlt = nil; out("bank alt cleared.")
		else s.bankAlt = ns.Resolve(rest); L.AddChar(s.bankAlt); out("bank alt is now " .. s.bankAlt .. ".") end
	elseif cmd == "alt" then
		local name, rest2, many = ns.SplitName(rest)
		local _, hits = ns.Resolve(name)
		if hits then out("which one? " .. table.concat(hits, ", ") .. ". Use the full name, e.g. /bankalt alt \"" .. hits[1] .. "\" herbs") return end
		if not name then out("which character? /bankalt alt \"Bron Herbs\" herbs") return end
		local alts = ns.R.Alts()
		if rest2:lower() == "off" then
			alts[name] = nil
			if s.bankAlt == name then s.bankAlt = nil end
			out(name .. " isn't a bank alt any more.")
			return
		end
		local cats, bad = {}, {}
		for word in rest2:gmatch("[^,%s]+") do
			local c = ns.R.CatName(word)
			if c then cats[c] = true else bad[#bad + 1] = word end
		end
		if #bad > 0 then out("I don't know " .. table.concat(bad, ", ") .. ". " .. HELP[3]:gsub("^%s+", "")) return end
		if not next(cats) then
			local d = ns.R.Describe(name)
			out(name .. (d and (" takes " .. d .. ".") or " isn't a bank alt.") )
			return
		end
		alts[name] = cats
		L.AddChar(name)
		out(name .. " now takes " .. ns.R.Describe(name) .. "."
			.. ((ns.db.chars[name] and ns.db.chars[name].bags.total) and "" or " (log in on them once so I can see their bags)"))
	elseif cmd == "alts" then
		local names = {}
		for name in pairs(ns.R.Alts()) do names[#names + 1] = name end
		if s.bankAlt and not ns.R.Alts()[s.bankAlt] then names[#names + 1] = s.bankAlt end
		table.sort(names)
		if #names == 0 then out("no bank alts yet: /bankalt alt <name> herbs") return end
		for _, name in ipairs(names) do
			local c = ns.db.chars[name]
			local free = c and c.bags and c.bags.total and c.bags.total > 0 and (" · " .. (c.bags.free or 0) .. " bag slots free") or " · not seen yet: log in on them once"
			out("  " .. name .. ": " .. (ns.R.Describe(name) or "") .. free)
		end
	elseif cmd == "send" then
		-- the item first (a shift-clicked link or its number), then the character's name
		local id, who = ns.ItemID(rest), nil
		local afterLink = rest:match("|h|r%s*(.-)$") or rest:match("%]%s*(.-)$")
		if afterLink and rest:find("|H") then who = afterLink
		else
			local num, tail = rest:match("^%s*(%d+)%s+(.-)$")
			if num then id, who = tonumber(num), tail end
		end
		if not id or not who or who == "" then out("/bankalt send <item> \"Bron Herbs\", or <item> auto") return end
		if who:lower() == "auto" then
			for name in pairs(ns.R.Lists()) do ns.R.SetListed(name, id, false) end
			out(ns.ItemName(id) .. " is off every send list: it goes where its category says.")
		else
			local key, hits = ns.Resolve(who)
			if hits then out("which one? " .. table.concat(hits, ", ")) return end
			ns.R.SetListed(key, id, true)
			s.stay[id] = nil
			L.AddChar(key)
			out(ns.ItemName(id) .. " is ticked for " .. key .. ".")
		end
	elseif cmd == "iam" then
		local n = ns.NormName(rest)
		local first = UnitName and UnitName("player")
		if not n then out("this character is " .. ns.Me() .. ". To change it: /bankalt iam \"" .. (first or "Name") .. " Surname\"") return end
		if first and n:match("^(%S+)") ~= first then out("that doesn't start with " .. first .. ": type this character's own full name.") return end
		ns.SetMyName(n, true)
		ns.S.ScanBags()
		out("this character is " .. n .. ".")
		if ns.H then ns.H.Draw() end
	elseif cmd == "add" then
		local n = ns.NormName(rest)
		if not n then out("/bankalt add \"Bron Herbs\" — adds a character before you've logged in on them") return end
		L.AddChar(n)
		out(n .. " added: give them a job in /bankalt.")
		if ns.H then ns.H.Draw() end
	elseif cmd == "remove" then
		local n = ns.Resolve(rest)
		if not n or not ns.db.chars[n] then out("I don't have a character called " .. tostring(rest) .. ".") return end
		if n == ns.Me() then out("that's the character you're on.") return end
		ns.db.chars[n], ns.db.transit[n], s.alts[n] = nil, nil, nil
		for iid, who in pairs(s.send) do if who == n then s.send[iid] = nil end end
		ns.R.Lists()[n] = nil
		out(n .. " removed.")
		if ns.H then ns.H.Draw() end
	elseif cmd == "stay" or cmd == "unstay" then
		local id = ns.ItemID(rest)
		if not id then out("which item? Shift-click it into the chat line, or give its number.") return end
		s.stay[id] = (cmd == "stay") or nil
		out(ns.ItemName(id) .. (cmd == "stay" and " won't be mailed away." or " can be mailed again."))
	elseif cmd == "find" then
		local id = ns.ItemID(rest)
		if not id and rest ~= "" then
			local want = rest:lower()
			for name in pairs(ns.db.chars) do
				for iid in pairs(ns.S.AllItems(name)) do
					local n = ns.ItemInfo(iid)
					if n and n:lower() == want then id = iid break end
				end
				if id then break end
			end
		end
		if not id then out("which item? Shift-click it, give its number, or its exact name.") return end
		local rows = ns.R.Find(id)
		if #rows == 0 then out("no " .. ns.ItemName(id) .. " on any character I've seen.") return end
		local total, parts = 0, {}
		for _, r in ipairs(rows) do total = total + r.n; parts[#parts + 1] = r.name .. " " .. r.n end
		local home = ns.R.Home(id)
		out(ns.ItemName(id) .. ": " .. total .. " (" .. table.concat(parts, ", ") .. ")" .. (home and (" · belongs on " .. home) or ""))
	elseif cmd == "keep" or cmd == "unkeep" then
		local id = ns.ItemID(rest)
		if cmd == "keep" and rest == "" then
			local names = {}
			for k in pairs(ns.db.keep) do names[#names + 1] = ns.ItemName(k) end
			table.sort(names)
			out("keep list: " .. (#names > 0 and table.concat(names, ", ") or "empty"))
		elseif not id then
			out("which item? Shift-click it into the chat line, or give its number.")
		else
			ns.db.keep[id] = (cmd == "keep") or nil
			out(ns.ItemName(id) .. (cmd == "keep" and " won't be sold." or " can be sold again."))
		end
	elseif cmd == "floor" then
		local id = ns.ItemID(rest) or tonumber(rest:match("^(%d+)%s"))
		local price = rest:match("(%S+)$")
		if not id then out("which item? /bankalt floor <item> 1g20s") return end
		if price and price:lower() == "off" then
			ns.db.floor[id] = nil; out("no minimum for " .. ns.ItemName(id) .. ".")
			return
		end
		local c = ns.ParseMoney(price)
		if not c or c <= 0 then out("what price? For example 1g20s, 35s or 250 (copper).") return end
		ns.db.floor[id] = c
		out(ns.ItemName(id) .. " won't be posted below " .. ns.Money(c) .. " each.")
	elseif cmd == "length" or cmd == "duration" then
		local h = tonumber(rest)
		local idx = ({ [12] = 1, [24] = 2, [48] = 3 })[h or 0]
		if not idx then out("auctions last " .. C.HOURS[s.duration] .. " hours; choose 12, 24 or 48.") return end
		s.duration = idx
		out("auctions now last " .. h .. " hours.")
	elseif cmd == "neutral" then
		local v = onOff(rest:lower())
		if v == nil then out("posting at neutral houses is " .. (s.allowNeutral and "on" or "off") .. ".") return end
		s.allowNeutral = v
		out("posting at neutral houses (15% cut) is " .. (v and "on" or "off") .. ".")
		if ns.atAH and ns.P then ns.P.Advance() end
	elseif cmd == "graph" or cmd == "price" or cmd == "prices" then
		ns.G.Open(rest)
	elseif cmd == "rules" or cmd == "where" or cmd == "items" or cmd == "lists" then
		ns.W.Open()
	elseif cmd == "sales" or cmd == "sold" then
		local sales = ns.SL.Store()
		if #sales == 0 then out("no auction mails seen yet: sales show up once the selling character opens its mailbox.") return end
		out("latest auction mails (seen when each character opened its mailbox):")
		for i = #sales, math.max(1, #sales - 14), -1 do
			local s = sales[i]
			local what = s.kind == "sold" and ("sold " .. s.item .. ((s.count or 1) > 1 and (" ×" .. s.count) or "") .. " for " .. ns.Money(s.money))
				or (s.item .. " came back unsold")
			out("  " .. ago(s.t) .. " · " .. s.who .. ": " .. what)
		end
		local gold, n = ns.SL.Today()
		if n > 0 then out("last 24 hours: " .. n .. " sold for " .. ns.Money(gold)) end
	elseif cmd == "stacks" then
		local v = onOff(rest:lower())
		if v == nil then out("adding every stack when you put one in a mail is " .. (s.autoStacks and "on" or "off") .. ".") return end
		s.autoStacks = v
		out("adding every stack when you put one in a mail is " .. (v and "on" or "off") .. ".")
	elseif cmd == "coins" then
		local v = onOff(rest:lower())
		if v == nil then out("prices show " .. (s.coins and "coin pictures" or "g s c letters") .. ": " .. ns.Money(123456)) return end
		s.coins = v
		out("prices now look like this: " .. ns.Money(123456))
		if ns.H then ns.H.Draw() end
	elseif cmd == "minimap" then
		local v = onOff(rest:lower())
		if v == nil then out("the minimap button is " .. (s.minimap and "on" or "off") .. ".") return end
		s.minimap = v
		local b = ns.H.MakeButton()
		if b then if v then b:Show() else b:Hide() end end
		out("the minimap button is " .. (v and "on" or "off") .. ".")
	elseif cmd == "autoname" then
		local v = onOff(rest:lower())
		if v == nil then out("filling in the alt's name when you attach items is " .. (s.autoName and "on" or "off") .. ".") return end
		s.autoName = v
		out("filling in the alt's name when you attach items is " .. (v and "on" or "off") .. ".")
	elseif cmd == "tooltip" then
		local v = onOff(rest:lower())
		if v == nil then out("the tooltip line is " .. (s.tooltip and "on" or "off") .. ".") return end
		s.tooltip = v
		out("the tooltip line is " .. (v and "on" or "off") .. ".")
	elseif cmd == "scan" then
		if not ns.atAH then out("open the auction house first.") return end
		local n = ns.A.ScanHeld(true)
		out("looking up " .. n .. " items.")
	elseif cmd == "skipped" then
		local list = ns.P and ns.P.skipped or {}
		if #list == 0 then out("nothing skipped this visit.") return end
		for _, line in ipairs(list) do out("  " .. line) end
	elseif cmd == "errors" then
		out("errors caught since login: " .. ns.errors)
	else
		for _, line in ipairs(HELP) do out(line) end
	end
end

SLASH_BANKALTHELPER1 = "/bankalt"
SLASH_BANKALTHELPER2 = "/bah"
SlashCmdList = SlashCmdList or {}
SlashCmdList.BANKALTHELPER = function(msg) ns.Safe("/bankalt", L.Command, msg) end

-- ---------------------------------------------------------------- tooltip line

function L.TooltipLine(id)
	if not id or not ns.db or not ns.db.settings.tooltip then return nil end
	local e = ns.V.PriceOf(id)
	local _, _, _, _, _, sell = ns.ItemInfo(id)
	if not e and not (sell and sell > 0) then return nil end
	if not e then return "Bank Alt: no auction price seen yet" end
	local v = ns.V.ForItem(id, 1)
	if v.action == "auction" then
		local seen = e and e.min and (", lowest " .. ns.Money(e.min) .. " " .. ago(e.t)) or ""
		return "Bank Alt: auction at " .. ns.Money(v.price) .. seen
	elseif v.action == "vendor" then
		return "Bank Alt: vendor it (" .. ns.Money(v.vendorTotal) .. ")"
	elseif v.action == "keep" then
		return "Bank Alt: keep"
	end
	return "Bank Alt: none listed when last looked " .. ago(e.t)
end

-- Where an item is mailed, for the tooltip: "Sends to: Bron Herbs" (or both names when it's on two lists).
function L.SendsTo(id)
	if not id or not ns.db then return nil end
	if ns.db.settings.stay[id] then return nil end
	local on = ns.R.ListsFor(id)
	if #on > 0 then return "Sends to: " .. table.concat(on, " or ") end
	return nil
end

local function addLine(tt, id)
	if not tt or not tt.AddLine then return end
	local line, sends = L.TooltipLine(id), L.SendsTo(id)
	if line then tt:AddLine("|cffd4a017" .. line .. "|r") end
	if sends then tt:AddLine("|cffd4a017" .. sends .. "|r") end
	if (line or sends) and tt.Show then tt:Show() end
end

table.insert(ns.OnLoad, function()
	if TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
		TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tt, data)
			if tt ~= GameTooltip and tt ~= ItemRefTooltip then return end
			ns.Safe("tooltip", addLine, tt, data and data.id)
		end)
	elseif GameTooltip and GameTooltip.HookScript then
		GameTooltip:HookScript("OnTooltipSetItem", function(tt)
			local _, link = tt:GetItem()
			ns.Safe("tooltip", addLine, tt, ns.ItemID(link))
		end)
	end
end)
