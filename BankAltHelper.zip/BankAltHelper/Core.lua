-- Bank Alt Helper: core. Saved data, the character key, events and small helpers.
-- WoW Forever runs on the modern client: items live in C_Item, bags in C_Container,
-- the auction house in C_AuctionHouse. Older globals are used only as a fallback.
local ADDON, ns = ...
ns = ns or {}
BankAltHelper = ns -- for /dump and for the tests

ns.VERSION = "0.6.3"
ns.DB_VERSION = 1

local C = {}
ns.C = C
C.MIN_DEPOSIT = 100        -- copper; Forever's minimum deposit (1 silver; 1 copper was announced)
C.CUT_FACTION = 0.05       -- faction auction house cut
C.CUT_NEUTRAL = 0.15       -- Gadgetzan, Booty Bay, Everlook
C.DURATION_DEFAULT = 2     -- 1 = 12 h, 2 = 24 h, 3 = 48 h
C.HISTORY_MAX = 60         -- price points kept per item
C.HOURS = { 12, 24, 48 }
C.NEUTRAL_PLACES = { ["Gadgetzan"] = true, ["Booty Bay"] = true, ["Everlook"] = true }

-- ---------------------------------------------------------------- printing and errors

function ns.Print(msg)
	local f = DEFAULT_CHAT_FRAME
	local line = "|cffd4a017Bank Alt|r " .. tostring(msg)
	if f and f.AddMessage then f:AddMessage(line) elseif print then print(line) end
end

ns.errors = 0
-- Runs fn safely: an error is counted and printed once a minute at most, never a pop-up per frame.
function ns.Safe(where, fn, ...)
	local ok, err = pcall(fn, ...)
	if not ok then
		ns.errors = ns.errors + 1
		local now = GetTime and GetTime() or 0
		if not ns.lastErr or now - ns.lastErr > 60 then
			ns.lastErr = now
			ns.Print("|cffff6060error in " .. where .. ":|r " .. tostring(err))
		end
	end
	return ok
end

-- ---------------------------------------------------------------- money

-- The game's own coin pictures, as Party Map shows them: 12 [gold] 34 [silver] 56 [copper].
ns.COIN = {
	g = "|TInterface\\MoneyFrame\\UI-GoldIcon:0:0:2:0|t",
	s = "|TInterface\\MoneyFrame\\UI-SilverIcon:0:0:2:0|t",
	c = "|TInterface\\MoneyFrame\\UI-CopperIcon:0:0:2:0|t",
}

-- 123456 -> "12 [gold] 34 [silver] 56 [copper]" (or "12g 34s 56c" with /bankalt coins off)
function ns.Money(c)
	c = math.floor(tonumber(c) or 0)
	local neg = c < 0
	if neg then c = -c end
	local g, s, cp = math.floor(c / 10000), math.floor(c / 100) % 100, c % 100
	local icons = not (ns.db and ns.db.settings and ns.db.settings.coins == false)
	local function unit(n, k) return n .. (icons and ns.COIN[k] or k) end
	local out = {}
	if g > 0 then out[#out + 1] = unit(g, "g") end
	if s > 0 or (g > 0 and cp > 0) then out[#out + 1] = unit(s, "s") end
	if cp > 0 or #out == 0 then out[#out + 1] = unit(cp, "c") end
	return (neg and "-" or "") .. table.concat(out, " ")
end

-- "1g20s", "1g 20s 5c", "250", "12s" -> copper (nil when it can't be read)
function ns.ParseMoney(s)
	if type(s) ~= "string" then return nil end
	s = s:lower():gsub("%s+", "")
	if s == "" then return nil end
	if s:match("^%d+$") then return tonumber(s) end
	local total, rest = 0, s
	for n, unit in s:gmatch("(%d+)([gsc])") do
		n = tonumber(n)
		if unit == "g" then total = total + n * 10000
		elseif unit == "s" then total = total + n * 100
		else total = total + n end
	end
	rest = rest:gsub("%d+[gsc]", "")
	if rest ~= "" then return nil end
	return total
end

-- ---------------------------------------------------------------- items

function ns.ItemInfo(id)
	local get = (C_Item and C_Item.GetItemInfo) or GetItemInfo
	if not get or not id then return nil end
	local name, link, quality, _, _, _, _, stack, _, icon, sell = get(id)
	if not name and C_Item and C_Item.RequestLoadItemDataByID then pcall(C_Item.RequestLoadItemDataByID, id) end
	return name, link, quality, stack, icon, sell
end

function ns.ItemName(id)
	local name = ns.ItemInfo(id)
	return name or ("item " .. tostring(id))
end

-- "item:2447:..." or a link or a number -> 2447
function ns.ItemID(x)
	if type(x) == "number" then return x end
	if type(x) ~= "string" then return nil end
	local id = x:match("item:(%d+)") or x:match("^%s*(%d+)%s*$")
	return id and tonumber(id)
end

-- Is it bound, or otherwise not something the auction house takes?
function ns.Sellable(info)
	if not info then return false end
	if info.isBound then return false end
	if info.hasNoValue then return false end
	return true
end

-- ---------------------------------------------------------------- characters and saved data

function ns.Faction()
	local f = UnitFactionGroup and UnitFactionGroup("player")
	return f or "Neutral"
end

local function isTable(t) return type(t) == "table" end

-- ---------------------------------------------------------------- character names
-- WoW Forever characters have a first name and a surname ("Bron Herbs"), but the game gives an
-- addon only the first name, so several alts called Bron all look like "Bron". The player frame
-- shows the full name, so it's read from there (as Party Map does), kept for that character
-- (BankAltHelperChar is saved per character), and every character is keyed by its full name.

local function secret(v) return issecretvalue and issecretvalue(v) or false end

-- "bron herbs", " Bron-Herbs ", "Bron Herbs-93" -> "Bron Herbs"
function ns.NormName(s)
	if type(s) ~= "string" or secret(s) then return nil end
	s = s:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub('^[%s"\']+', ""):gsub('[%s"\']+$', "")
	s = s:gsub("%-%d+$", "")                       -- a realm number
	if not s:find(" ") then s = s:gsub("%-", " ") end -- the WTF folder style, Bron-Herbs
	s = s:gsub("%s+", " ")
	if s == "" then return nil end
	return (s:gsub("(%S)(%S*)", function(a, b) return a:upper() .. b:lower() end))
end

-- Reads "Bron Herbs" off the player frame: a text that starts with your first name and goes on.
function ns.ReadFrameName()
	local first = UnitName and UnitName("player")
	if type(first) ~= "string" or first == "" or secret(first) then return nil end
	local function try(fs)
		if not (fs and fs.GetText) then return nil end
		local ok, t = pcall(fs.GetText, fs)
		if not ok or type(t) ~= "string" or secret(t) then return nil end
		t = t:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("^%s+", ""):gsub("%s+$", "")
		if t:sub(1, #first + 1) == first .. " " and #t <= 40 then return t end
		return nil
	end
	local found = try(_G.PlayerName) or try(PlayerFrame and PlayerFrame.name)
	local function walk(f, depth)
		if found or not f or depth > 5 then return end
		local okr, regions = pcall(function() return { f:GetRegions() } end)
		if okr then
			for _, r in ipairs(regions) do
				if not found and r.GetObjectType and r:GetObjectType() == "FontString" then found = try(r) end
			end
		end
		local okc, kids = pcall(function() return { f:GetChildren() } end)
		if okc then for _, k in ipairs(kids) do walk(k, depth + 1) end end
	end
	if not found and PlayerFrame then walk(PlayerFrame, 0) end
	return found and ns.NormName(found) or nil
end

-- This character's full name (its first name until the full one is known).
function ns.Me()
	if ns.fullName then return ns.fullName end
	local c = BankAltHelperChar
	if isTable(c) and type(c.name) == "string" and c.name ~= "" then
		ns.fullName = c.name
		return c.name
	end
	return (UnitName and UnitName("player")) or "Unknown"
end

-- Sets this character's full name (read from the frame, or typed with /bankalt iam).
function ns.SetMyName(name, typed)
	name = ns.NormName(name)
	if not name then return nil end
	if not isTable(BankAltHelperChar) then BankAltHelperChar = {} end
	local first = UnitName and UnitName("player")
	BankAltHelperChar.name, BankAltHelperChar.typed = name, typed and true or nil
	ns.fullName = name
	if ns.db and first and first ~= name then ns.ForgetShort(first) end
	return name
end

-- Before 0.5.0 characters were saved under their first name, which mixed all the Brons together.
-- Once a full name is known, that mixed entry (and anything pointing at it) is dropped.
function ns.ForgetShort(first)
	local db = ns.db
	if not db or not db.chars[first] then return end
	db.chars[first] = nil
	db.transit[first] = nil
	local s = db.settings
	local hadJob = s.alts[first] ~= nil
	s.alts[first] = nil
	if s.bankAlt == first then s.bankAlt = nil end
	for id, who in pairs(s.send) do if who == first then s.send[id] = nil end end
	s.lists[first] = nil
	if hadJob then
		ns.Print("characters are now kept by their full name, so the job you gave \"" .. first
			.. "\" was cleared: set it again in /bankalt.")
	end
end

-- Tries to learn the full name; returns it once known.
function ns.LearnName()
	local c = BankAltHelperChar
	if isTable(c) and type(c.name) == "string" and c.name ~= "" then
		if ns.fullName ~= c.name then ns.SetMyName(c.name, c.typed) end
		return c.name
	end
	local n = ns.ReadFrameName()
	if n then return ns.SetMyName(n) end
	return nil
end

-- A character's key from what was typed: an exact known name (any case), or a first name that
-- only one of your characters has. Returns key, and a list of matches when it's ambiguous.
function ns.Resolve(s)
	local n = ns.NormName(s)
	if not n then return nil end
	local chars = ns.db and ns.db.chars or {}
	local function known(x)
		if not x then return nil end
		if chars[x] then return x end
		local low = x:lower()
		for k in pairs(chars) do if k:lower() == low then return k end end
	end
	local k = known(n)
	if k then return k end
	-- "Name-Realm" the way some mail boxes write it: the part before the hyphen
	if type(s) == "string" and not s:find(" ") and s:find("%-") then
		local before = ns.NormName(s:match("^%s*([^%-]+)"))
		k = known(before)
		if k then return k end
		n = before or n
	end
	local low = n:lower()
	if not n:find(" ") then
		local hits = {}
		for k in pairs(chars) do
			if k:match("^(%S+)"):lower() == low and k:find(" ") then hits[#hits + 1] = k end
		end
		table.sort(hits)
		if #hits == 1 then return hits[1] end
		if #hits > 1 then return n, hits end
	end
	return n
end

-- Splits "<name> <rest>" where the name may be "in quotes", a known character, or (Forever's
-- usual shape) a first name and a surname.
function ns.SplitName(text)
	if type(text) ~= "string" then return nil, "" end
	text = text:gsub("^%s+", "")
	local q, rest = text:match('^"([^"]+)"%s*(.-)$')
	if not q then q, rest = text:match("^'([^']+)'%s*(.-)$") end
	if q then return ns.Resolve(q), rest end
	local words = {}
	for w in text:gmatch("%S+") do words[#words + 1] = w end
	if #words == 0 then return nil, "" end
	local chars = ns.db and ns.db.chars or {}
	for n = math.min(#words, 4), 1, -1 do
		local cand = ns.NormName(table.concat(words, " ", 1, n))
		local low = cand and cand:lower()
		for k in pairs(chars) do
			if low and k:lower() == low then return k, table.concat(words, " ", n + 1) end
		end
	end
	local take = 1
	if #words >= 3 then take = 2
	elseif #words == 2 and not (ns.R and (ns.R.CatName(words[2]) or words[2]:lower() == "off")) then take = 2 end
	return ns.Resolve(table.concat(words, " ", 1, take)), table.concat(words, " ", take + 1)
end

-- Builds or repairs the saved data. Anything of the wrong type is reset, so junk never breaks the addon.
function ns.InitDB()
	if not isTable(BankAltHelperDB) then BankAltHelperDB = {} end
	local db = BankAltHelperDB
	if db.v ~= ns.DB_VERSION then db.v = ns.DB_VERSION end
	if not isTable(db.chars) then db.chars = {} end
	if not isTable(db.prices) then db.prices = {} end
	if not isTable(db.deposits) then db.deposits = {} end
	if not isTable(db.transit) then db.transit = {} end
	if not isTable(db.keep) then db.keep = {} end
	if not isTable(db.floor) then db.floor = {} end
	if not isTable(db.settings) then db.settings = {} end
	local s = db.settings
	if type(s.duration) ~= "number" or s.duration < 1 or s.duration > 3 then s.duration = C.DURATION_DEFAULT end
	if type(s.minDeposit) ~= "number" or s.minDeposit < 0 then s.minDeposit = C.MIN_DEPOSIT end
	if type(s.itemStep) ~= "number" or (s.itemStep ~= 1 and s.itemStep ~= 100) then s.itemStep = 1 end
	if type(s.bankAlt) ~= "string" then s.bankAlt = nil end
	if type(s.allowNeutral) ~= "boolean" then s.allowNeutral = false end
	if type(s.tooltip) ~= "boolean" then s.tooltip = true end
	if type(s.autoName) ~= "boolean" then s.autoName = true end
	if type(s.coins) ~= "boolean" then s.coins = true end
	if type(s.autoStacks) ~= "boolean" then s.autoStacks = true end
	if type(s.minimap) ~= "boolean" then s.minimap = true end
	if type(s.minimapAngle) ~= "number" then s.minimapAngle = 200 end
	if type(s.alts) ~= "table" then s.alts = {} end   -- [name] = { herbs = true, ... }
	for name, cats in pairs(s.alts) do
		if type(name) ~= "string" or type(cats) ~= "table" then s.alts[name] = nil end
	end
	if type(s.send) ~= "table" then s.send = {} end   -- [itemID] = alt name: per-item choice
	if type(s.stay) ~= "table" then s.stay = {} end   -- [itemID] = true: never mail it away
	if type(s.lists) ~= "table" then s.lists = {} end -- [name] = { [itemID] = true }: send lists
	for name, list in pairs(s.lists) do
		if type(name) ~= "string" or type(list) ~= "table" then s.lists[name] = nil end
	end
	-- 0.4 and before: one character per item. Those become ticks on that character's list.
	for id, who in pairs(s.send) do
		if type(who) == "string" and type(id) == "number" then
			if type(s.lists[who]) ~= "table" then s.lists[who] = {} end
			s.lists[who][id] = true
		end
		s.send[id] = nil
	end
	if type(db.sales) ~= "table" then db.sales = {} end
	if type(db.salesKeys) ~= "table" then db.salesKeys = {} end
	if type(db.lastLook) ~= "table" then db.lastLook = {} end  -- [name] = when you were last on them
	for name, c in pairs(db.chars) do
		if type(name) ~= "string" or not isTable(c) then db.chars[name] = nil end
	end
	for k, list in pairs(db.transit) do
		if type(k) ~= "string" or not isTable(list) then db.transit[k] = nil end
	end
	ns.db = db
	return db
end

function ns.Char(name)
	name = name or ns.Me()
	local chars = ns.db.chars
	local c = chars[name]
	if not isTable(c) then
		c = {}
		chars[name] = c
	end
	if not isTable(c.bags) then c.bags = {} end
	if not isTable(c.bank) then c.bank = {} end
	if not isTable(c.mail) then c.mail = {} end
	return c
end

-- The price book for this faction's auction house (one per faction on Forever's megaservers).
function ns.Prices(faction)
	faction = faction or (ns.db.settings.faction) or ns.Faction()
	local p = ns.db.prices[faction]
	if not isTable(p) then p = {}; ns.db.prices[faction] = p end
	return p
end

function ns.Now()
	return (time and time()) or 0
end

-- ---------------------------------------------------------------- events

local frame = CreateFrame("Frame", "BankAltHelperEvents")
ns.frame = frame
ns.handlers = {}

function ns.On(event, fn)
	local list = ns.handlers[event]
	if not list then
		list = {}
		ns.handlers[event] = list
		frame:RegisterEvent(event)
	end
	list[#list + 1] = fn
end

frame:SetScript("OnEvent", function(_, event, ...)
	local list = ns.handlers[event]
	if not list then return end
	for i = 1, #list do ns.Safe(event, list[i], ...) end
end)

-- A tiny timer that works with or without C_Timer.
function ns.After(sec, fn)
	if C_Timer and C_Timer.After then
		C_Timer.After(sec, function() ns.Safe("timer", fn) end)
	else
		ns.Safe("timer", fn)
	end
end

ns.On("ADDON_LOADED", function(name)
	if name ~= ADDON then return end
	ns.InitDB()
	if not isTable(BankAltHelperChar) then BankAltHelperChar = {} end
	ns.fullName = nil
	ns.LearnName()
	local me = ns.Char()
	me.faction = ns.Faction()
	if UnitClass then me.class = select(2, UnitClass("player")) end
	if ns.OnLoad then for _, fn in ipairs(ns.OnLoad) do ns.Safe("load", fn) end end
end)

ns.OnLoad = {}

-- The player frame may not have its name yet when the addon loads: try again as the world comes up.
-- If it can't be read at all, say how to tell it.
ns.On("PLAYER_ENTERING_WORLD", function()
	if ns.LearnName() then return end
	ns.After(2, function()
		if ns.LearnName() then ns.Char() return end
		ns.After(5, function()
			if ns.LearnName() then ns.Char() return end
			ns.Print("I can't read this character's full name. Type it once: /bankalt iam \"" ..
				(UnitName and UnitName("player") or "Name") .. " Surname\"")
		end)
	end)
end)
