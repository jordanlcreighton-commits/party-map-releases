-- Umberhide Skies: the settings panel (/skies). A meter for every effect, the presets and switches.
local ADDON, ns = ...
local O = {}
ns.Options = O

local panel
local controls = {}
local refreshing = false

local function Pct(v) return ("%d%%"):format(math.floor(v * 100 + 0.5)) end
local function Times(v) return ("%.1f×"):format(v) end

local function Label(parent, text, template)
	local f = parent:CreateFontString(nil, "OVERLAY", template or "GameFontNormalSmall")
	f:SetText(text)
	return f
end

local function Slider(label, key, lo, hi, step, fmt, x, y, width)
	local sl = CreateFrame("Slider", nil, panel, BackdropTemplateMixin and "BackdropTemplate" or nil)
	sl:SetOrientation("HORIZONTAL")
	sl:SetSize(width, 16)
	sl:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y - 16)
	sl:SetMinMaxValues(lo, hi)
	sl:SetValueStep(step)
	if sl.SetObeyStepOnDrag then sl:SetObeyStepOnDrag(true) end
	if sl.SetBackdrop then
		sl:SetBackdrop({ bgFile = "Interface\\Buttons\\UI-SliderBar-Background", edgeFile = "Interface\\Buttons\\UI-SliderBar-Border",
			tile = true, tileSize = 8, edgeSize = 8, insets = { left = 3, right = 3, top = 6, bottom = 6 } })
	end
	sl:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Horizontal")
	local name = Label(panel, label)
	name:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y)
	local val = Label(panel, "", "GameFontHighlightSmall")
	val:SetPoint("TOPRIGHT", panel, "TOPLEFT", x + width, y)
	sl:SetScript("OnValueChanged", function(_, v)
		val:SetText(fmt(v))
		if refreshing then return end
		ns.s[key] = v
		-- moving a weather meter by hand means your own weather, not the zone's
		if key == "fog" or key == "rain" or key == "wind" or key == "snow" or key == "ff" then ns.s.live = false end
		ns.Touched()
	end)
	sl:EnableMouseWheel(true)
	sl:SetScript("OnMouseWheel", function(self, delta) self:SetValue(self:GetValue() + delta * step) end)
	controls[#controls + 1] = { kind = "slider", w = sl, key = key, val = val, fmt = fmt }
	return sl
end

local function Check(label, key, x, y, get, set)
	local cb = CreateFrame("CheckButton", nil, panel, "UICheckButtonTemplate")
	cb:SetSize(24, 24)
	cb:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y)
	local t = Label(panel, label, "GameFontHighlightSmall")
	t:SetPoint("LEFT", cb, "RIGHT", 2, 1)
	cb:SetScript("OnClick", function(self)
		if refreshing then return end
		local v = self:GetChecked() and true or false
		if set then set(v) else ns.s[key] = v end
		if key == "on" then ns.Changed() else ns.Touched() end
	end)
	controls[#controls + 1] = { kind = "check", w = cb, key = key, get = get }
	return cb
end

local function Button(text, x, y, w, onClick)
	local b = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
	b:SetSize(w, 22)
	b:SetPoint("TOPLEFT", panel, "TOPLEFT", x, y)
	b:SetText(text)
	b:SetScript("OnClick", onClick)
	return b
end

local colourButton, clockButton, presetNote, weatherNote
local presetButtons = {}

function O.Refresh()
	if not panel then return end
	refreshing = true
	for _, c in ipairs(controls) do
		if c.kind == "slider" then
			c.w:SetValue(ns.s[c.key])
			c.val:SetText(c.fmt(ns.s[c.key]))
		elseif c.kind == "check" then
			c.w:SetChecked(c.get and c.get() or ns.s[c.key])
		end
	end
	colourButton:SetText("Colour: " .. ns.Colour(ns.s.colour).name)
	clockButton:SetText("Night: " .. ns.ClockName(ns.s.clock))
	local p = ns.Preset(ns.s.preset)
	presetNote:SetText(ns.s.on and ("Look: " .. (p and p.name or "your own")) or "Off: /skies on, or tick On")
	weatherNote:SetText("Weather: " .. (ns.Live and ns.Live.Describe() or ""))
	for key, b in pairs(presetButtons) do
		if b.LockHighlight then if key == ns.s.preset then b:LockHighlight() else b:UnlockHighlight() end end
	end
	refreshing = false
end

local function Build()
	panel = CreateFrame("Frame", "UmberhideSkiesPanel", UIParent, BackdropTemplateMixin and "BackdropTemplate" or nil)
	panel:SetSize(590, 660)
	panel:SetPoint("CENTER")
	panel:SetFrameStrata("DIALOG")
	panel:SetMovable(true)
	panel:EnableMouse(true)
	panel:RegisterForDrag("LeftButton")
	panel:SetScript("OnDragStart", panel.StartMoving)
	panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
	if panel.SetBackdrop then
		panel:SetBackdrop({ bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background-Dark", edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
			tile = true, tileSize = 32, edgeSize = 32, insets = { left = 11, right = 12, top = 12, bottom = 11 } })
	end
	if UISpecialFrames then table.insert(UISpecialFrames, "UmberhideSkiesPanel") end
	local title = Label(panel, "Umberhide Skies", "GameFontNormalLarge")
	title:SetPoint("TOPLEFT", 24, -20)
	local ver = Label(panel, ns.VERSION, "GameFontDisableSmall")
	ver:SetPoint("LEFT", title, "RIGHT", 8, -1)
	presetNote = Label(panel, "", "GameFontHighlightSmall")
	presetNote:SetPoint("TOPRIGHT", panel, "TOPRIGHT", -48, -24)
	local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
	close:SetPoint("TOPRIGHT", -6, -6)
	Check("On", "on", 22, -46)
	-- presets
	local px, py = 22, -76
	for i, p in ipairs(ns.PRESETS) do
		local col, row = (i - 1) % 4, math.floor((i - 1) / 4)
		local b = Button(p.name, px + col * 138, py - row * 26, 134, function() ns.ApplyPreset(p.key) end)
		presetButtons[p.key] = b
	end
	-- what the weather's doing (live) or "your own look"
	weatherNote = Label(panel, "", "GameFontHighlightSmall")
	weatherNote:SetPoint("TOPLEFT", panel, "TOPLEFT", 26, -160)
	weatherNote:SetWidth(540)
	weatherNote:SetJustifyH("LEFT")
	-- meters, two columns
	local lx, rx, top, gap, w = 26, 316, -186, 38, 250
	Slider("Darkness", "dark", 0, 0.97, 0.01, Pct, lx, top, w)
	Slider("Dark edges", "vig", 0, 1, 0.01, Pct, lx, top - gap, w)
	Slider("Light size", "lsize", 0.3, 2.5, 0.05, Times, lx, top - gap * 2, w)
	Slider("Light brightness", "lstr", 0, 1, 0.01, Pct, lx, top - gap * 3, w)
	Slider("Your light: across", "lightX", 0, 1, 0.005, Pct, lx, top - gap * 4, w)
	Slider("Your light: up and down", "lightY", 0.25, 1, 0.005, Pct, lx, top - gap * 5, w)
	Slider("Horizon (match your camera)", "horizon", 0.05, 0.6, 0.005, Pct, lx, top - gap * 6, w)
	colourButton = Button("Colour", rx, top + 2, w, function()
		local i = 1
		for k, c in ipairs(ns.COLOURS) do if c.key == ns.s.colour then i = k end end
		ns.s.colour = ns.COLOURS[i % #ns.COLOURS + 1].key
		ns.Touched()
	end)
	Slider("Colour strength", "cstr", 0, 1, 0.01, Pct, rx, top - gap, w)
	Slider("Fog", "fog", 0, 1, 0.01, Pct, rx, top - gap * 2, w)
	Slider("Rain", "rain", 0, 1, 0.01, Pct, rx, top - gap * 3, w)
	Slider("Wind", "wind", 0, 1, 0.01, Pct, rx, top - gap * 4, w)
	Slider("Snow", "snow", 0, 1, 0.01, Pct, rx, top - gap * 5, w)
	Slider("Fireflies", "ff", 0, 1, 0.01, Pct, rx, top - gap * 6, w)
	Slider("Lightning: how often", "boltRate", 0, 1, 0.01, Pct, lx, top - gap * 7, w)
	Slider("Lightning: brightness", "boltBright", 0, 1, 0.01, Pct, rx, top - gap * 7, w)
	Slider("Live weather: strength", "wstr", 0, 1, 0.01, Pct, lx, top - gap * 8, w)
	-- switches
	local cy = top - gap * 9 - 8
	local cols = { 22, 212, 402 }
	local list = {
		false, { "Light round you", "meOn" }, { "Light round Mika", "mikaOn" },
		{ "Splashes", "splash" }, { "Lightning", "storm" }, { "Frosted edges", "frost" },
		{ "Cat Form night vision", "cat" }, { "Prowling dims the world", "prowl" }, { "Low health warning", "lowhp" },
		{ "Sounds", "sound" },
	}
	for i, e in ipairs(list) do
		local col, row = (i - 1) % 3, math.floor((i - 1) / 3)
		if e then Check(e[1], e[2], cols[col + 1], cy - row * 24) end
	end
	-- which clock the night follows: your PC's, the game's, or always night
	clockButton = Button("Night", cols[1], cy + 2, 182, function()
		local i = 1
		for k, c in ipairs(ns.CLOCKS) do if c.key == ns.s.clock then i = k end end
		ns.s.clock = ns.CLOCKS[i % #ns.CLOCKS + 1].key
		ns.Changed()
	end)
	Check("Gloom indoors", "indoors", cols[2], cy - 3 * 24,
		function() return ns.s.indoors == "gloom" end,
		function(v) ns.s.indoors = v and "gloom" or "off" end)
	local hint = Label(panel, "Light round Mika needs friendly name plates on. Sounds use the game's Ambience volume. /skies weather storm brings a storm in.", "GameFontDisableSmall")
	hint:SetPoint("BOTTOMLEFT", panel, "BOTTOMLEFT", 24, 18)
	panel:Hide()
	local since = 0
	panel:SetScript("OnUpdate", function(_, e)
		since = since + (e or 0)
		if since > 2 then since = 0; weatherNote:SetText("Weather: " .. (ns.Live and ns.Live.Describe() or "")) end
	end)
	table.insert(ns.listeners, O.Refresh)
end

function O.Toggle()
	if not panel then Build() end
	if panel:IsShown() then panel:Hide() else O.Refresh(); panel:Show() end
end

function O.Panel() return panel end
