-- Party Map: turns a frame of bytes into the strip's grey cells.
-- Pure Lua 5.1 (no WoW API), so it can be tested outside the game.
--
-- Strip layout (one cell = 2 screen pixels wide, 1 tall, grey level 0..7):
--   sync:        7 0 0 7
--   calibration: 0 1 2 3 4 5 6 7
--   payload:     the frame's bytes as a bit stream, 3 bits per cell (most significant first),
--                padded with 0s to the strip's length
-- The frame's last two bytes are a CRC-16/CCITT of the bytes before them.

local addonName, ns = ...
ns = ns or {}

local E = {}
ns.Encode = E

E.CELLS = 260                     -- cells in the strip (520 px wide)
E.MAX = 0.14                      -- brightest grey drawn (0..1): near black, so the strip all but disappears.
                                  -- (WoW Forever draws greys about twice as bright as asked; the app only
                                  -- needs the levels to differ, and it reads exact pixel values)
E.MAX_BRIGHT = 0.45               -- /partymap bright: easier to read if a screen setting crushes dark greys
E.SYNC = { 7, 0, 0, 7 }
E.HEADER_CELLS = #E.SYNC + 8      -- sync + calibration
E.PAYLOAD_BYTES = math.floor((E.CELLS - E.HEADER_CELLS) * 3 / 8)   -- 93
E.FIXED_BYTES = 24                -- frame header before the chunk
E.CHUNK_MAX = E.PAYLOAD_BYTES - E.FIXED_BYTES - 2                 -- 67 (2: CRC)
E.FORMAT = 1                      -- the strip format (the frame's first byte); the app ignores frames of a format it doesn't know
ns.STRIP_FORMAT = E.FORMAT

local floor = math.floor

-- CRC-16/CCITT-FALSE (poly 0x1021, init 0xFFFF), arithmetic only (Lua 5.1 has no bit ops)
local function xor8(a, b)          -- 8-bit xor
	local r, p = 0, 1
	for _ = 1, 8 do
		local ab, bb = a % 2, b % 2
		if ab ~= bb then r = r + p end
		a, b, p = floor(a / 2), floor(b / 2), p * 2
	end
	return r
end
function E.CRC16(bytes, n)
	local crc = 0xFFFF
	for i = 1, n do
		local hi = floor(crc / 256)
		local lo = crc % 256
		hi = xor8(hi, bytes[i])
		crc = hi * 256 + lo
		for _ = 1, 8 do
			if crc >= 0x8000 then
				crc = (crc * 2) % 0x10000
				-- xor with 0x1021
				local h, l = floor(crc / 256), crc % 256
				crc = xor8(h, 0x10) * 256 + xor8(l, 0x21)
			else
				crc = (crc * 2) % 0x10000
			end
		end
	end
	return crc
end

local function put16(t, v) v = floor(v) % 65536; t[#t + 1] = floor(v / 256); t[#t + 1] = v % 256 end
local function put24(t, v) v = floor(v) % 16777216; t[#t + 1] = floor(v / 65536); t[#t + 1] = floor(v / 256) % 256; t[#t + 1] = v % 256 end

-- f = { seq, rev, page, pages, u, v (0..1 or nil), facing (radians or nil), mapID, W, H, flags, chunk (string) }
function E.BuildFrame(f)
	local t = {}
	t[1] = E.FORMAT                            -- strip format
	t[2] = (f.seq or 0) % 256
	put16(t, f.rev or 0)
	put16(t, f.page or 0)
	put16(t, f.pages or 0)
	if type(f.u) == "number" and type(f.v) == "number" and f.u == f.u and f.v == f.v then
		put24(t, math.max(0, math.min(16777214, f.u * 16777214 + 0.5)))
		put24(t, math.max(0, math.min(16777214, f.v * 16777214 + 0.5)))
	else
		put24(t, 16777215); put24(t, 16777215)
	end
	if type(f.facing) == "number" and f.facing == f.facing then
		local a = f.facing % (2 * math.pi)
		put16(t, math.min(65534, a / (2 * math.pi) * 65534 + 0.5))
	else
		put16(t, 65535)
	end
	put16(t, f.mapID or 0)
	put16(t, (f.W or 0) * 10 + 0.5)
	put16(t, (f.H or 0) * 10 + 0.5)
	t[#t + 1] = (f.flags or 0) % 256
	local chunk = f.chunk or ""
	if #chunk > E.CHUNK_MAX then chunk = chunk:sub(1, E.CHUNK_MAX) end
	t[#t + 1] = #chunk
	for i = 1, #chunk do t[#t + 1] = chunk:byte(i) end
	local crc = E.CRC16(t, #t)
	put16(t, crc)
	return t
end

-- bytes -> grey levels for every cell of the strip
function E.Cells(bytes)
	local cells = {}
	for i = 1, #E.SYNC do cells[i] = E.SYNC[i] end
	for l = 0, 7 do cells[#cells + 1] = l end
	-- bit stream, 3 bits per cell
	local acc, nbits = 0, 0
	for i = 1, #bytes do
		acc = acc * 256 + bytes[i]; nbits = nbits + 8
		while nbits >= 3 do
			local shift = 2 ^ (nbits - 3)
			local v = floor(acc / shift)
			cells[#cells + 1] = v
			acc = acc - v * shift
			nbits = nbits - 3
		end
	end
	if nbits > 0 then cells[#cells + 1] = acc * 2 ^ (3 - nbits) end
	while #cells < E.CELLS do cells[#cells + 1] = 0 end
	return cells
end

return E
