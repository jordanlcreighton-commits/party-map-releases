-- Bank Alt Helper: which alt each item belongs on. You give each bank alt one or more categories
-- (herbs, gear, reagents...); every item is sorted by the game's own item type, most specific first.
-- A per-item choice (/bankalt send <item> <alt>) beats the category.
local _, ns = ...
local R = {}
ns.R = R

-- The game's item classes and Trade Goods subclasses (modern client, as WoW Forever uses).
local CLASS = { CONSUMABLE = 0, CONTAINER = 1, WEAPON = 2, GEM = 3, ARMOR = 4, REAGENT = 5, TRADEGOODS = 7, RECIPE = 9, MISC = 15 }
local TG = { PARTS = 1, JEWEL = 4, CLOTH = 5, LEATHER = 6, METAL = 7, COOKING = 8, HERB = 9, ELEMENTAL = 10, OTHER = 11, ENCHANTING = 12, INSCRIPTION = 16 }
R.CLASS, R.TG = CLASS, TG

-- Every category, in the order they're shown. "reagents" takes any crafting material that no more
-- specific alt takes; "everything" takes whatever is left.
R.CATS = { "herbs", "leather", "cloth", "ore", "cooking", "enchanting", "elemental", "reagents", "gear",
	"consumables", "recipes", "bags", "everything" }
R.LABEL = { herbs = "herbs", leather = "leather and hides", cloth = "cloth", ore = "ore, stone and bars",
	cooking = "cooking ingredients", enchanting = "enchanting materials", elemental = "elementals",
	reagents = "crafting reagents", gear = "gear", consumables = "potions, food and scrolls",
	recipes = "recipes", bags = "bags", everything = "everything else" }
local ALIAS = { herb = "herbs", leathers = "leather", hides = "leather", ores = "ore", metal = "ore", bars = "ore",
	mining = "ore", stone = "ore", food = "cooking", ench = "enchanting", reagent = "reagents", mats = "reagents",
	materials = "reagents", crafting = "reagents", armor = "gear", armour = "gear", weapons = "gear",
	weapon = "gear", potions = "consumables", consumable = "consumables", recipe = "recipes", bag = "bags",
	all = "everything", rest = "everything", other = "everything" }

function R.CatName(word)
	if type(word) ~= "string" then return nil end
	word = word:lower()
	for _, c in ipairs(R.CATS) do if c == word then return c end end
	return ALIAS[word]
end

-- The most specific category for an item, then the broader one it falls back to.
function R.CategoryOf(id)
	local get = (C_Item and C_Item.GetItemInfoInstant) or GetItemInfoInstant
	if not get or not id then return "everything" end
	local _, _, _, _, _, class, sub = get(id)
	if class == CLASS.TRADEGOODS then
		if sub == TG.HERB then return "herbs", "reagents" end
		if sub == TG.LEATHER then return "leather", "reagents" end
		if sub == TG.CLOTH then return "cloth", "reagents" end
		if sub == TG.METAL then return "ore", "reagents" end
		if sub == TG.COOKING then return "cooking", "reagents" end
		if sub == TG.ENCHANTING then return "enchanting", "reagents" end
		if sub == TG.ELEMENTAL then return "elemental", "reagents" end
		return "reagents"
	end
	if class == CLASS.REAGENT then return "reagents" end
	if class == CLASS.WEAPON or class == CLASS.ARMOR then return "gear" end
	if class == CLASS.CONSUMABLE then return "consumables" end
	if class == CLASS.RECIPE then return "recipes" end
	if class == CLASS.CONTAINER then return "bags" end
	return "everything"
end

-- settings.alts = { [name] = { herbs = true, ... } }
function R.Alts()
	local s = ns.db.settings
	if type(s.alts) ~= "table" then s.alts = {} end
	return s.alts
end

local function altWith(cat)
	local found
	for name, cats in pairs(R.Alts()) do
		if type(cats) == "table" and cats[cat] then
			if not found or name < found then found = name end -- the same answer every time
		end
	end
	return found
end

-- Send lists: settings.lists[character] = { [itemID] = true }, ticked in the send lists window.
function R.Lists()
	local s = ns.db.settings
	if type(s.lists) ~= "table" then s.lists = {} end
	return s.lists
end

-- The characters whose send list has this item, by name (leaving out the one you're on).
function R.ListsFor(id, includeMe)
	local me, on = ns.Me(), {}
	for name, list in pairs(R.Lists()) do
		if type(list) == "table" and list[id] and (includeMe or name ~= me) then on[#on + 1] = name end
	end
	table.sort(on)
	return on
end

function R.SetListed(name, id, on)
	if type(name) ~= "string" or not id then return end
	local lists = R.Lists()
	local list = lists[name]
	if type(list) ~= "table" then list = {}; lists[name] = list end
	list[id] = on and true or nil
	if not next(list) then lists[name] = nil end
end

-- Which character an item belongs on (nil when no alt takes it). Third value: when it's ticked for
-- more than one character, the list of them, so the mail can ask which.
function R.Home(id)
	if ns.db.settings.stay[id] then return nil, "never mailed" end
	local chosen = ns.M and ns.M.choice and ns.M.choice[id]
	if chosen then return chosen, "you chose" end
	local on = R.ListsFor(id)
	if #on == 1 then return on[1], "on " .. on[1] .. "'s send list" end
	if #on > 1 then return nil, "on " .. #on .. " send lists", on end
	local fixed = ns.db.settings.send and ns.db.settings.send[id]
	if type(fixed) == "string" then return fixed, "your choice for this item" end
	local cat, broad = R.CategoryOf(id)
	local who = altWith(cat)
	if who then return who, R.LABEL[cat] end
	if broad then
		who = altWith(broad)
		if who then return who, R.LABEL[broad] end
	end
	who = altWith("everything") or ns.db.settings.bankAlt
	if who then return who, R.LABEL.everything end
	return nil
end

-- One alt's categories as words, for lists.
function R.Describe(name)
	local cats = R.Alts()[name]
	if type(cats) ~= "table" then
		return name == ns.db.settings.bankAlt and R.LABEL.everything or nil
	end
	local words = {}
	for _, c in ipairs(R.CATS) do if cats[c] then words[#words + 1] = R.LABEL[c] end end
	return #words > 0 and table.concat(words, ", ") or nil
end

-- What this character should send away: { [alt] = { { id, count, why }... } } in bag order.
-- Bound items, keep-on-this-character items and items better sold to a vendor stay.
function R.Outgoing()
	local me = ns.Me()
	local out, order, ask = {}, {}, {}
	local counts = {}
	for _, bag in ipairs(ns.S.BagIDs()) do
		local n = (C_Container and C_Container.GetContainerNumSlots and C_Container.GetContainerNumSlots(bag)) or 0
		for slot = 1, n do
			local i = ns.S.SlotInfo(bag, slot)
			-- (a locked stack is already in a mail, or on its way somewhere: not counted again)
			if i and i.id and ns.Sellable(i) and not i.locked then counts[i.id] = (counts[i.id] or 0) + i.count end
		end
	end
	local ids = {}
	for id in pairs(counts) do ids[#ids + 1] = id end
	table.sort(ids)
	for _, id in ipairs(ids) do
		local home, why, several = R.Home(id)
		if several then ask[#ask + 1] = { id = id, count = counts[id], on = several } end
		if home and home ~= me and not (ns.db.settings.stay and ns.db.settings.stay[id]) then
			-- Held back only when a real auction price says it's worth more to a vendor;
			-- an item with no price seen yet still goes, so the alt can price it.
			local v = ns.V.ForItem(id, counts[id])
			local e = ns.V.PriceOf(id)
			local knownLoss = v.action == "vendor" and e and (e.min or e.last)
			if not knownLoss or ns.db.keep[id] then
				if not out[home] then out[home] = {}; order[#order + 1] = home end
				table.insert(out[home], { id = id, count = counts[id], why = why })
			end
		end
	end
	table.sort(order)
	return out, order, ask
end

-- Every character's count of one item, most first.
function R.Find(id)
	local rows = {}
	for name in pairs(ns.db.chars) do
		local n = ns.S.AllItems(name)[id]
		if n and n > 0 then rows[#rows + 1] = { name = name, n = n } end
	end
	table.sort(rows, function(a, b) if a.n ~= b.n then return a.n > b.n end return a.name < b.name end)
	return rows
end
