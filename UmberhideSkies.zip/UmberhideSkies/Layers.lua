-- Umberhide Skies: the night, the lights, colour moods and the screen edges.
-- One frame on the game world (under the interface and name plates) holds every layer.
local ADDON, ns = ...
local L = {}
ns.Layers = L

local WHITE = "Interface\\Buttons\\WHITE8X8"
local NAVY = { 0.016, 0.027, 0.078 }
local Clamp = ns.Clamp

-- the frame everything is drawn in: the whole screen, behind the interface
local root
function L.Root() return root end

-- Size of the screen in the frame's own units (falls back to a 16:9 screen)
function L.Size()
	local w, h = root and root:GetWidth() or 0, root and root:GetHeight() or 0
	if not w or w <= 0 then w = 1600 end
	if not h or h <= 0 then h = 900 end
	return w, h
end

-- Gradient helper: works with both the newer (colour objects) and older (alpha) API
function ns.Gradient(tex, orient, r, g, b, aBottom, aTop)
	if CreateColor and tex.SetGradient then
		local ok = pcall(tex.SetGradient, tex, orient, CreateColor(r, g, b, aBottom), CreateColor(r, g, b, aTop))
		if ok then return end
	end
	if tex.SetGradientAlpha then
		pcall(tex.SetGradientAlpha, tex, orient, r, g, b, aBottom, r, g, b, aTop)
	else
		tex:SetVertexColor(r, g, b, (aBottom + aTop) / 2)
	end
end

local function Tex(layer, sub, file, blend)
	local t = root:CreateTexture(nil, layer, nil, sub)
	t:SetTexture(file or WHITE)
	if blend then t:SetBlendMode(blend) end
	t:Hide()
	return t
end
L.Tex = Tex

-- places a texture by its centre, in top-left screen units (y measured downwards)
local function Place(t, x, y, w, h)
	local _, H = L.Size()
	t:ClearAllPoints()
	t:SetPoint("CENTER", root, "BOTTOMLEFT", x, H - y)
	t:SetSize(math.max(1, w), math.max(1, h))
end
L.Place = Place

local function PlaceRect(t, x0, y0, x1, y1)
	local _, H = L.Size()
	t:ClearAllPoints()
	if x1 <= x0 or y1 <= y0 then t:Hide() return end
	t:SetPoint("TOPLEFT", root, "BOTTOMLEFT", x0, H - y0)
	t:SetPoint("BOTTOMRIGHT", root, "BOTTOMLEFT", x1, H - y1)
	t:Show()
end

local mood, hole, dim, dark = nil, nil, nil, {}
local far, glowMe
local glows = {}
local vig, prowlDark, prowlVig, catVig, frost, lowhp
local moonGlow, cloudA, cloudB
L.flash = nil

function L.Init()
	root = CreateFrame("Frame", "UmberhideSkiesRoot", WorldFrame or UIParent)
	root:SetAllPoints(WorldFrame or UIParent)
	root:SetFrameStrata("BACKGROUND")
	root:SetFrameLevel(0)
	if root.EnableMouse then root:EnableMouse(false) end
	mood = Tex("BACKGROUND", -8, WHITE, "MOD")
	hole = Tex("BORDER", 0, ns.PATH .. "Textures\\Hole")
	dim = Tex("BORDER", 0)
	for i = 1, 4 do dark[i] = Tex("BORDER", 0) end
	far = Tex("BORDER", 1)
	-- the night's life: slow cloud shadows drifting over the land, and the moon's glow in its part
	-- of the sky (both use the haze stripe of Fog.tga and the soft glow; no extra files)
	cloudA = Tex("BORDER", 1, ns.PATH .. "Textures\\Fog")
	cloudB = Tex("BORDER", 1, ns.PATH .. "Textures\\Fog")
	for _, t in ipairs({ cloudA, cloudB }) do t:SetTexture(ns.PATH .. "Textures\\Fog", "REPEAT", "CLAMP") end
	moonGlow = Tex("ARTWORK", -6, ns.PATH .. "Textures\\Soft", "ADD")
	glowMe = Tex("ARTWORK", -5, ns.PATH .. "Textures\\Soft", "ADD")
	for i = 1, 4 do glows[i] = Tex("ARTWORK", -5, ns.PATH .. "Textures\\Soft", "ADD") end
	vig = Tex("OVERLAY", 0, ns.PATH .. "Textures\\Vignette")
	prowlDark = Tex("OVERLAY", 1)
	prowlVig = Tex("OVERLAY", 1, ns.PATH .. "Textures\\Vignette")
	catVig = Tex("OVERLAY", 2, ns.PATH .. "Textures\\Vignette", "ADD")
	frost = Tex("OVERLAY", 3, ns.PATH .. "Textures\\Frost", "ADD")
	lowhp = Tex("OVERLAY", 4, ns.PATH .. "Textures\\Vignette")
	L.flash = Tex("OVERLAY", 5, WHITE, "ADD")
	for _, t in ipairs({ mood, far, vig, prowlDark, prowlVig, catVig, frost, lowhp, L.flash, cloudA, cloudB }) do t:SetAllPoints(root) end
end

-- ---------------------------------------------------------------- where the lights are
-- Your light: a spot on the screen (where your character stands; you can nudge it). Its size
-- follows how far down the screen it is, as a person further away looks smaller.
L.lights = {} -- { x, y (feet), cx, cy (middle of the glow), rx, ry, k (strength) }

local function ScaleAt(y)
	local _, H = L.Size()
	local hz = ns.s.horizon * H
	local ref = 0.69 * H - 0.23 * H
	return Clamp((y - hz) / math.max(ref, 1), 0.3, 2.0)
end
L.ScaleAt = ScaleAt

local function PlateSpot(unit)
	if not (C_NamePlate and C_NamePlate.GetNamePlateForUnit) then return nil end
	local ok, plate = pcall(C_NamePlate.GetNamePlateForUnit, unit)
	if not ok or not plate or not plate.GetCenter then return nil end
	local shown = not plate.IsVisible or plate:IsVisible()
	if not shown then return nil end
	local px, py = plate:GetCenter()
	if type(px) ~= "number" or type(py) ~= "number" or ns.Secret(px) then return nil end
	local es = plate.GetEffectiveScale and plate:GetEffectiveScale() or 1
	local rs = root.GetEffectiveScale and root:GetEffectiveScale() or 1
	local _, H = L.Size()
	px, py = px * es / rs, py * es / rs
	return px, H - py
end

local function Gather()
	local W, H = L.Size()
	local s = ns.s
	local u = H / 656
	wipe(L.lights)
	if s.meOn then
		local x, y = s.lightX * W, s.lightY * H
		local k = ScaleAt(y)
		local R = 260 * u * s.lsize * k
		L.lights[1] = { x = x, y = y, cx = x, cy = y - 34 * u * k, rx = R, ry = R * 0.8, k = 1, me = true }
	end
	if s.mikaOn then
		for i = 1, 4 do
			local unit = "party" .. i
			if not UnitExists or UnitExists(unit) then
				local px, py = PlateSpot(unit)
				if px then
					-- the name sits over the head; the feet are about a body's height lower
					local k = ScaleAt(py + 120 * u)
					local fy = py + 110 * u * k
					local R = 210 * u * s.lsize * k
					L.lights[#L.lights + 1] = { x = px, y = fy, cx = px, cy = fy - 34 * u * k, rx = R, ry = R * 0.8, k = 0.85 }
				end
			end
		end
	end
end

-- How lit a spot is (0..1): rain and snow shine where it's lit
function L.LightAt(x, y)
	local best = 0
	for _, l in ipairs(L.lights) do
		local dx, dy = (x - l.cx) / l.rx, (y - l.cy) / l.ry
		local v = (1 - math.sqrt(dx * dx + dy * dy)) * l.k
		if v > best then best = v end
	end
	return Clamp(best, 0, 1) * ns.s.lstr
end

-- ---------------------------------------------------------------- drawing
local function HideAll()
	for _, t in ipairs({ mood, hole, dim, far, glowMe, vig, prowlDark, prowlVig, catVig, frost, lowhp, L.flash, moonGlow, cloudA, cloudB }) do t:Hide() end
	for i = 1, 4 do dark[i]:Hide(); glows[i]:Hide() end
end

local function DrawDarkness(d)
	local W, H = L.Size()
	local me = L.lights[1]
	local r, g, b = NAVY[1], NAVY[2], NAVY[3]
	if d <= 0.003 then
		hole:Hide(); dim:Hide(); far:Hide()
		for i = 1, 4 do dark[i]:Hide() end
		return
	end
	-- outside the light: full darkness. Inside: the hole texture (dark at its rim, clear in the
	-- middle) plus a dim layer, so "Brightness" sets how clear the middle is with no seam at the rim
	-- Outside your light the darkness is as strong as the meter says (1.0.3 held it back to 86%,
	-- which in game wasn't dark enough). Inside, the hole texture (dark at its
	-- rim, clear in the middle) plus a dim layer meet the outside exactly at the rim, so there's
	-- no seam; "Brightness" sets how clear the middle is.
	local outside = d
	local dd = d * (1 - ns.s.lstr) * 0.45
	local holeA = 1 - (1 - outside) / (1 - dd)
	for i = 1, 4 do dark[i]:SetColorTexture(r, g, b, outside) end
	if me and me.me then
		local x0, y0, x1, y1 = me.cx - me.rx, me.cy - me.ry, me.cx + me.rx, me.cy + me.ry
		hole:SetVertexColor(r, g, b, 1)
		hole:SetAlpha(holeA)
		Place(hole, me.cx, me.cy, me.rx * 2, me.ry * 2)
		hole:Show()
		if dd > 0.003 then
			dim:SetColorTexture(r, g, b, dd)
			Place(dim, me.cx, me.cy, me.rx * 2, me.ry * 2)
			dim:Show()
		else
			dim:Hide()
		end
		PlaceRect(dark[1], 0, 0, W, math.max(0, y0))            -- above
		PlaceRect(dark[2], 0, math.min(H, y1), W, H)            -- below
		PlaceRect(dark[3], 0, math.max(0, y0), math.max(0, x0), math.min(H, y1)) -- left
		PlaceRect(dark[4], math.min(W, x1), math.max(0, y0), W, math.min(H, y1)) -- right
	else
		hole:Hide(); dim:Hide()
		PlaceRect(dark[1], 0, 0, W, H)
		for i = 2, 4 do dark[i]:Hide() end
	end
	-- further away is darker: a little more towards the top of the screen
	ns.Gradient(far, "VERTICAL", r, g, b, 0, d * 0.22)
	far:Show()
end

local function DrawGlows(d)
	-- a faint warm lantern glow round you and your party, stronger the darker it is
	local s = ns.s
	local warm = ns.s.colour == "ember" and { 1, 0.7, 0.45 } or { 1, 0.86, 0.66 }
	local me = L.lights[1]
	if me and me.me and d > 0.05 then
		glowMe:SetVertexColor(warm[1], warm[2], warm[3], 1)
		glowMe:SetAlpha(Clamp(0.24 * s.lstr * d, 0, 0.3))
		Place(glowMe, me.cx, me.cy, me.rx * 1.2, me.ry * 1.2)
		glowMe:Show()
	else
		glowMe:Hide()
	end
	local n = 0
	for i, l in ipairs(L.lights) do
		if not l.me and n < 4 and d > 0.05 then
			n = n + 1
			local t = glows[n]
			t:SetVertexColor(warm[1], warm[2], warm[3], 1)
			t:SetAlpha(Clamp(0.55 * s.lstr * d, 0, 0.6))
			Place(t, l.cx, l.cy, l.rx * 2, l.ry * 2)
			t:Show()
		end
	end
	for i = n + 1, 4 do glows[i]:Hide() end
end

-- ---------------------------------------------------------------- the night's life
-- The moon sits in its part of the sky by the game's clock (rising in the east in the evening,
-- south at midnight, setting in the west by dawn), so its glow moves when you turn and stays put
-- when you don't. Clouds drift over it: their shadows cross the land slowly, and every minute or
-- so the moon comes out for a while and the night lifts a little. Rain and storms hide it.
local moonRel, moonOut, moonPhase, moonNext, moonHold = nil, 0, "hidden", 25, 0
L.moon = { out = 0 }

local function MoonFacing(h)
	-- azimuth clockwise from north: east (90°) at 19:00, south (180°) at 00:00, west (270°) at 05:00
	local t = ((h - 19) % 24) / 10
	local az = math.rad(90 + Clamp(t, 0, 1) * 180)
	return (-az) % (2 * math.pi), math.sin(math.pi * Clamp(t, 0, 1))
end

local function NightLife(elapsed, now, d, clear)
	local W, H = L.Size()
	local s = ns.s
	local u = H / 656
	local outside = ns.Place() == "out"
	-- the moon coming out from behind the clouds now and then (only on a clear night)
	moonNext = moonNext - elapsed
	if moonPhase == "hidden" and moonNext <= 0 and clear > 0.6 then
		moonPhase, moonHold = "rising", 0
	end
	if moonPhase == "rising" then
		moonOut = math.min(1, moonOut + elapsed / 5)
		if moonOut >= 1 then moonPhase, moonHold = "out", 10 + math.random() * 16 end
	elseif moonPhase == "out" then
		moonHold = moonHold - elapsed
		if moonHold <= 0 or clear < 0.4 then moonPhase = "setting" end
	elseif moonPhase == "setting" then
		moonOut = math.max(0, moonOut - elapsed / 7)
		if moonOut <= 0 then moonPhase, moonNext = "hidden", 35 + math.random() * 55 end
	end
	L.moon.out = moonOut
	if not outside or d < 0.05 then
		moonGlow:Hide(); cloudA:Hide(); cloudB:Hide()
		return
	end
	-- cloud shadows: two soft layers drifting at different speeds and sizes
	local wind = ns.Weather and ns.Weather.Wind and ns.Weather.Wind(now) or 0
	local cover = Clamp(0.55 + (1 - clear) * 0.45, 0, 1)
	for i, t in ipairs({ cloudA, cloudB }) do
		local sc = i == 1 and 1 or 0.55
		local du = now * (0.004 + wind * 0.006) * (i == 1 and 1 or 1.7) + (i == 1 and 0 or 0.37)
		t:SetTexCoord(du, du + W / (1500 * u * sc), 338 / 512, 414 / 512)
		t:SetVertexColor(NAVY[1], NAVY[2], NAVY[3], 1)
		t:SetAlpha(Clamp(d * cover * (i == 1 and 0.22 or 0.16) * (1 - 0.6 * moonOut), 0, 0.3))
		t:Show()
	end
	-- the moon's glow, where the moon is in the sky
	local h = ns.Hour()
	local f = nil
	if GetPlayerFacing then
		local ok, v = pcall(GetPlayerFacing)
		if ok and type(v) == "number" and not ns.Secret(v) then f = v end
	end
	local glow = d * Clamp(clear, 0, 1) * (0.13 + 0.15 * moonOut)
	if h and f and glow > 0.003 then
		local fm, elev = MoonFacing(h)
		local rel = (fm - f + math.pi) % (2 * math.pi) - math.pi
		if not moonRel or math.abs(rel - moonRel) > 1.2 then moonRel = rel end
		moonRel = moonRel + (rel - moonRel) * Clamp(elapsed / 0.5, 0, 1)
		local F = H * 1.372
		local r = moonRel
		if math.abs(r) < 1.3 then
			local x = W / 2 - math.tan(r) * F
			local y = s.horizon * H - (0.10 + 0.55 * elev) * H
			moonGlow:SetVertexColor(0.58, 0.68, 0.98, 1)
			moonGlow:SetAlpha(Clamp(glow, 0, 0.3))
			Place(moonGlow, x, y, H * 1.9, H * 1.5)
			moonGlow:Show()
		else
			moonGlow:Hide()
		end
	else
		moonGlow:Hide()
	end
end

local lowPhase = 0
function L.Update(elapsed, now)
	if not root then return end
	local s = ns.s
	if not s.on then HideAll() return end
	Gather()
	local d = ns.Darkness()
	local W = ns.W
	local clear = Clamp(1 - W.cloud * 1.1 - W.fog * 0.3, 0, 1)
	NightLife(elapsed or 0, now or 0, d, clear)
	d = d * (1 - 0.2 * moonOut * clear) -- the moon out: the night lifts a little
	-- heavy cloud darkens the day too (a storm by day: your light comes on)
	if ns.Place() == "out" then d = 1 - (1 - d) * (1 - 0.32 * W.cloud * W.cloud) end
	d = Clamp(d, 0, 0.97)
	L.darkness = d
	-- colour mood: the world multiplied towards the chosen colour
	local c = ns.Colour(s.colour)
	local k = s.cstr * (ns.Place() == "out" and 1 or 0.5)
	-- rain makes the world a touch darker and cooler, cloud greyer; dust warms it
	local out = ns.Place() == "out"
	local wet = out and W.rain or 0
	local cl = out and W.cloud or 0
	local du = out and W.dust or 0
	local wr = (1 - 0.10 * wet) * (1 - 0.10 * cl) * (1 - 0.02 * du)
	local wg = (1 - 0.08 * wet) * (1 - 0.08 * cl) * (1 - 0.10 * du)
	local wb = (1 - 0.03 * wet) * (1 - 0.04 * cl) * (1 - 0.25 * du)
	if k > 0.01 or wet > 0.01 or cl > 0.01 or du > 0.01 then
		mood:SetVertexColor((1 - k * (1 - c.r)) * wr, (1 - k * (1 - c.g)) * wg, (1 - k * (1 - c.b)) * wb, 1)
		mood:Show()
	else
		mood:Hide()
	end
	DrawDarkness(d)
	DrawGlows(d)
	-- dark edges
	if s.vig > 0.01 then vig:SetVertexColor(0, 0, 0, 1); vig:SetAlpha(s.vig * 0.85); vig:Show() else vig:Hide() end
	-- prowling: dimmer, edges close in
	if s.prowl and ns.Prowling() then
		prowlDark:SetColorTexture(0, 0, 0, 0.14); prowlDark:Show()
		prowlVig:SetVertexColor(0, 0, 0, 1); prowlVig:SetAlpha(0.5); prowlVig:Show()
	else
		prowlDark:Hide(); prowlVig:Hide()
	end
	-- cat form: a faint green-gold edge, the cat's eyes
	if s.cat and ns.InCatForm() and s.dark > 0.05 then
		catVig:SetVertexColor(0.59, 0.75, 0.31, 1); catVig:SetAlpha(0.22); catVig:Show()
	else
		catVig:Hide()
	end
	-- frost on snowy days
	if W.frost > 0.05 and ns.Place() == "out" then frost:SetVertexColor(0.84, 0.91, 1, 1); frost:SetAlpha(0.5 * W.frost); frost:Show() else frost:Hide() end
	-- low health: red edges that pulse
	local low = s.lowhp and ns.LowestHealth()
	if low and low < 0.3 then
		lowPhase = lowPhase + (elapsed or 0) * 4
		local p = (math.sin(lowPhase) + 1) / 2
		lowhp:SetVertexColor(0.75, 0.06, 0.06, 1); lowhp:SetAlpha(0.28 + 0.37 * p); lowhp:Show()
	else
		lowhp:Hide()
	end
end

ns.Register("layers", L)
