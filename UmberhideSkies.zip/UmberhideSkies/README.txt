Umberhide Skies 1.0.0, for WoW Forever

Darker nights that follow the game's clock, a soft light round you and round Mika, colour moods,
rain, snow, fog and fireflies with depth, rain and wind sounds, thunder and lightning, and a few
Druid touches (Cat Form sees better in the dark, Prowling dims the world, red edges at low health).

Install once: put this UmberhideSkies folder into
  World of Warcraft\_retail_\_forever_\Interface\AddOns
next to PartyMap, then restart WoW. After that Party Map's app keeps it up to date.

In game
  /skies            the settings: presets, a meter for every effect, switches
  /skies off        everything off at once (/skies on brings it back)
  /skies storm      a preset by name: off, night, storm, drizzle, mist, snow, flies, gold, camp, gloom, grove
  /skies status     what it's doing right now

Good to know
  - It draws see-through layers on the game world, under your interface. It can't make campfires
    or torches shine through the dark, and rain can't hide behind trees or rocks.
  - "Light round Mika" follows the name over her head, so friendly name plates must be on.
  - Sounds play on the Ambience channel: the game's Ambience volume sets how loud they are.
  - "Horizon" lines the rain and fog up with your camera; move it if drops land in the wrong place.
  - Inside buildings, caves and dungeons the weather stops; "Gloom indoors" keeps them dim.
