Party Map
=========

1. Start WoW Forever (windowed or windowed fullscreen). The Party Map addon must be enabled.
2. Double-click PartyMap.exe. A map window opens (Edge or Chrome, in its own window).
3. Drag that window to your second monitor.

Keys in the map window:
  F      full screen           Q      hide/show the quest panel
  Space  recentre on you       G      quest givers (!) on/off
  P      where's my friend?    Esc    clear the selected quest
  B      Party bags: a window showing your party's bags (tick whose you want to see)
  V      places (vendors, trainers, flight masters, inns, banks, mailboxes...)
  L      look: day and night by your clock, golden hour or plain; cloud shadows; quest font (Questie's
         Friz Quadrata, the quest log's Morpheus, or modern)
  Mouse wheel zooms, drag to look around. Click a quest (or a marker) to find it on the map.
  Zoom right in for the game's own close-up detail (its minimap), as OpenMap shows it.
  Right-click the map to pin a spot: the pin command is copied, paste it into WoW chat.
  The map zooms out while you ride or fly, and back in when you stop.
  Share button: a link someone on another computer can open to watch your map live.

In WoW:
  /partymap        turn the strip on or off
  /partymap bl     strip in the bottom-left corner (also br, tl, tr)
  /partymap bright easier-to-read strip, if the map stops updating with the dim one
  /partymap dim    back to the near-invisible strip (the default)
  /partymap pin [label]   pin where you stand, for your party (Alt+click the world map: pin a spot)
  /partymap pins clear    take your pins away (they also go after 30 minutes)
  /partymap train         what you can learn now, the cost, and the nearest trainer (needs the
                          WhatsTraining addon; it also tells you on levelling up, and the map
                          window shows it at the top of your quests)
  /partymap bags off      stop sharing your bags with the party (/partymap bags on to share again)
  /partymap name <full name>   your full name for the party, e.g. /partymap name Mika Underhide
  /partymap role tank|healer|dps   which gear upgrades you're shown (auto: the role the party
                          leader gave you, else your talents)
  /partymap updates off|on   the "Party Map updated" notice off or on again
  /partymap check  versions, the other addons, your party's Party Map versions and any errors
                   (send this to Jordan if something looks wrong, with the end of partymap.log)
  /partymap test   pretend friend: a copy of you, "<you> (echo)", just beside you, sent through the
                   same messages a friend's addon uses. Type it again to stop.

Playing with a friend:
  Your friend installs the PartyMap addon folder too (the App folder is optional: only for a second
  monitor). In a party, you see each other's position, quests, Questie markers and bags.
  Friends and guild members who share their location through OpenMap show as grey dots.

The strip is a 1-pixel, almost black line on the edge of the game. Keep that corner uncovered.
Updating: Party Map keeps itself up to date. The app checks for a new version when it starts,
  every 15 minutes, and straight away when someone in your group has a newer one. It downloads it,
  checks every file, and puts it in by itself. In WoW a small "Party Map updated" notice then offers
  "Reload now" (or "Later"); press it when you're out of combat. Once in a while it says "Restart WoW
  to update" instead. To switch automatic updates off: click the small mark beside "Live" in the map
  window. /partymap updates off hides the notice. The newest version is always at
  https://github.com/jordanlcreighton-commits/party-map-releases/raw/main/PartyMap.zip
  A new version dropped in this folder as PartyMap.new.exe is also checked and swapped in
  automatically. If the new version isn't well, the previous one (PartyMap.prev.exe) goes back in
  by itself. The window's top-right corner shows the version and a small health mark: click it to
  see what's fine and what isn't.
The log: %LOCALAPPDATA%\PartyMap\partymap.log (the run before: partymap.prev.log).
