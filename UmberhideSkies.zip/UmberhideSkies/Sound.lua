-- Umberhide Skies: rain, snow, dust, wind and gusts, crickets, an owl and thunder.
-- Since 1.0.4 it uses WoW's own weather sounds where it can (the game's rain loops, snow, thunder
-- cracks and owl), played by their file IDs from the game's own data; nothing is copied. If the
-- game says it won't play one (Forever's data may not have it), the addon's own sound plays
-- instead, there and then. Everything plays on the Ambience channel, so the game's Ambience volume
-- slider sets how loud it is.
--
-- The game's loops are of unknown length, so each runs as two copies started half a period apart,
-- each restarted every period (fading the old one out): that stays unbroken for any loop at least
-- half a period long, and two copies of rain sound fuller anyway.
local ADDON, ns = ...
local S = {}
ns.Sound = S

local DIR = ns.PATH .. "Sounds\\"
-- WoW's own sounds (FileDataIDs from the community listfile, vanilla files):
local GAME = {
	rainLight = 538983,   -- sound/ambience/weather/rainlightloop.ogg
	rainMedium = 538981,  -- sound/ambience/weather/rainmediumloop.ogg
	rainHeavy = 538982,   -- sound/ambience/weather/rainheavyloop.ogg
	snowLight = 538985,   -- sound/ambience/weather/snowlight.ogg
	snowMedium = 538989,  -- sound/ambience/weather/snowmedium.ogg
	snowHeavy = 538984,   -- sound/ambience/weather/snowheavy.ogg
	dustLight = 538988,   -- sound/ambience/weather/sandstormlight.ogg
	dustMedium = 538987,  -- sound/ambience/weather/sandstormmedium.ogg
	dustHeavy = 538986,   -- sound/ambience/weather/sandstormheavy.ogg
	cracks = { 565712, 565974, 566471, 566202, 566511 }, -- sound/doodad/fx_thundercrack01-05.ogg
	owl = 557971,         -- sound/creature/owl/owlpreaggro.ogg
}
S.GAME = GAME
local GAMENAME = {}
for k, v in pairs(GAME) do
	if type(v) == "number" then GAMENAME[v] = k else for i, id in ipairs(v) do GAMENAME[id] = k .. i end end
end

local PERIOD, OVERLAP = 10.0, 1.0
local LOOPS = {
	-- key = { game = function() -> FileDataID or nil, own = file, offset }
	rain = { own = "RainLoop.ogg" },
	rain2 = { own = "RainLoop.ogg", offset = PERIOD / 2 },
	snow = { own = "WindLoop.ogg" },
	snow2 = { own = "WindLoop.ogg", offset = PERIOD / 2 },
	dust = { own = "WindLoop.ogg" },
	dust2 = { own = "WindLoop.ogg", offset = PERIOD / 2 },
	wind = { own = "WindLoop.ogg", ownOnly = true },
	muffled = { own = "RainMuffled.ogg", ownOnly = true }, -- rain on the roof, when you're indoors
	crickets = { own = "CricketsLoop.ogg", ownOnly = true, period = 8.7 },
}
local THUNDER = { "Thunder1.ogg", "Thunder2.ogg", "Thunder3.ogg" }

local state = {} -- key -> { handle, nextAt }
S.playing = state
S.log = {} -- what was played (tests read this): own file names, or "game:<name>"
S.gameOK = {} -- FileDataID -> false once the game has refused it (then we don't ask again)

local function Log(name)
	S.log[#S.log + 1] = name
	if #S.log > 60 then table.remove(S.log, 1) end
end

local function PlayOwn(file)
	if not PlaySoundFile then return nil end
	local ok, willPlay, handle = pcall(PlaySoundFile, DIR .. file, "Ambience")
	if ok and willPlay then
		Log(file)
		return handle
	end
end

-- the game's sound if it will play it, otherwise our own
local function Play(id, own)
	if id and S.gameOK[id] ~= false and PlaySoundFile then
		local ok, willPlay, handle = pcall(PlaySoundFile, id, "Ambience")
		if ok and willPlay then
			S.gameOK[id] = true
			Log("game:" .. (GAMENAME[id] or tostring(id)))
			return handle
		end
		S.gameOK[id] = false
	end
	if own then return PlayOwn(own) end
end
S.Play = Play

local function Stop(handle, fade)
	if handle and StopSound then pcall(StopSound, handle, fade or 800) end
end

local function Want(key, id, now)
	local st = state[key]
	local loop = LOOPS[key]
	if id == false then
		if st then
			Stop(st.handle, 1500)
			state[key] = nil
		end
		return
	end
	if not st then
		st = { nextAt = now + (loop.offset or 0) }
		state[key] = st
	end
	if now >= st.nextAt then
		local old = st.handle
		st.handle = loop.ownOnly and PlayOwn(loop.own) or Play(id, loop.own)
		st.nextAt = now + (loop.period or PERIOD) - OVERLAP
		if old then
			if C_Timer and C_Timer.After then C_Timer.After(OVERLAP, function() Stop(old, 700) end) else Stop(old, 700) end
		end
	end
end

function S.Update(elapsed, now)
	local s = ns.s
	local W = ns.W
	local on = s.on and s.sound
	local out = on and ns.Place() == "out"
	local d = ns.Layers.darkness or 0
	-- rain: the game's light, medium or heavy loop, by how hard it's raining now; a second copy
	-- joins as it gets heavy, so it builds as the weather comes in and fades as it goes
	local r = W.rain * ((ns.Weather and ns.Weather.rainNow) or 1)
	local rainId = r < 0.35 and GAME.rainLight or (r < 0.7 and GAME.rainMedium or GAME.rainHeavy)
	Want("rain", out and W.rain > 0.08 and rainId or false, now)
	Want("rain2", out and W.rain > 0.45 and rainId or false, now)
	-- indoors while it rains: rain on the roof, muffled
	Want("muffled", on and not out and s.live and W.rain > 0.25 and 0 or false, now)
	-- snow: the game's own snow weather (its wind and hiss)
	local snowId = W.snow < 0.35 and GAME.snowLight or (W.snow < 0.7 and GAME.snowMedium or GAME.snowHeavy)
	local snowing = out and W.snow > 0.15
	Want("snow", snowing and snowId or false, now)
	Want("snow2", snowing and W.snow > 0.6 and snowId or false, now)
	-- dust: the game's own sandstorm
	local dustId = W.dust < 0.35 and GAME.dustLight or (W.dust < 0.7 and GAME.dustMedium or GAME.dustHeavy)
	local dusting = out and W.dust > 0.15
	Want("dust", dusting and dustId or false, now)
	Want("dust2", dusting and W.dust > 0.6 and dustId or false, now)
	-- our gusting wind for windy or stormy weather (snow and dust have their own)
	Want("wind", out and not snowing and not dusting and (W.wind > 0.3 or (W.storm > 0.3 and W.rain > 0.1)) and 0 or false, now)
	-- gusts now and then when it's windy: a rush of wind that swells and dies away
	if out and W.wind > 0.42 then
		S.gustAt = S.gustAt or now + 3 + math.random() * 6
		if now >= S.gustAt then
			PlayOwn(("Gust%d.ogg"):format(math.random(3)))
			S.gustAt = now + (16 - 9 * W.wind) * (0.6 + math.random() * 0.8)
		end
	else
		S.gustAt = nil
	end
	Want("crickets", out and d > 0.35 and W.rain < 0.15 and W.snow < 0.2 and W.dust < 0.1 and W.wind < 0.5 and 0 or false, now)
	-- an owl now and then on a clear night: the game's owl and ours, in turn
	if out and d > 0.45 and W.rain < 0.1 and W.storm < 0.05 and W.snow < 0.3 and W.dust < 0.1 then
		S.owlAt = S.owlAt or now + 20 + math.random() * 40
		if now >= S.owlAt then
			S.owlTurn = not S.owlTurn
			if S.owlTurn then Play(GAME.owl, "Owl.ogg") else PlayOwn("Owl.ogg") end
			S.owlAt = now + 30 + math.random() * 60
		end
	else
		S.owlAt = nil
	end
	-- thunder follows the lightning, later the further off it was: a close strike cracks (the
	-- game's own crack) and rumbles; a far one only rolls, softer the further it is. You hear it
	-- indoors too.
	local q = ns.Weather and ns.Weather.thunder
	if q then
		for i = #q, 1, -1 do
			if now >= q[i].at then
				if on then
					local dist = q[i].dist
					if dist < 0.35 then
						local crack = GAME.cracks[math.random(#GAME.cracks)]
						if Play(crack, nil) then PlayOwn(THUNDER[2]) else PlayOwn(THUNDER[1]) end
					else
						PlayOwn(THUNDER[dist < 0.7 and 2 or 3])
					end
				end
				table.remove(q, i)
			end
		end
	end
end

function S.StopAll()
	for k in pairs(LOOPS) do Want(k, false, 0) end
end

ns.Register("sound", S)
